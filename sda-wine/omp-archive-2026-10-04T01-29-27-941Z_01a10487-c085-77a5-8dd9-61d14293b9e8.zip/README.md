# Session archive

Generated 2026-10-04T21:09:29.154Z from session `01a10487-c085-77a5-8dd9-61d14293b9e8`.

## Layout

| Path | Contents |
| --- | --- |
| `manifest.json` | Index of everything below (counts, sizes, subagent list) |
| `session.jsonl` | The main session transcript, verbatim |
| `agents.json` | Live per-agent state captured while the session ran (model, system prompt, tools) |
| `jobs.json` | Background jobs: `completed` (recovered from transcripts) + `live` (running/recent at archive time) |
| `artifacts/` | Every file under the session artifact directory, verbatim |
| `viewer.html` | Standalone HTML viewer (all subagent sessions embedded) |

`artifacts/` is the important part: it holds each subagent's own
`<AgentId>.jsonl` transcript (recursively nested), the session's
`*.bash.log` / `*.eval.log` / `*.read.log` files with the **full, untruncated**
tool and background-job output, and `*.jsonl.tombstone` kill markers.

## Background jobs

10 completed jobs recovered from the transcripts (main + every subagent); full list in `jobs.json`. A live snapshot of running/recent jobs for Main is also included. Per-job output lives in the owning transcript and in `artifacts/*.log`.

## Subagents (7)

- `Appdb42981Plan` — 214 entries, 1442175 bytes
- `AppIdentity` — 188 entries, 1092422 bytes
- `FxOnWine` — 193 entries, 1183134 bytes
- `InstallerRE` — 159 entries, 2422662 bytes
- `PriorWineKnowledge` — 95 entries, 657969 bytes
- `ProbeSpawn` — 8 entries, 14071 bytes
- `SdaStartupTrace` — 189 entries, 1633724 bytes

## Totals

69 files, 31783330 bytes.
