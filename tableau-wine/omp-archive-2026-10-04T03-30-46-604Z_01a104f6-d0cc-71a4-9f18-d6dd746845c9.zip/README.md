# Session archive

Generated 2026-10-04T21:09:39.742Z from session `01a104f6-d0cc-71a4-9f18-d6dd746845c9`.

## Layout

| Path | Contents |
| --- | --- |
| `manifest.json` | Index of everything below (counts, sizes, subagent list) |
| `session.jsonl` | The main session transcript, verbatim |
| `agents.json` | Live per-agent state captured while the session ran (model, system prompt, tools) |
| `jobs.json` | Background jobs: `completed` (recovered from transcripts) + `live` (running/recent at archive time) |
| `artifacts/` | Every file under the session artifact directory, verbatim |
| `viewer.html` | Standalone HTML viewer (all subagent sessions embedded) |

`artifacts/` is the important part: it holds each subagent's own
`<AgentId>.jsonl` transcript (recursively nested), the session's
`*.bash.log` / `*.eval.log` / `*.read.log` files with the **full, untruncated**
tool and background-job output, and `*.jsonl.tombstone` kill markers.

## Background jobs

31 completed jobs recovered from the transcripts (main + every subagent); full list in `jobs.json`. A live snapshot of running/recent jobs for Main is also included. Per-job output lives in the owning transcript and in `artifacts/*.log`.

## Subagents (17)

- `BuildEnv` — 138 entries, 684599 bytes
- `BurnInstallerWine` — 149 entries, 552032 bytes
- `DeliverableDocs` — 160 entries, 960651 bytes
- `FlexNetWine` — 287 entries, 788527 bytes
- `GapPlan` — 207 entries, 875067 bytes
- `HostIdProbes` — 310 entries, 937589 bytes
- `InstallerRecon` — 187 entries, 693402 bytes
- `LicenseRisk` — 190 entries, 1158116 bytes
- `MissingExports` — 255 entries, 1059734 bytes
- `OpenSourceTrace` — 367 entries, 1425059 bytes
- `OpenSourceTrace/OpenSourceTrace.ChromiumWin32` — 370 entries, 1456301 bytes
- `OpenSourceTrace/OpenSourceTrace.EnvoyGrpc` — 245 entries, 1071233 bytes
- `OpenSourceTrace/OpenSourceTrace.NodeLibuv` — 157 entries, 814115 bytes
- `OpenSourceTrace/OpenSourceTrace.QtWin32` — 252 entries, 1421448 bytes
- `PatchUnion` — 114 entries, 531605 bytes
- `TableauStack` — 215 entries, 654903 bytes
- `WindowsMethod` — 167 entries, 1143263 bytes

## Totals

202 files, 55758457 bytes.
