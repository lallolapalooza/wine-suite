{
  "file": "recon/TABLEAU_STACK.md",
  "msi_count": 1,
  "component_versions": [
    "Tableau core (tableau.exe/tabui.dll/tabdoc.dll/docapi.dll/art_cpp.dll/atrdiag.exe) 20262.26.0912.1023 — PE VS_VERSIONINFO FileVersion",
    "Qt 6.5.11.0 (Qt6Core/Qt6Gui/Qt6Widgets/Qt6WebEngineCore…) — Qt6Core.dll FileVersion 6.5.11.0; strings -a Qt6Core.dll | grep -oE 'Qt [0-9.]+' -> Qt 6.5.11",
    "Chromium/QtWebEngine 122.0.6261.171 — strings -a Qt6WebEngineCore.dll | grep -oE 'Chrome/[0-9.]+' -> Chrome/122.0.6261.171",
    "JRE/Java: Azul Zulu 17.0.18+1 (OpenJDK 17 JDK) — jre/bin/server/jvm.dll ProductName 'Azul Zulu 17', FileVersion 17.0.18.0.101",
    "Node.js 22.17.1 (bin/eps/eps.exe) — ProductName Node.js, OriginalFilename node.exe",
    "Hyper 2026.2.24949.r11593467 (bin/hyper/hyperd.exe) — ProductName 'Tableau Hyper Database Engine'",
    "FlexNet Publisher 11.19.4.1 build 291070 (bin/tabfnp.dll etc.) — ProductVersion/CompanyName Flexera",
    "ANGLE libEGL/libGLESv2 5.15.18.0; d3dcompiler_47.dll 6.3.9600.16384 (i386); ICU 74 (icudt74.dll)",
    "VC++ 2022 Redistributable bootstrapper 14.44.35211.0 (a0, PE32 i386, 25,635,768 B)",
    ".NET assemblies: NONE (0 of 405 PEs have a CLR header); Python: NONE; CEF/libcef.dll: NONE"
  ],
  "licensing_stack": "Flexera FlexNet Publisher 11.19.4.1 (build 291070), two layers: (1) FlexNet binaries in bin/ — tabfnp.dll (10,066,784 B, main client), fnpcommssoap.dll (501,032 B SOAP activation transport), custactutil.exe + custactutil_libFNP.dll (MSI custom-action host), FNP_Act_Installer.dll (4,646,184 B 'Activation Licensing Service Installer', embeds x86_64 FNPLicensingService.exe), installanchorservice.exe/uninstallanchorservice.exe (25,440 B). Machine identity = NIC MAC via DeviceIoControl/IOCTL or WMI (strings: s_cacheNetIfDataViaIOCTL, s_cacheNetIfDataViaWMI, s_getMACAddressFromDevice, 'Attempting to read SMBIOS UUID from WMI', CUMNProvider::readDataFromTS, CBIOSWMI/CWMI) + SMBIOS UUID via WMI Win32_ComputerSystemProduct. State dir C:\\ProgramData\\FLEXnet; log libFNP_events.log. (2) Tableau 'ATR' licensing: MSI props REGISTER/SILENTLYREGISTERUSER/SYNCHRONOUSLICENSECHECK/ACTIVATE_KEY/RECLAIMLICENSE/ACTIVATIONSERVER/LBLM/ATRENABLED/ATRREQUESTEDDURATIONSECONDS, CAs 'tableau.exe -activate|-register|-return all', registry HKLM\\SOFTWARE\\Tableau\\ATR and HKLM\\SOFTWARE\\Tableau\\FlexNetUsers\\loom. No lmutil/pubglue/*.sys.",
  "services_drivers": [
    "Service: FNPLicensingService64 (display 'FlexNet Licensing Service 64') — created by custom action bin\\installanchorservice.exe \"Tableau Software, LLC\" \"Tableau 2026.2\" at seq 5802; ACL set at 5803 via sc.exe sdset; binary %CommonProgramFiles%\\Macrovision Shared\\FLEXnet Publisher\\",
    "MSI has NO ServiceInstall/ServiceControl tables (verified msiinfo tables); no drivers (*.sys absent), no scheduled tasks, no firewall rules, no Environment table",
    "Registry (167 rows): HKLM\\SOFTWARE\\Tableau\\Directories, HKLM\\Software\\Tableau\\Tableau 2026.2\\{Directories,AutoUpdate,Autosave,DiscoverPane,Samples,Settings,Settings\\Extensions,Telemetry,Crashdump,Install}, HKLM\\SOFTWARE\\Tableau\\ReportingServer, HKLM\\SOFTWARE\\Tableau\\ATR, HKLM\\SOFTWARE\\Tableau\\FlexNetUsers",
    "HKCR: file associations .twb/.twbx/.tps/.hyper etc. (Tableau.Workbook.2, Tableau.PackagedWorkbook.2, Tableau.Preferences.2, Tableau.Bookmark.2, Tableau.Extract.2) with shell\\open|print|printto|package verb commands; URL protocols tableau, twdc, tableau-desktop",
    "No packages: Burn bundle = 1 MSI (Tableau 26.2.1954, ProductCode {D5C4243D-E35D-4F26-A837-EDB5C3AA3739}, 5,425 files / 2,208,240,220 B) + 1 ExePackage (VC2022Redist 14.44.35211.0)"
  ],
  "wine_risk_apis": [
    "bin/tabfnp.dll, bin/custactutil*.dll/exe, bin/atrdiag.exe -> DeviceIoControl/GetVolumeInformationA/QueryDosDeviceA/DefineDosDeviceA -> FlexNet hostid reads NIC/disk via raw IOCTL; Wine ntdll only handles storage IOCTLs in cdrom.c, hard-disk SMART/IOCTL_STORAGE_QUERY_PROPERTY unhandled -> empty hostid (falls back to WMI)",
    "bin/FNP_Act_Installer.dll -> OpenSCManagerA/OpenServiceA/CreateServiceA/StartServiceA/ControlService/QueryServiceConfigA/QueryServiceStatus/ChangeServiceConfigA/DeleteService -> installs+controls FNPLicensingService64; Wine SCM works but the service binary is Windows-only FlexNet code",
    "bin/tabfnp.dll, custactutil*, atrdiag.exe -> CoCreateInstance + CoInitializeSecurity + CoSetProxyBlanket (+CoInitializeEx) -> WMI/DCOM; wbemprox must marshal IWbem* through Wine DCOM",
    "CustomAction sc.exe sdset 'flexnet licensing service 64' D:(…) -> programs/sc/sc.c line ~430 = FIXME(\"SdSet command not supported, faking success\") -> safe no-op",
    "bin/tabfnp.dll, custactutil* -> SetupDiGetClassDevsA/SetupDiEnumDeviceInfo/SetupDiGetDeviceRegistryPropertyA -> PnP device enumeration for hostid; Wine setupapi partial, may return empty set",
    "bin/tabfnp.dll, custactutil*, atrdiag.exe -> iphlpapi GetAdaptersInfo -> MAC enumeration; Wine returns host NICs (should work)",
    "Qt6WebEngineCore.dll/QtWebEngineProcess.exe -> advapi32 EventRegister/EventWrite/EventWriteTransfer/EventUnregister -> Wine ntdll EtwEventRegister is a stub returning ERROR_SUCCESS with handle 0xdeadbeef -> ETW no-op, must be tolerated",
    "Qt6WebEngineCore.dll/libGLESv2.dll -> CreateDXGIFactory(1)/D3D11CreateDevice/Direct3DCreate9/D3DCompile -> Chromium/ANGLE GPU path; Wine ships dxgi/d3d11/d3d9, software fallback bin/swiftshader + bundled d3dcompiler_47.dll",
    "Qt6WebEngineCore.dll/QtWebEngineProcess.exe/hyperd.exe/jvm.dll -> OpenProcessToken/GetTokenInformation/AdjustTokenPrivileges/DuplicateTokenEx -> Chromium sandbox token manipulation; emulated Wine tokens -> may need no-sandbox",
    "Qt6WebEngineCore.dll/hyperd.exe/eps.exe -> CryptProtectData/CryptUnprotectData, CertOpenStore/CertFindCertificateInStore, CryptAcquireContextW, BCryptOpenAlgorithmProvider -> DPAPI works per-user, machine cert store sparse",
    "Qt6WebEngineCore.dll/QtWebEngineProcess.exe/jre jvm.dll/hyperd.exe -> CreateToolhelp32Snapshot/Process32First(W)/Process32Next(W) -> process enumeration; Wine supports (NtQuerySystemInformation/GetSystemFirmwareTable/WerRegister NOT imported anywhere)",
    "hyperd.exe, tabsys.dll, eps.exe (dbghelp) -> MiniDumpWriteDump -> Wine can write minidumps but stack quality is poor; crash-report path only",
    "wine-11.18/dlls/tbs/tbs.c -> Tbsi_Context_Create/Tbsi_GetDeviceInfo/GetDeviceIDString = stub returning TBS_E_TPM_NOT_FOUND; no payload PE imports tbs.dll, but TPM-backed activation would get no TPM",
    "wine-11.18/dlls/wbemprox -> Win32_ComputerSystemProduct (UUID) + Win32_NetworkAdapter present but partially stubbed -> FlexNet machine identity may be empty even though the app starts"
  ],
  "logging_knobs": "CLI/env: tableau.exe -DLogLevel=<Info|Debug|Trace> (string '-DLogLevel=%1'); '-DNativeLogConfigPath=' + 'log_config' file (strings 'Unable to read native logging configuration file.', ?NativeLogConfigPath@appoptions@tableau); invalid level -> \"An invalid value '%1' was specified for LogLevel. LogLevel reset to 'Info'.\"; per-subsystem DefaultLogLevel/ExternalProtocolLogLevel/GRPC_STACKTRACE_MINLOGLEVEL, TLog rotation (?GetLogFileRotateSizeMB, ?GetMaxBackupLogFileCount). Qt/Chromium: QT_LOGGING_RULES / QT_LOGGING_CONF / QT_FORCE_STDERR_LOGGING / QT_LOGGING_TO_CONSOLE (Qt6Core.dll) and '--remote-debugging-port=' for embedded Chromium DevTools. Destinations: user Repository (Documents\\My Tableau Repository\\Logs — strings 'My Tableau Repository', 'saved workbooks, preferences, samples, and logs aren't available', ?GetUserRepositoryDir) and per-product %LOCALAPPDATA%\\Tableau\\Tableau 2026.2\\ (exact subpath INFERENCE: composed at runtime via SHGetKnownFolderPath + 'Tableau 2026.2' literal). Licensing log: libFNP_events.log under C:\\ProgramData\\FLEXnet. Installer log: Burn WixBundleLog prefix 'Tableau_2026.2_(20262.26.0912.1023)' via /log.",
  "top_requirements": [
    "1. MSI install path: Burn -> msiexec on a1 (5,425 files, 2.06 GiB LZX cab1.cab) + WixQuietExec64 custom actions + VC2022Redist prerequisite",
    "2. x86_64 PE loading + full Qt 6.5.11 runtime (product is x64, bootstrap is 32-bit -> --enable-archs=i386,x86_64)",
    "3. Qt GUI platform plugin (qwindows) + ANGLE/d3dcompiler_47 -> D3D11/D3D9, fallback bin/swiftshader software GL (else abort before any window)",
    "4. FlexNet client load + machine identifier from DeviceIoControl NIC/disk read OR WMI fallback (Win32_NetworkAdapter + Win32_ComputerSystemProduct) — #1 functional Wine risk",
    "5. FNPLicensingService64 service install/start (installanchorservice.exe; sc sdset already faked in Wine) for ATR/concurrent activation",
    "6. QtWebEngine Chromium 122 init incl. ETW stubs, sandbox/token calls, QtWebEngineProcess.exe (HybridUI shell + start page)",
    "7. Embedded JDK 17 (jre/) + jdbcserver.jar/oauthservice.jar child processes",
    "8. hyperd.exe + hyperapi.dll (extracts/datasource engine; MiniDumpWriteDump/BCrypt/CertOpenStore/RegNotifyChangeKeyValue imports)",
    "9. eps.exe (Node.js 22.17.1) + tabprotosrv.exe brokers (ordinary console processes)",
    "10. Crash/telemetry stubs (MiniDumpWriteDump, EventRegister, SetUnhandledExceptionFilter) return success — non-blocking but void diagnostics"
  ],
  "df_free": "19G"
}