{
  "blocking_gaps": [],
  "recommended_jobs": 6,
  "configure_line": "cd /home/asdf/projects/tableau-wine/wine-11.18 && ./configure --prefix=/home/asdf/projects/tableau-wine/wine-install --enable-archs=i386,x86_64 --disable-tests",
  "disk_estimate": "Last measured: 27 GB free of 213 GB on / (87% used) per /home/asdf/projects/tableau-wine/STATE.md (2026-10-04); siblings measured 17 GB free (powerbi-linux/docs/SHAPED_REPLAY.md:387) to ~33 GiB free (mastercam-wine/STATE.md:85). A FRESH `df -h /` is UNVERIFIED here (this recon slice has no shell). Estimate for this build (all on /): source already present (44.6 MB tarball + ~1.0-1.1 GB extracted tree [INFERENCE]) + in-place i386,x86_64 object tree +3.5-5 GB [INFERENCE] + `make install` wine-install ~1.2-1.6 GB [INFERENCE] + prefix with .NET 4.8 + Tableau ~4-7 GB (mastercam measured a comparable .NET+app prefix at 7.5 GB) + ccache <=5 GB default cap = ~10-15 GB incremental. Fits 27 GB comfortably; fits 17 GB only with --disable-tests. Run `df -h /` before starting and require >=18 GB free.",
  "build_command": "cd /home/asdf/projects/tableau-wine && source env.sh && mkdir -p logs && (tools/mem_guard.sh 85 5 >> logs/mem-guard.log 2>&1 &) && export PATH=/usr/lib/ccache:$PATH && export CCACHE_DIR=$HOME/.cache/ccache && JOBS=6 tools/build_tableau.sh",
  "verified": true,
  "unverified": [
    "Fresh `df -h /` current free space (no shell in this read-only slice) - last documented 27 GB, range 17-33 GB",
    "`ccache -s` counters: the stats files are binary and not human-decodable here; ccache is installed, wrappers exist and the cache dir is populated with objects, exact hit/miss counts UNVERIFIED",
    "Prior build artefacts wine/, wine-install/, powerbi-linux/logs/ have been deleted, so no live config.log survives to re-read the invocation line; the configure line is taken from primary on-host docs (INFRA.md) + acad build_configure.log stdout",
    "Test-suite share of build time/space when adding/removing --disable-tests (INFERENCE, not measured)"
  ],
  "prereqs": {
    "result": "NO blocking gaps; no root required; nothing to install",
    "mandatory_all_present": [
      "make (/usr/bin/make)",
      "m4 (dpkg: install ok installed)",
      "patch",
      "pkg-config",
      "flex",
      "bison",
      "gcc + g++ (gcc-multilib present)",
      "clang (/usr/bin/clang)",
      "lld (/usr/bin/lld)",
      "llvm-dlltool (/usr/bin/llvm-dlltool)",
      "mingw-w64: i686-w64-mingw32-gcc AND x86_64-w64-mingw32-gcc on PATH (dpkg mingw-w64 'install ok installed')",
      "python3 3.14.3-0ubuntu2 + python3-venv package installed",
      "gcc-multilib + libc6-dev-i386 (/usr/lib32/libc.so.6 and /usr/lib/gcc/x86_64-linux-gnu/15/32/libgcc.a present)"
    ],
    "x_dev_all_present": [
      "libx11-dev (X11/Xlib.h)",
      "libxext-dev",
      "libxrender-dev (X11/extensions/Xrender.h)",
      "libxrandr-dev (Xrandr.h)",
      "libxi-dev (XInput.h)",
      "libxcursor-dev (Xcursor/Xcursor.h)",
      "libxinerama-dev (Xinerama.h)",
      "libxfixes-dev (Xfixes.h)",
      "libxcomposite-dev (Xcomposite.h)",
      "libxkbcommon-dev (xkbcommon/xkbregistry.h) + libxkbregistry-dev",
      "libfreetype-dev (freetype2/ft2build.h)",
      "libgnutls28-dev (gnutls/gnutls.h)",
      "libwayland-bin (wayland-scanner; INFRA.md notes Wayland enabled after install)"
    ],
    "evidence": "dpkg status lines 'Package: X / Status: install ok installed' for all of the above; header globs under /usr/include; binary globs under /usr/bin. Independently corroborated by acad-wine-main/logs/build_configure.log (this host, 6 days old) which reached 'configure: Finished. Do make to compile Wine.' with gcc + i686/x86_64-w64-mingw32-gcc and found X11 extensions, freetype, gnutls, dbus, fontconfig, wayland, OpenCL, pcap, PCSC, inotify, pulse, gstreamer all 'yes'.",
    "missing_nonblocking": [
      "ffmpeg (not a build dep)",
      "innoextract (not a build dep)",
      "/usr/bin/python3-venv is not a real file, but package python3-venv IS installed and venv works (acad-wine-main/tools/venv/bin/python exists from a prior run on this host)"
    ],
    "no_rootfs_needed": "acad-wine-main/env.sh supports an optional private rootfs at $ACAD/root (PATH prepend, BISON_PKGDATADIR, M4, PKG_CONFIG_PATH) but only exports it if $ACAD/root/usr/bin exists. It does NOT exist on this host, so the mechanism is inert and the system toolchain is used. tableau-wine/env.sh has no rootfs block. No private rootfs is needed because every prerequisite is installed system-wide."
  },
  "memory": {
    "MemTotal": "31788688 kB = 30.31 GiB",
    "MemAvailable_now": "15513660 kB = 14.79 GiB",
    "swap": "8388604 kB total, 3864960 kB free (4.32 GiB used)",
    "nproc": 22,
    "load": "2.68 2.64 2.88",
    "vm": "Windows guest win11 running, 8 GiB",
    "jobs_arithmetic": "Ceiling 24 GiB system RSS. 6 jobs x ~2 GiB peak RSS (Wine C++ TUs) = ~12 GiB + 8 GiB Windows VM + ~3-4 GiB OS/X/agent = ~23-24 GiB, i.e. at the ceiling. 8 jobs -> ~16+8+4 = 28 GiB (>24, only if VM idle); 14 jobs OOM-killed a prior build (powerbi-linux/tools/build_wine.sh comment) and 22 OOM-killed twice (mem_guard.sh header). Recommend JOBS=6, matching env.sh, build_tableau.sh and STATE.md defaults.",
    "mem_guard_invocation": "tools/mem_guard.sh 85 5 >> logs/mem-guard.log 2>&1 &  (cap 85% of 30 GiB = 25.5 GiB; kills only cc1/cc1plus/ld/gcc/g++/make/ninja/cmake, never qemu/the app)"
  },
  "ccache": {
    "installed": "ccache package 'install ok installed'; /usr/bin/ccache",
    "enablement": "export PATH=/usr/lib/ccache:$PATH - symlinks exist for gcc, g++, clang, clang++, AND i686-w64-mingw32-gcc / x86_64-w64-mingw32-gcc, so both the Unix and PE compilers are cached. CCACHE_DIR defaults to /home/asdf/.cache/ccache (populated; no ccache.conf present -> defaults, max_size 5 GB). No prior project build script actually enabled ccache (grep found only upstream Wine gitlab CI using PATH=/usr/lib/ccache).",
    "stats": "UNVERIFIED (binary stats files; run `ccache -s`)"
  },
  "prior_trees": {
    "note": "None of the prior build trees survive; this is why the configure line is quoted from primary on-host docs plus a surviving configure stdout log.",
    "acad-wine-main": {
      "wine/": "ABSENT",
      "wine-install/": "ABSENT",
      "root/": "ABSENT",
      "wine-11.18/": "present (patched source)",
      "logs/build_configure.log": "PRESENT - 462 lines, ends 'configure: Finished. Do make to compile Wine.'; compiler = gcc; PE compiler = i686-w64-mingw32-gcc and x86_64-w64-mingw32-gcc (mingw-w64 chosen, NOT clang); docs README.md:113 and SETUP.md:92 give `./configure --prefix=$ACAD/wine-install --enable-archs=i386,x86_64`"
    },
    "powerbi-linux": {
      "wine/": "ABSENT",
      "logs/": "ABSENT (wine-configure-depcheck.log referenced in docs is gone)",
      "docs/INFRA.md": "PRIMARY: 8.2 documents a configure rc=0 run on this host for `--prefix=$ROOT/wine/install --enable-archs=i386,x86_64 --disable-tests`; 8.3 gives the full recipe configure+`make -j14`+`make install` -> wine/install/bin/wine, ~10-20 min at -j14, and 'Nothing the --enable-archs=i386,x86_64 build requires is missing'",
      "tools/build_wine.sh:37": "same configure line incl. --disable-tests"
    },
    "powerbi": {
      "wine/wine-11.18/": "present (source, no config.log)",
      "wine/test4/": "a Wine PREFIX, not a build tree",
      "configure used": "--enable-archs=x86_64 (64-bit only), NOT i386,x86_64"
    },
    "mastercam-wine": {
      "wine/": "ABSENT",
      "wine-install/": "ABSENT",
      "README.md:81": "`tools/build_wine.sh --jobs 8` = configure --enable-archs=i386,x86_64 && make && make install -> wine-install/bin/wine (tree since deleted)"
    }
  },
  "target_tree_state": {
    "wine-11.18/": "Wine 11.18 with ALL 20 union patches applied cleanly (logs/union/union-apply.log: every patch rc=0); NOT configured (no Makefile/config.log/config.status); no wine-install/ yet; prefix/ empty",
    "src/": "wine-11.18.tar.xz = 44.6 MB",
    "app/": "tableau_burn.cab = 708.9 MB + extracted msi_root tree",
    "tools/build_tableau.sh": "ALREADY the correct driver: builds in place in wine-11.18/, installs to wine-install/, configure line exactly `--prefix=$PREFIX --enable-archs=i386,x86_64 --disable-tests`, JOBS default 6, logs to logs/wine-build.log, completion marker wine-install/.wine-build-complete, --check prints df/free",
    "inconsistency_to_flag": "the COPIED tools/build_wine.sh is the Power BI variant (builds out-of-tree wine/wine-11.18 -> wine/install) and contradicts env.sh/STATE.md (in-place -> wine-install/). Use tools/build_tableau.sh, not tools/build_wine.sh."
  },
  "extra_configure": {
    "recommended": "--disable-tests",
    "why": "skips Wine's own regression suite; saves roughly 20-30% compile time and ~1-1.5 GB of objects [INFERENCE, not measured]. It is what the proven powerbi-linux line used.",
    "caveat": "patch 0020 (tests-cover-the-series) only compiles/runs with tests enabled; if the union's regression tests are wanted (WINE_TESTS.md), reconfigure without --disable-tests and rebuild."
  },
  "report": "# $P/recon/BUILD_ENV.md — build-environment recon (read-only measurements)\n\nAll claims name their measurement. Items that could not be measured from this read-only slice are marked **UNVERIFIED**.\n\n## Verdict\nThis host CAN build Wine 11.18 for `--enable-archs=i386,x86_64` **without root**. Zero blocking prerequisite gaps: every mandatory toolchain/library is installed (dpkg status / header / binary checks), a byte-identical configure already succeeded on this host (acad `logs/build_configure.log`), and powerbi-linux `docs/INFRA.md` §8.2 records `configure rc=0` for the exact line. No private rootfs exists (`acad-wine-main/root/` absent) and none is needed.\n\n## 1. Private-rootfs mechanism\n`acad-wine-main/env.sh` optionally layers `$ACAD/root` (prepends `$R/usr/bin` to PATH, sets `BISON_PKGDATADIR`, `M4`, `PKG_CONFIG_PATH`) — but ONLY when `$ACAD/root/usr/bin` exists. It does **not** exist; the mechanism is inert and the system toolchain is used. `$P/env.sh` has no rootfs block at all. No rootfs is required: all packages are system-installed.\n\n## 2. Prerequisite checks (replicated read-only)\nMandatory — all present: `make, m4, patch, pkg-config, flex, bison, gcc/g++ (+gcc-multilib, libc6-dev-i386), clang, lld, llvm-dlltool, i686-w64-mingw32-gcc, x86_64-w64-mingw32-gcc (mingw-w64), python3 3.14.3 + python3-venv`. dpkg status = `install ok installed` for each; binaries exist in `/usr/bin`; `/usr/lib32/libc.so.6` and `/usr/lib/gcc/x86_64-linux-gnu/15/32/libgcc.a` prove the 32-bit libc/compiler support.\nX/other dev headers — all present: `Xlib.h, extensions/{Xrender,Xrandr,XInput,Xfixes,Xinerama,Xcomposite}.h, Xcursor/Xcursor.h, xkbcommon/xkbregistry.h, freetype2/ft2build.h, gnutls/gnutls.h`; packages `libx11-dev, libxext-dev, libxrender-dev, libxrandr-dev, libxi-dev, libxcursor-dev, libxinerama-dev, libxfixes-dev, libxcomposite-dev, libxkbcommon-dev, libxkbregistry-dev, libfreetype-dev, libgnutls28-dev, libwayland-bin` all installed.\nCorroboration: `acad-wine-main/logs/build_configure.log` (this host, 462 lines) ends `configure: Finished. Do 'make' to compile Wine.` with gcc + mingw-w64 and reports X11 extensions, freetype, gnutls, dbus, fontconfig, wayland, OpenCL, pcap, PCSC, inotify, pulse, gstreamer all `yes`.\nMISSING (non-blocking): `ffmpeg`, `innoextract`. `python3-venv` has no `/usr/bin` binary but the package is installed and venv works (`acad-wine-main/tools/venv/bin/python` exists).\n\n## 3. Proven-to-work configure line (from prior trees)\nNo prior build tree survives (`acad-wine-main/wine/`+`wine-install/`, `mastercam-wine/wine-install/`, `powerbi-linux/wine/`+`logs/` all deleted), so the line is taken from primary on-host docs plus the surviving acad configure stdout:\n- powerbi-linux `docs/INFRA.md` §8.2/8.3 (verified `configure rc=0` on this host; build `make -j14`; result `wine/install/bin/wine`):\n  `./configure --prefix=$ROOT/wine/install --enable-archs=i386,x86_64 --disable-tests`\n- acad `README.md:113` / `SETUP.md:92`: `./configure --prefix=<checkout>/wine-install --enable-archs=i386,x86_64` (acad log shows mingw-w64 chosen as the PE compiler; clang/lld also present).\n- mastercam `README.md:81`: `tools/build_wine.sh --jobs 8` → same line → `wine-install/bin/wine`.\n- powerbi project used `--enable-archs=x86_64` only (not both archs).\n\n## 4. Memory headroom and JOBS\nMeasured now: `MemTotal 30.31 GiB`, `MemAvailable 14.79 GiB`, `swap 8 GiB total / 3.69 GiB free`, `nproc 22`, load `2.68 2.64 2.88`; Windows VM resident 8 GiB.\nArithmetic to the 24 GiB ceiling: `6 jobs x ~2 GiB = ~12 GiB + 8 GiB VM + ~3-4 GiB OS/agent = ~23-24 GiB`. `8 jobs` → ~28 GiB (over). Prior host history: 14 jobs OOM-killed; 22 OOM-killed twice. **Recommend JOBS=6.**\nGuard: `tools/mem_guard.sh 85 5 >> logs/mem-guard.log 2>&1 &` (cap 25.5 GiB; kills only build processes).\n\n## 5. Disk estimate vs df\nLast documented free on `/`: **27 GB free of 213 GB (87% used)** — `$P/STATE.md` (2026-10-04). Siblings: 17 GB free (`powerbi-linux/docs/SHAPED_REPLAY.md:387`), ~33 GiB (`mastercam-wine/STATE.md:85`). A **fresh `df -h /` is UNVERIFIED** here (this slice has no shell). Estimated incremental footprint: source ext tree ~1.0-1.1 GB *(present)*, in-place i386,x86_64 objects +3.5-5 GB, `make install` ~1.2-1.6 GB, prefix with .NET 4.8 + Tableau ~4-7 GB, ccache ≤5 GB → **~10-15 GB**. Fits 27 GB; tight at 17 GB → use `--disable-tests`.\n`EXTRA_CONFIGURE=--disable-tests` saves ~20-30% time and ~1-1.5 GB objects [INFERENCE]. Caveat: patch 0020's tests only build/run when tests are enabled.\n\n## 6. Literal build command (logs → $P/logs)\n```\ncd /home/asdf/projects/tableau-wine\nsource env.sh\nmkdir -p logs\ntools/mem_guard.sh 85 5 >> logs/mem-guard.log 2>&1 &\nexport PATH=/usr/lib/ccache:$PATH          # caches gcc AND i686/x86_64-w64-mingw32-gcc\nexport CCACHE_DIR=$HOME/.cache/ccache\nJOBS=6 tools/build_tableau.sh             # configure(once) + make -j6 + make install -> logs/wine-build.log\n```\nIt expands to (prefix = `/home/asdf/projects/tableau-wine/wine-install`):\n```\ncd /home/asdf/projects/tableau-wine/wine-11.18\n./configure --prefix=/home/asdf/projects/tableau-wine/wine-install --enable-archs=i386,x86_64 --disable-tests >> ../logs/wine-build.log 2>&1\nmake -j6 >> ../logs/wine-build.log 2>&1\nmake install >> ../logs/wine-build.log 2>&1\n```\nResult: `wine-install/bin/wine`, marker `wine-install/.wine-build-complete`; check with `tools/build_tableau.sh --check`.\n\n## Notes / flags\n- `$P/wine-11.18` already has all 20 union patches applied cleanly (`logs/union/union-apply.log`, every rc=0) and is unconfigured.\n- The copied `tools/build_wine.sh` is the Power BI variant (out-of-tree `wine/wine-11.18` → `wine/install`) and contradicts `env.sh`/`STATE.md`; use `tools/build_tableau.sh`.\n- ccache: `/usr/lib/ccache` has wrappers for gcc, g++, clang, clang++ and both mingw cross compilers; no `ccache.conf` (defaults, max_size 5 GB). `ccache -s` counters UNVERIFIED.",
  "host": "Ubuntu 26.04.1 LTS (resolute), kernel 7.0.0-34, Intel Core Ultra 7 155H, 22 threads, 30.31 GiB RAM, no root"
}