# Session archive

Generated 2026-10-04T21:08:19.868Z from session `01a1040c-f3c7-717a-bd72-df7f462c7d3d`.

## Layout

| Path | Contents |
| --- | --- |
| `manifest.json` | Index of everything below (counts, sizes, subagent list) |
| `session.jsonl` | The main session transcript, verbatim |
| `agents.json` | Live per-agent state captured while the session ran (model, system prompt, tools) |
| `jobs.json` | Background jobs: `completed` (recovered from transcripts) + `live` (running/recent at archive time) |
| `artifacts/` | Every file under the session artifact directory, verbatim |
| `viewer.html` | Standalone HTML viewer (all subagent sessions embedded) |

`artifacts/` is the important part: it holds each subagent's own
`<AgentId>.jsonl` transcript (recursively nested), the session's
`*.bash.log` / `*.eval.log` / `*.read.log` files with the **full, untruncated**
tool and background-job output, and `*.jsonl.tombstone` kill markers.

## Background jobs

13 completed jobs recovered from the transcripts (main + every subagent); full list in `jobs.json`. A live snapshot of running/recent jobs for Main is also included. Per-job output lives in the owning transcript and in `artifacts/*.log`.

## Subagents (5)

- `Appdb4xRecipe` — 11 entries, 19428 bytes
- `CSPenguinInstaller` — 11 entries, 20022 bytes
- `CSPTechStack` — 11 entries, 19643 bytes
- `WineBugzillaScan` — 11 entries, 18950 bytes
- `WineDcompStatus` — 11 entries, 20206 bytes

## Totals

22 files, 7023752 bytes.
