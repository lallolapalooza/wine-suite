// This file is part of Notepad++ project
// Copyright (C)2021 Don HO <don.h@free.fr>

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// at your option any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.


#include "Parameters.h"

#include <windows.h>

#include <shlobj.h>
#include <shlwapi.h>
#include <strsafe.h>

#include <algorithm>
#include <array>
#include <cassert>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <cwchar>
#include <exception>
#include <locale>
#include <map>
#include <memory>
#include <sstream>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

#include <SciLexer.h>
#include <Scintilla.h>

#include "Common.h"
#include "ContextMenu.h"
#include "Notepad_plus_Window.h"
#include "Notepad_plus_msgs.h"
#include "NppConstants.h"
#include "NppDarkMode.h"
#include "NppXml.h"
#include "ScintillaEditView.h"
#include "ToolBar.h"
#include "UserDefineDialog.h"
#include "hmac.h"
#include "keys.h"
#include "localization.h"
#include "localizationString.h"
#include "menuCmdID.h"
#include "resource.h"
#include "shortcut.h"
#include "verifySignedfile.h"

#ifdef _MSC_VER
#pragma warning(disable : 4996) // for GetVersionEx()
#endif

static constexpr const wchar_t localConfFile[] = L"doLocalConf.xml";
static constexpr const wchar_t notepadStyleFile[] = L"asNotepad.xml";

static constexpr int NB_MAX_FINDHISTORY_FIND = 30;
static constexpr int NB_MAX_FINDHISTORY_REPLACE = 30;
static constexpr int NB_MAX_FINDHISTORY_PATH = 30;
static constexpr int NB_MAX_FINDHISTORY_FILTER = 20;

namespace // anonymous namespace
{


struct WinMenuKeyDefinition // more or less matches accelerator table definition, easy copy/paste
{
	int vKey = 0;
	int functionId = 0;
	bool isCtrl = false;
	bool isAlt = false;
	bool isShift = false;
	const wchar_t * specialName = nullptr; // Used when no real menu name exists (in case of toggle for example)
};


/*!
** \brief array of accelerator keys for all std menu items
**
** values can be 0 for vKey, which means its unused
*/
static constexpr WinMenuKeyDefinition winKeyDefs[]
{
	// V_KEY,    COMMAND_ID,                                    Ctrl,  Alt,   Shift, cmdName
	// -------------------------------------------------------------------------------------
	//
	{ VK_N,       IDM_FILE_NEW,                                 true,  false, false, nullptr },
	{ VK_O,       IDM_FILE_OPEN,                                true,  false, false, nullptr },
	{ VK_NULL,    IDM_FILE_OPEN_FOLDER,                         false, false, false, L"Open containing folder in Explorer" },
	{ VK_NULL,    IDM_FILE_OPEN_CMD,                            false, false, false, L"Open containing folder in Command Prompt" },
	{ VK_NULL,    IDM_FILE_OPEN_POWERSHELL,                     false, false, false, L"Open containing folder in PowerShell" },
	{ VK_NULL,    IDM_FILE_OPEN_DEFAULT_VIEWER,                 false, false, false, nullptr },
	{ VK_NULL,    IDM_FILE_OPENFOLDERASWORKSPACE,                false, false, false, nullptr },
	{ VK_R,       IDM_FILE_RELOAD,                              true,  false, false, nullptr },
	{ VK_S,       IDM_FILE_SAVE,                                true,  false, false, nullptr },
	{ VK_S,       IDM_FILE_SAVEAS,                              true,  true,  false, nullptr },
	{ VK_NULL,    IDM_FILE_SAVECOPYAS,                          false, false, false, nullptr },
	{ VK_S,       IDM_FILE_SAVEALL,                             true,  false, true,  nullptr },
	{ VK_NULL,    IDM_FILE_RENAME,                              false, false, false, nullptr },
	{ VK_W,       IDM_FILE_CLOSE,                               true,  false, false, nullptr },
	{ VK_W,       IDM_FILE_CLOSEALL,                            true,  false, true,  nullptr },
	{ VK_NULL,    IDM_FILE_CLOSEALL_BUT_CURRENT,                false, false, false, nullptr },
	{ VK_NULL,    IDM_FILE_CLOSEALL_BUT_PINNED,                 false, false, false, nullptr },
	{ VK_NULL,    IDM_FILE_CLOSEALL_TOLEFT,                     false, false, false, nullptr },
	{ VK_NULL,    IDM_FILE_CLOSEALL_TORIGHT,                    false, false, false, nullptr },
	{ VK_NULL,    IDM_FILE_CLOSEALL_UNCHANGED,                  false, false, false, nullptr },
	{ VK_NULL,    IDM_FILE_DELETE,                              false, false, false, nullptr },
	{ VK_NULL,    IDM_FILE_LOADSESSION,                         false, false, false, nullptr },
	{ VK_NULL,    IDM_FILE_SAVESESSION,                         false, false, false, nullptr },
	{ VK_P,       IDM_FILE_PRINT,                               true,  false, false, nullptr },
	{ VK_NULL,    IDM_FILE_PRINTNOW,                            false, false, false, nullptr },
	{ VK_T,       IDM_FILE_RESTORELASTCLOSEDFILE,               true,  false, true,  L"Restore Recent Closed File" },
	{ VK_F4,      IDM_FILE_EXIT,                                false, true,  false, nullptr },

//	{ VK_NULL,    IDM_EDIT_UNDO,                                false, false, false, nullptr },
//	{ VK_NULL,    IDM_EDIT_REDO,                                false, false, false, nullptr },

	{ VK_DELETE,  IDM_EDIT_CUT,                                 false, false, true,  nullptr },
	{ VK_X,       IDM_EDIT_CUT,                                 true,  false, false, nullptr },

	{ VK_INSERT,  IDM_EDIT_COPY,                                true,  false, false, nullptr },
	{ VK_C,       IDM_EDIT_COPY,                                true,  false, false, nullptr },

	{ VK_INSERT,  IDM_EDIT_PASTE,                               false, false, true,  nullptr },
	{ VK_V,       IDM_EDIT_PASTE,                               true,  false, false, nullptr },

//	{ VK_NULL,    IDM_EDIT_DELETE,                              false, false, false, nullptr },
//	{ VK_NULL,    IDM_EDIT_SELECTALL,                           false, false, false, nullptr },
	{ VK_B,       IDM_EDIT_BEGINENDSELECT,                      true,  false, true,  nullptr },
	{ VK_B,       IDM_EDIT_BEGINENDSELECT_COLUMNMODE,           false, true,  true,  nullptr },

	{ VK_NULL,    IDM_EDIT_FULLPATHTOCLIP,                      false, false, false, nullptr },
	{ VK_NULL,    IDM_EDIT_FILENAMETOCLIP,                      false, false, false, nullptr },
	{ VK_NULL,    IDM_EDIT_CURRENTDIRTOCLIP,                    false, false, false, nullptr },
	{ VK_NULL,    IDM_EDIT_COPY_ALL_NAMES,                      false, false, false, nullptr },
	{ VK_NULL,    IDM_EDIT_COPY_ALL_PATHS,                      false, false, false, nullptr },

	{ VK_NULL,    IDM_EDIT_INS_TAB,                             false, false, false, nullptr },
	{ VK_NULL,    IDM_EDIT_RMV_TAB,                             false, false, false, nullptr },
	{ VK_U,       IDM_EDIT_UPPERCASE,                           true,  false, true,  nullptr },
	{ VK_U,       IDM_EDIT_LOWERCASE,                           true,  false, false, nullptr },
	{ VK_U,       IDM_EDIT_PROPERCASE_FORCE,                    false, true,  false, nullptr },
	{ VK_U,       IDM_EDIT_PROPERCASE_BLEND,                    false, true,  true,  nullptr },
	{ VK_U,       IDM_EDIT_SENTENCECASE_FORCE,                  true,  true,  false, nullptr },
	{ VK_U,       IDM_EDIT_SENTENCECASE_BLEND,                  true,  true,  true,  nullptr },
	{ VK_NULL,    IDM_EDIT_INVERTCASE,                          false, false, false, nullptr },
	{ VK_NULL,    IDM_EDIT_RANDOMCASE,                          false, false, false, nullptr },
	{ VK_NULL,    IDM_EDIT_REMOVE_CONSECUTIVE_DUP_LINES,        false, false, false, nullptr },
	{ VK_NULL,    IDM_EDIT_REMOVE_ANY_DUP_LINES,                false, false, false, nullptr },
	{ VK_I,       IDM_EDIT_SPLIT_LINES,                         true,  false, false, nullptr },
	{ VK_J,       IDM_EDIT_JOIN_LINES,                          true,  false, false, nullptr },
	{ VK_UP,      IDM_EDIT_LINE_UP,                             true,  false, true,  nullptr },
	{ VK_DOWN,    IDM_EDIT_LINE_DOWN,                           true,  false, true,  nullptr },
	{ VK_NULL,    IDM_EDIT_REMOVEEMPTYLINES,                    false, false, false, nullptr },
	{ VK_NULL,    IDM_EDIT_REMOVEEMPTYLINESWITHBLANK,           false, false, false, nullptr },
	{ VK_RETURN,  IDM_EDIT_BLANKLINEABOVECURRENT,               true,  true,  false, nullptr },
	{ VK_RETURN,  IDM_EDIT_BLANKLINEBELOWCURRENT,               true,  true,  true,  nullptr },
	{ VK_NULL,    IDM_EDIT_SORTLINES_LENGTH_ASCENDING,          false, false, false, nullptr },
	{ VK_NULL,    IDM_EDIT_SORTLINES_LENGTH_DESCENDING,         false, false, false, nullptr },
	{ VK_NULL,    IDM_EDIT_SORTLINES_LEXICOGRAPHIC_ASCENDING,   false, false, false, nullptr },
	{ VK_NULL,    IDM_EDIT_SORTLINES_LEXICOGRAPHIC_DESCENDING,  false, false, false, nullptr },
	{ VK_NULL,    IDM_EDIT_SORTLINES_LEXICO_CASE_INSENS_ASCENDING,   false, false, false, nullptr },
	{ VK_NULL,    IDM_EDIT_SORTLINES_LEXICO_CASE_INSENS_DESCENDING,  false, false, false, nullptr },
	{ VK_NULL,    IDM_EDIT_SORTLINES_LOCALE_ASCENDING,          false, false, false, nullptr },
	{ VK_NULL,    IDM_EDIT_SORTLINES_LOCALE_DESCENDING,         false, false, false, nullptr },
	{ VK_NULL,    IDM_EDIT_SORTLINES_INTEGER_ASCENDING,         false, false, false, nullptr },
	{ VK_NULL,    IDM_EDIT_SORTLINES_INTEGER_DESCENDING,        false, false, false, nullptr },
	{ VK_NULL,    IDM_EDIT_SORTLINES_DECIMALCOMMA_ASCENDING,    false, false, false, nullptr },
	{ VK_NULL,    IDM_EDIT_SORTLINES_DECIMALCOMMA_DESCENDING,   false, false, false, nullptr },
	{ VK_NULL,    IDM_EDIT_SORTLINES_DECIMALDOT_ASCENDING,      false, false, false, nullptr },
	{ VK_NULL,    IDM_EDIT_SORTLINES_DECIMALDOT_DESCENDING,     false, false, false, nullptr },
	{ VK_NULL,    IDM_EDIT_SORTLINES_REVERSE_ORDER,             false, false, false, nullptr },
	{ VK_NULL,    IDM_EDIT_SORTLINES_RANDOMLY,                  false, false, false, nullptr },
	{ VK_Q,       IDM_EDIT_BLOCK_COMMENT,                       true,  false, false, nullptr },
	{ VK_K,       IDM_EDIT_BLOCK_COMMENT_SET,                   true,  false, false, nullptr },
	{ VK_K,       IDM_EDIT_BLOCK_UNCOMMENT,                     true,  false, true,  nullptr },
	{ VK_Q,       IDM_EDIT_STREAM_COMMENT,                      true,  false, true,  nullptr },
	{ VK_NULL,    IDM_EDIT_STREAM_UNCOMMENT,                    false, false, false, nullptr },
	{ VK_SPACE,   IDM_EDIT_AUTOCOMPLETE,                        true,  false, false, nullptr },
	{ VK_SPACE,   IDM_EDIT_AUTOCOMPLETE_PATH,                   true,  true,  false, nullptr },
	{ VK_RETURN,  IDM_EDIT_AUTOCOMPLETE_CURRENTFILE,            true,  false, false, nullptr },
	{ VK_SPACE,   IDM_EDIT_FUNCCALLTIP,                         true,  false, true,  nullptr },
	{ VK_UP,      IDM_EDIT_FUNCCALLTIP_PREVIOUS,                false, true,  false, nullptr },
	{ VK_DOWN,    IDM_EDIT_FUNCCALLTIP_NEXT,                    false, true,  false, nullptr },
	{ VK_NULL,    IDM_EDIT_INSERT_DATETIME_SHORT,               false, false, false, nullptr },
	{ VK_NULL,    IDM_EDIT_INSERT_DATETIME_LONG,                false, false, false, nullptr },
	{ VK_NULL,    IDM_EDIT_INSERT_DATETIME_CUSTOMIZED,          false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_TODOS,                             false, false, false, L"EOL Conversion to Windows (CR LF)" },
	{ VK_NULL,    IDM_FORMAT_TOUNIX,                            false, false, false, L"EOL Conversion to Unix (LF)" },
	{ VK_NULL,    IDM_FORMAT_TOMAC,                             false, false, false, L"EOL Conversion to Macintosh (CR)" },
	{ VK_NULL,    IDM_EDIT_TRIMTRAILING,                        false, false, false, nullptr },
	{ VK_NULL,    IDM_EDIT_TRIMLINEHEAD,                        false, false, false, nullptr },
	{ VK_NULL,    IDM_EDIT_TRIM_BOTH,                           false, false, false, nullptr },
	{ VK_NULL,    IDM_EDIT_EOL2WS,                              false, false, false, nullptr },
	{ VK_NULL,    IDM_EDIT_TRIMALL,                             false, false, false, nullptr },
	{ VK_NULL,    IDM_EDIT_TAB2SW,                              false, false, false, nullptr },
	{ VK_NULL,    IDM_EDIT_SW2TAB_ALL,                          false, false, false, nullptr },
	{ VK_NULL,    IDM_EDIT_SW2TAB_LEADING,                      false, false, false, nullptr },
	{ VK_NULL,    IDM_EDIT_PASTE_AS_HTML,                       false, false, false, nullptr },
	{ VK_NULL,    IDM_EDIT_PASTE_AS_RTF,                        false, false, false, nullptr },
	{ VK_NULL,    IDM_EDIT_COPY_BINARY,                         false, false, false, nullptr },
	{ VK_NULL,    IDM_EDIT_CUT_BINARY,                          false, false, false, nullptr },
	{ VK_NULL,    IDM_EDIT_PASTE_BINARY,                        false, false, false, nullptr },
	{ VK_NULL,    IDM_EDIT_OPENSELECTEDFILETOEDIT,              false, false, false, nullptr },
	{ VK_NULL,    IDM_EDIT_OPENSELECTEDFILEFOLDERINEXPLORER,    false, false, false, nullptr },
	{ VK_NULL,    IDM_EDIT_SEARCHONINTERNET,                    false, false, false, nullptr },
	{ VK_NULL,    IDM_EDIT_CHANGESEARCHENGINE,                  false, false, false, nullptr },
	{ VK_NULL,    IDM_EDIT_MULTISELECTALL,                      false, false, false, L"Multi-select All: Ignore Case and Whole Word" },
	{ VK_NULL,    IDM_EDIT_MULTISELECTALLMATCHCASE,             false, false, false, L"Multi-select All: Match Case Only" },
	{ VK_NULL,    IDM_EDIT_MULTISELECTALLWHOLEWORD,             false, false, false, L"Multi-select All: Match Whole Word Only" },
	{ VK_NULL,    IDM_EDIT_MULTISELECTALLMATCHCASEWHOLEWORD,    false, false, false, L"Multi-select All: Match Case and Whole Word" },
	{ VK_NULL,    IDM_EDIT_MULTISELECTNEXT,                     false, false, false, L"Multi-select Next: Ignore Case and Whole Word" },
	{ VK_NULL,    IDM_EDIT_MULTISELECTNEXTMATCHCASE,            false, false, false, L"Multi-select Next: Match Case Only" },
	{ VK_NULL,    IDM_EDIT_MULTISELECTNEXTWHOLEWORD,            false, false, false, L"Multi-select Next: Match Whole Word Only" },
	{ VK_NULL,    IDM_EDIT_MULTISELECTNEXTMATCHCASEWHOLEWORD,   false, false, false, L"Multi-select Next: Match Case and Whole Word" },
	{ VK_NULL,    IDM_EDIT_MULTISELECTUNDO,                     false, false, false, nullptr },
	{ VK_NULL,    IDM_EDIT_MULTISELECTSSKIP,                    false, false, false, nullptr },
//  { VK_NULL,    IDM_EDIT_COLUMNMODETIP,                       false, false, false, nullptr },
	{ VK_C,       IDM_EDIT_COLUMNMODE,                          false, true,  false, nullptr },
	{ VK_NULL,    IDM_EDIT_CHAR_PANEL,                          false, false, false, L"Toggle Character Panel" },
	{ VK_NULL,    IDM_EDIT_CLIPBOARDHISTORY_PANEL,              false, false, false, L"Toggle Clipboard History" },
	{ VK_NULL,    IDM_EDIT_TOGGLEREADONLY,                      false, false, false, nullptr },
	{ VK_NULL,    IDM_EDIT_SETREADONLYFORALLDOCS,               false, false, false, nullptr },
	{ VK_NULL,    IDM_EDIT_CLEARREADONLYFORALLDOCS,             false, false, false, nullptr },
	{ VK_NULL,    IDM_EDIT_TOGGLESYSTEMREADONLY,                false, false, false, nullptr },
	{ VK_F,       IDM_SEARCH_FIND,                              true,  false, false, nullptr },
	{ VK_F,       IDM_SEARCH_FINDINFILES,                       true,  false, true,  nullptr },
	{ VK_F3,      IDM_SEARCH_FINDNEXT,                          false, false, false, nullptr },
	{ VK_F3,      IDM_SEARCH_FINDPREV,                          false, false, true,  nullptr },
	{ VK_F3,      IDM_SEARCH_SETANDFINDNEXT,                    true,  false, false, nullptr },
	{ VK_F3,      IDM_SEARCH_SETANDFINDPREV,                    true,  false, true,  nullptr },
	{ VK_F3,      IDM_SEARCH_VOLATILE_FINDNEXT,                 true,  true,  false, nullptr },
	{ VK_F3,      IDM_SEARCH_VOLATILE_FINDPREV,                 true,  true,  true,  nullptr },
	{ VK_H,       IDM_SEARCH_REPLACE,                           true,  false, false, nullptr },
	{ VK_I,       IDM_SEARCH_FINDINCREMENT,                     true,  true,  false, nullptr },
	{ VK_F7,      IDM_FOCUS_ON_FOUND_RESULTS,                   false, false, false, nullptr },
	{ VK_F4,      IDM_SEARCH_GOTOPREVFOUND,                     false, false, true,  nullptr },
	{ VK_F4,      IDM_SEARCH_GOTONEXTFOUND,                     false, false, false, nullptr },
	{ VK_G,       IDM_SEARCH_GOTOLINE,                          true,  false, false, nullptr },
	{ VK_B,       IDM_SEARCH_GOTOMATCHINGBRACE,                 true,  false, false, nullptr },
	{ VK_B,       IDM_SEARCH_SELECTMATCHINGBRACES,              true,  true,  false, nullptr },
	{ VK_NULL,    IDM_SEARCH_CHANGED_PREV,                      false, false, false, nullptr },
	{ VK_NULL,    IDM_SEARCH_CHANGED_NEXT,                      false, false, false, nullptr },
	{ VK_NULL,    IDM_SEARCH_CLEAR_CHANGE_HISTORY,              false, false, false, nullptr },
	{ VK_M,       IDM_SEARCH_MARK,                              true,  false, false, nullptr },
	{ VK_NULL,    IDM_SEARCH_MARKALLEXT1,                       false, false, false, L"Style all using 1st style" },
	{ VK_NULL,    IDM_SEARCH_MARKALLEXT2,                       false, false, false, L"Style all using 2nd style" },
	{ VK_NULL,    IDM_SEARCH_MARKALLEXT3,                       false, false, false, L"Style all using 3rd style" },
	{ VK_NULL,    IDM_SEARCH_MARKALLEXT4,                       false, false, false, L"Style all using 4th style" },
	{ VK_NULL,    IDM_SEARCH_MARKALLEXT5,                       false, false, false, L"Style all using 5th style" },
	{ VK_NULL,    IDM_SEARCH_MARKONEEXT1,                       false, false, false, L"Style one using 1st style" },
	{ VK_NULL,    IDM_SEARCH_MARKONEEXT2,                       false, false, false, L"Style one using 2nd style" },
	{ VK_NULL,    IDM_SEARCH_MARKONEEXT3,                       false, false, false, L"Style one using 3rd style" },
	{ VK_NULL,    IDM_SEARCH_MARKONEEXT4,                       false, false, false, L"Style one using 4th style" },
	{ VK_NULL,    IDM_SEARCH_MARKONEEXT5,                       false, false, false, L"Style one using 5th style" },
	{ VK_NULL,    IDM_SEARCH_UNMARKALLEXT1,                     false, false, false, L"Clear 1st style" },
	{ VK_NULL,    IDM_SEARCH_UNMARKALLEXT2,                     false, false, false, L"Clear 2nd style" },
	{ VK_NULL,    IDM_SEARCH_UNMARKALLEXT3,                     false, false, false, L"Clear 3rd style" },
	{ VK_NULL,    IDM_SEARCH_UNMARKALLEXT4,                     false, false, false, L"Clear 4th style" },
	{ VK_NULL,    IDM_SEARCH_UNMARKALLEXT5,                     false, false, false, L"Clear 5th style" },
	{ VK_NULL,    IDM_SEARCH_CLEARALLMARKS,                     false, false, false, L"Clear all styles" },
	{ VK_1,       IDM_SEARCH_GOPREVMARKER1,                     true,  false, true,  L"Previous style of 1st style" },
	{ VK_2,       IDM_SEARCH_GOPREVMARKER2,                     true,  false, true,  L"Previous style of 2nd style" },
	{ VK_3,       IDM_SEARCH_GOPREVMARKER3,                     true,  false, true,  L"Previous style of 3rd style" },
	{ VK_4,       IDM_SEARCH_GOPREVMARKER4,                     true,  false, true,  L"Previous style of 4th style" },
	{ VK_5,       IDM_SEARCH_GOPREVMARKER5,                     true,  false, true,  L"Previous style of 5th style" },
	{ VK_0,       IDM_SEARCH_GOPREVMARKER_DEF,                  true,  false, true,  L"Previous style of Find Mark style" },
	{ VK_1,       IDM_SEARCH_GONEXTMARKER1,                     true,  false, false, L"Next style of 1st style" },
	{ VK_2,       IDM_SEARCH_GONEXTMARKER2,                     true,  false, false, L"Next style of 2nd style" },
	{ VK_3,       IDM_SEARCH_GONEXTMARKER3,                     true,  false, false, L"Next style of 3rd style" },
	{ VK_4,       IDM_SEARCH_GONEXTMARKER4,                     true,  false, false, L"Next style of 4th style" },
	{ VK_5,       IDM_SEARCH_GONEXTMARKER5,                     true,  false, false, L"Next style of 5th style" },
	{ VK_0,       IDM_SEARCH_GONEXTMARKER_DEF,                  true,  false, false, L"Next style of Find Mark style" },
	{ VK_NULL,    IDM_SEARCH_STYLE1TOCLIP,                      false, false, false, L"Copy Styled Text of 1st Style" },
	{ VK_NULL,    IDM_SEARCH_STYLE2TOCLIP,                      false, false, false, L"Copy Styled Text of 2nd Style" },
	{ VK_NULL,    IDM_SEARCH_STYLE3TOCLIP,                      false, false, false, L"Copy Styled Text of 3rd Style" },
	{ VK_NULL,    IDM_SEARCH_STYLE4TOCLIP,                      false, false, false, L"Copy Styled Text of 4th Style" },
	{ VK_NULL,    IDM_SEARCH_STYLE5TOCLIP,                      false, false, false, L"Copy Styled Text of 5th Style" },
	{ VK_NULL,    IDM_SEARCH_ALLSTYLESTOCLIP,                   false, false, false, L"Copy Styled Text of All Styles" },
	{ VK_NULL,    IDM_SEARCH_MARKEDTOCLIP,                      false, false, false, L"Copy Styled Text of Find Mark style" },
	{ VK_F2,      IDM_SEARCH_TOGGLE_BOOKMARK,                   true,  false, false, nullptr },
	{ VK_F2,      IDM_SEARCH_NEXT_BOOKMARK,                     false, false, false, nullptr },
	{ VK_F2,      IDM_SEARCH_PREV_BOOKMARK,                     false, false, true, nullptr  },
	{ VK_NULL,    IDM_SEARCH_CLEAR_BOOKMARKS,                   false, false, false, nullptr },
	{ VK_NULL,    IDM_SEARCH_CUTMARKEDLINES,                    false, false, false, nullptr },
	{ VK_NULL,    IDM_SEARCH_COPYMARKEDLINES,                   false, false, false, nullptr },
	{ VK_NULL,    IDM_SEARCH_PASTEMARKEDLINES,                  false, false, false, nullptr },
	{ VK_NULL,    IDM_SEARCH_DELETEMARKEDLINES,                 false, false, false, nullptr },
	{ VK_NULL,    IDM_SEARCH_DELETEUNMARKEDLINES,               false, false, false, nullptr },
	{ VK_NULL,    IDM_SEARCH_INVERSEMARKS,                      false, false, false, nullptr },
	{ VK_NULL,    IDM_SEARCH_FINDCHARINRANGE,                   false, false, false, nullptr },

	{ VK_NULL,    IDM_VIEW_ALWAYSONTOP,                         false, false, false, nullptr },
	{ VK_F11,     IDM_VIEW_FULLSCREENTOGGLE,                    false, false, false, nullptr },
	{ VK_F12,     IDM_VIEW_POSTIT,                              false, false, false, nullptr },
	{ VK_NULL,    IDM_VIEW_DISTRACTIONFREE,                     false, false, false, nullptr },

	{ VK_NULL,    IDM_VIEW_IN_FIREFOX,                          false, false, false, L"View current file in Firefox" },
	{ VK_NULL,    IDM_VIEW_IN_CHROME,                           false, false, false, L"View current file in Chrome" },
	{ VK_NULL,    IDM_VIEW_IN_IE,                               false, false, false, L"View current file in IE" },
	{ VK_NULL,    IDM_VIEW_IN_EDGE,                             false, false, false, L"View current file in Edge" },

	{ VK_NULL,    IDM_VIEW_TAB_SPACE,                           false, false, false, nullptr },
	{ VK_NULL,    IDM_VIEW_EOL,                                 false, false, false, nullptr },
	{ VK_NULL,    IDM_VIEW_ALL_CHARACTERS,                      false, false, false, nullptr },
	{ VK_NULL,    IDM_VIEW_NPC,                                 false, false, false, nullptr },
	{ VK_NULL,    IDM_VIEW_NPC_CCUNIEOL,                        false, false, false, nullptr },
	{ VK_NULL,    IDM_VIEW_INDENT_GUIDE,                        false, false, false, nullptr },
	{ VK_NULL,    IDM_VIEW_WRAP_SYMBOL,                         false, false, false, nullptr },
//  { VK_NULL,    IDM_VIEW_ZOOMIN,                              false, false, false, nullptr },
//  { VK_NULL,    IDM_VIEW_ZOOMOUT,                             false, false, false, nullptr },
//  { VK_NULL,    IDM_VIEW_ZOOMRESTORE,                         false, false, false, nullptr },
	{ VK_NULL,    IDM_VIEW_GOTO_START,                          false, false, false, nullptr },
	{ VK_NULL,    IDM_VIEW_GOTO_END,                            false, false, false, nullptr },
	{ VK_NULL,    IDM_VIEW_GOTO_ANOTHER_VIEW,                   false, false, false, nullptr },
	{ VK_NULL,    IDM_VIEW_CLONE_TO_ANOTHER_VIEW,               false, false, false, nullptr },
	{ VK_NULL,    IDM_VIEW_GOTO_NEW_INSTANCE,                   false, false, false, nullptr },
	{ VK_NULL,    IDM_VIEW_LOAD_IN_NEW_INSTANCE,                false, false, false, nullptr },

	{ VK_NUMPAD1, IDM_VIEW_TAB1,                                true,  false, false, nullptr },
	{ VK_NUMPAD2, IDM_VIEW_TAB2,                                true,  false, false, nullptr },
	{ VK_NUMPAD3, IDM_VIEW_TAB3,                                true,  false, false, nullptr },
	{ VK_NUMPAD4, IDM_VIEW_TAB4,                                true,  false, false, nullptr },
	{ VK_NUMPAD5, IDM_VIEW_TAB5,                                true,  false, false, nullptr },
	{ VK_NUMPAD6, IDM_VIEW_TAB6,                                true,  false, false, nullptr },
	{ VK_NUMPAD7, IDM_VIEW_TAB7,                                true,  false, false, nullptr },
	{ VK_NUMPAD8, IDM_VIEW_TAB8,                                true,  false, false, nullptr },
	{ VK_NUMPAD9, IDM_VIEW_TAB9,                                true,  false, false, nullptr },
	{ VK_NULL,    IDM_VIEW_TAB_START,                           false, false, false, nullptr },
	{ VK_NULL,    IDM_VIEW_TAB_END,                             false, false, false, nullptr },
	{ VK_NEXT,    IDM_VIEW_TAB_NEXT,                            true,  false, false, nullptr },
	{ VK_PRIOR,   IDM_VIEW_TAB_PREV,                            true,  false, false, nullptr },
	{ VK_NEXT,    IDM_VIEW_TAB_MOVEFORWARD,                     true,  false, true,  nullptr },
	{ VK_PRIOR,   IDM_VIEW_TAB_MOVEBACKWARD,                    true,  false, true,  nullptr },
	{ VK_TAB,     IDC_PREV_DOC,                                 true,  false, true,  L"Switch to previous document" },
	{ VK_TAB,     IDC_NEXT_DOC,                                 true,  false, false, L"Switch to next document" },
	{ VK_NULL,    IDM_VIEW_WRAP,                                false, false, false, nullptr },
	{ VK_H,       IDM_VIEW_HIDELINES,                           false, true,  false, nullptr },
	{ VK_F8,      IDM_VIEW_SWITCHTO_OTHER_VIEW,                 false, false, false, nullptr },

	{ VK_0,       IDM_VIEW_FOLDALL,                             false, true,  false, nullptr },
	{ VK_0,       IDM_VIEW_UNFOLDALL,                           false, true,  true,  nullptr },
	{ VK_F,       IDM_VIEW_FOLD_CURRENT,                        true,  true,  false, nullptr },
	{ VK_F,       IDM_VIEW_UNFOLD_CURRENT,                      true,  true,  true,  nullptr },
	{ VK_1,       IDM_VIEW_FOLD_1,                              false, true,  false, L"Fold Level 1" },
	{ VK_2,       IDM_VIEW_FOLD_2,                              false, true,  false, L"Fold Level 2" },
	{ VK_3,       IDM_VIEW_FOLD_3,                              false, true,  false, L"Fold Level 3" },
	{ VK_4,       IDM_VIEW_FOLD_4,                              false, true,  false, L"Fold Level 4" },
	{ VK_5,       IDM_VIEW_FOLD_5,                              false, true,  false, L"Fold Level 5" },
	{ VK_6,       IDM_VIEW_FOLD_6,                              false, true,  false, L"Fold Level 6" },
	{ VK_7,       IDM_VIEW_FOLD_7,                              false, true,  false, L"Fold Level 7" },
	{ VK_8,       IDM_VIEW_FOLD_8,                              false, true,  false, L"Fold Level 8" },

	{ VK_1,       IDM_VIEW_UNFOLD_1,                            false, true,  true,  L"Unfold Level 1" },
	{ VK_2,       IDM_VIEW_UNFOLD_2,                            false, true,  true,  L"Unfold Level 2" },
	{ VK_3,       IDM_VIEW_UNFOLD_3,                            false, true,  true,  L"Unfold Level 3" },
	{ VK_4,       IDM_VIEW_UNFOLD_4,                            false, true,  true,  L"Unfold Level 4" },
	{ VK_5,       IDM_VIEW_UNFOLD_5,                            false, true,  true,  L"Unfold Level 5" },
	{ VK_6,       IDM_VIEW_UNFOLD_6,                            false, true,  true,  L"Unfold Level 6" },
	{ VK_7,       IDM_VIEW_UNFOLD_7,                            false, true,  true,  L"Unfold Level 7" },
	{ VK_8,       IDM_VIEW_UNFOLD_8,                            false, true,  true,  L"Unfold Level 8" },
	{ VK_NULL,    IDM_VIEW_SUMMARY,                             false, false, false, nullptr },
	{ VK_NULL,    IDM_VIEW_PROJECT_PANEL_1,                     false, false, false, L"Toggle Project Panel 1" },
	{ VK_NULL,    IDM_VIEW_PROJECT_PANEL_2,                     false, false, false, L"Toggle Project Panel 2" },
	{ VK_NULL,    IDM_VIEW_PROJECT_PANEL_3,                     false, false, false, L"Toggle Project Panel 3" },
	{ VK_NULL,    IDM_VIEW_FILEBROWSER,                         false, false, false, L"Toggle Folder as Workspace" },
	{ VK_NULL,    IDM_VIEW_DOC_MAP,                             false, false, false, L"Toggle Document Map" },
	{ VK_NULL,    IDM_VIEW_DOCLIST,                             false, false, false, L"Toggle Document List" },
	{ VK_NULL,    IDM_VIEW_FUNC_LIST,                           false, false, false, L"Toggle Function List" },
	{ VK_NULL,    IDM_VIEW_SWITCHTO_PROJECT_PANEL_1,            false, false, false, L"Switch to Project Panel 1" },
	{ VK_NULL,    IDM_VIEW_SWITCHTO_PROJECT_PANEL_2,            false, false, false, L"Switch to Project Panel 2" },
	{ VK_NULL,    IDM_VIEW_SWITCHTO_PROJECT_PANEL_3,            false, false, false, L"Switch to Project Panel 3" },
	{ VK_NULL,    IDM_VIEW_SWITCHTO_FILEBROWSER,                false, false, false, L"Switch to Folder as Workspace" },
	{ VK_NULL,    IDM_VIEW_SWITCHTO_FUNC_LIST,                  false, false, false, L"Switch to Function List" },
	{ VK_NULL,    IDM_VIEW_SWITCHTO_DOCLIST,                    false, false, false, L"Switch to Document List" },
	{ VK_NULL,    IDM_VIEW_TAB_COLOUR_NONE,                     false, false, false, L"Remove Tab Colour" },
	{ VK_NULL,    IDM_VIEW_TAB_COLOUR_1,                        false, false, false, L"Apply Tab Colour 1" },
	{ VK_NULL,    IDM_VIEW_TAB_COLOUR_2,                        false, false, false, L"Apply Tab Colour 2" },
	{ VK_NULL,    IDM_VIEW_TAB_COLOUR_3,                        false, false, false, L"Apply Tab Colour 3" },
	{ VK_NULL,    IDM_VIEW_TAB_COLOUR_4,                        false, false, false, L"Apply Tab Colour 4" },
	{ VK_NULL,    IDM_VIEW_TAB_COLOUR_5,                        false, false, false, L"Apply Tab Colour 5" },
	{ VK_NULL,    IDM_VIEW_SYNSCROLLV,                          false, false, false, nullptr },
	{ VK_NULL,    IDM_VIEW_SYNSCROLLH,                          false, false, false, nullptr },
	{ VK_R,       IDM_EDIT_RTL,                                 true,  true,  false, nullptr },
	{ VK_L,       IDM_EDIT_LTR,                                 true,  true,  false, nullptr },
	{ VK_NULL,    IDM_VIEW_MONITORING,                          false, false, false, nullptr },

	{ VK_NULL,    IDM_FORMAT_ANSI,                              false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_AS_UTF_8,                          false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_UTF_8,                             false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_UTF_16BE,                          false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_UTF_16LE,                          false, false, false, nullptr },

	{ VK_NULL,    IDM_FORMAT_ISO_8859_6,                        false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_WIN_1256,                          false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_ISO_8859_13,                       false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_WIN_1257,                          false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_ISO_8859_14,                       false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_ISO_8859_5,                        false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_MAC_CYRILLIC,                      false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_KOI8R_CYRILLIC,                    false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_KOI8U_CYRILLIC,                    false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_WIN_1251,                          false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_WIN_1250,                          false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_DOS_437,                           false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_DOS_720,                           false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_DOS_737,                           false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_DOS_775,                           false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_DOS_850,                           false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_DOS_852,                           false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_DOS_855,                           false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_DOS_857,                           false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_DOS_858,                           false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_DOS_860,                           false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_DOS_861,                           false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_DOS_862,                           false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_DOS_863,                           false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_DOS_865,                           false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_DOS_866,                           false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_DOS_869,                           false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_BIG5,                              false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_GB2312,                            false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_ISO_8859_2,                        false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_ISO_8859_7,                        false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_WIN_1253,                          false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_ISO_8859_8,                        false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_WIN_1255,                          false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_SHIFT_JIS,                         false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_EUC_KR,                            false, false, false, nullptr },
	//{ VK_NULL,    IDM_FORMAT_ISO_8859_10,                       false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_ISO_8859_15,                       false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_ISO_8859_4,                        false, false, false, nullptr },
	//{ VK_NULL,    IDM_FORMAT_ISO_8859_16,                       false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_ISO_8859_3,                        false, false, false, nullptr },
	//{ VK_NULL,    IDM_FORMAT_ISO_8859_11,                       false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_TIS_620,                           false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_ISO_8859_9,                        false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_WIN_1254,                          false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_WIN_1252,                          false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_ISO_8859_1,                        false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_WIN_1258,                          false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_CONV2_ANSI,                        false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_CONV2_AS_UTF_8,                    false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_CONV2_UTF_8,                       false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_CONV2_UTF_16BE,                    false, false, false, nullptr },
	{ VK_NULL,    IDM_FORMAT_CONV2_UTF_16LE,                    false, false, false, nullptr },

	{ VK_NULL,    IDM_LANG_USER_DLG,                            false, false, false, nullptr },
	{ VK_NULL,    IDM_LANG_USER,                                false, false, false, nullptr },
	{ VK_NULL,    IDM_LANG_OPENUDLDIR,                          false, false, false, nullptr },

	{ VK_NULL,    IDM_SETTING_PREFERENCE,                       false, false, false, nullptr },
	{ VK_NULL,    IDM_LANGSTYLE_CONFIG_DLG,                     false, false, false, nullptr },
	{ VK_NULL,    IDM_SETTING_SHORTCUT_MAPPER,                  false, false, false, nullptr },
	{ VK_NULL,    IDM_SETTING_IMPORTPLUGIN,                     false, false, false, nullptr },
	{ VK_NULL,    IDM_SETTING_IMPORTSTYLETHEMES,                false, false, false, nullptr },
	{ VK_NULL,    IDM_SETTING_EDITCONTEXTMENU,                  false, false, false, nullptr },

	{ VK_R,       IDC_EDIT_TOGGLEMACRORECORDING,                true,  false, true,  L"Toggle macro recording" },
	{ VK_NULL,    IDM_MACRO_STARTRECORDINGMACRO,                false, false, false, nullptr },
	{ VK_NULL,    IDM_MACRO_STOPRECORDINGMACRO,                 false, false, false, nullptr },
	{ VK_P,       IDM_MACRO_PLAYBACKRECORDEDMACRO,              true,  false, true,  nullptr },
	{ VK_NULL,    IDM_MACRO_SAVECURRENTMACRO,                   false, false, false, nullptr },
	{ VK_NULL,    IDM_MACRO_RUNMULTIMACRODLG,                   false, false, false, nullptr },

	{ VK_F5,      IDM_EXECUTE,                                  false, false, false, nullptr },
	{ VK_NULL,    IDM_EXECUTE_VALIDATE_SHORTCUTSXML,            false, false, false, nullptr },

	{ VK_NULL,    IDM_WINDOW_WINDOWS,                           false, false, false, nullptr },
	{ VK_NULL,    IDM_WINDOW_SORT_FN_ASC,                       false, false, false, L"Sort by Name A to Z" },
	{ VK_NULL,    IDM_WINDOW_SORT_FN_DSC,                       false, false, false, L"Sort by Name Z to A" },
	{ VK_NULL,    IDM_WINDOW_SORT_FP_ASC,                       false, false, false, L"Sort by Path A to Z" },
	{ VK_NULL,    IDM_WINDOW_SORT_FP_DSC,                       false, false, false, L"Sort by Path Z to A" },
	{ VK_NULL,    IDM_WINDOW_SORT_FT_ASC,                       false, false, false, L"Sort by Type A to Z" },
	{ VK_NULL,    IDM_WINDOW_SORT_FT_DSC,                       false, false, false, L"Sort by Type Z to A" },
	{ VK_NULL,    IDM_WINDOW_SORT_FS_ASC,                       false, false, false, L"Sort by Content Length Ascending" },
	{ VK_NULL,    IDM_WINDOW_SORT_FS_DSC,                       false, false, false, L"Sort by Content Length Descending" },

	{ VK_NULL,    IDM_CMDLINEARGUMENTS,                         false, false, false, nullptr },
	{ VK_NULL,    IDM_HOMESWEETHOME,                            false, false, false, nullptr },
	{ VK_NULL,    IDM_PROJECTPAGE,                              false, false, false, nullptr },
	{ VK_NULL,    IDM_ONLINEDOCUMENT,                           false, false, false, nullptr },
	{ VK_NULL,    IDM_FORUM,                                    false, false, false, nullptr },
//	{ VK_NULL,    IDM_ONLINESUPPORT,                            false, false, false, nullptr },
//	{ VK_NULL,    IDM_PLUGINSHOME,                              false, false, false, nullptr },

	// The following two commands are not in menu if (nppGUI._doesExistUpdater == 0).
	// They cannot be derived from menu then, only for this reason the text is specified here.
	// In localized environments, the text comes preferably from xml Menu/Main/Commands.
	{ VK_NULL,    IDM_UPDATE_NPP,                               false, false, false, L"Update Notepad++" },
	{ VK_NULL,    IDM_CONFUPDATERPROXY,                         false, false, false, L"Set Updater Proxy..." },
	{ VK_NULL,    IDM_DEBUGINFO,                                false, false, false, nullptr },
	{ VK_F1,      IDM_ABOUT,                                    false, false, false, nullptr }
};



struct ScintillaKeyDefinition
{
	const wchar_t* name = nullptr;
	int functionId = 0;
	bool isCtrl = false;
	bool isAlt = false;
	bool isShift = false;
	int vKey = 0;
	int redirFunctionId = 0; // this gets set when a function is being redirected through Notepad++ if Scintilla doesn't do it properly :)
};

/*!
** \brief array of accelerator keys for all possible scintilla functions
**
** values can be 0 for vKey, which means its unused
*/
static constexpr ScintillaKeyDefinition scintKeyDefs[]
{
	//Scintilla command name,             SCINTILLA_CMD_ID,            Ctrl,  Alt,   Shift, V_KEY,       NOTEPAD++_CMD_ID
	// -------------------------------------------------------------------------------------------------------------------
	//
	//{L"SCI_CUT",                     SCI_CUT,                     true,  false, false, VK_X,        IDM_EDIT_CUT},
	//{L"",                            SCI_CUT,                     false, false, true,  VK_DELETE,   0},
	//{L"SCI_COPY",                    SCI_COPY,                    true,  false, false, VK_C,        IDM_EDIT_COPY},
	//{L"",                            SCI_COPY,                    true,  false, false, VK_INSERT,   0},
	//{L"SCI_PASTE",                   SCI_PASTE,                   true,  false, false, VK_V,        IDM_EDIT_PASTE},
	//{L"SCI_PASTE",                   SCI_PASTE,                   false, false, true,  VK_INSERT,   IDM_EDIT_PASTE},
	{L"SCI_SELECTALL",               SCI_SELECTALL,               true,  false, false, VK_A,        IDM_EDIT_SELECTALL},
	{L"SCI_CLEAR",                   SCI_CLEAR,                   false, false, false, VK_DELETE,   IDM_EDIT_DELETE},
	{L"SCI_CLEARALL",                SCI_CLEARALL,                false, false, false, 0,           0},
	{L"SCI_UNDO",                    SCI_UNDO,                    true,  false, false, VK_Z,        IDM_EDIT_UNDO},
	{L"",                            SCI_UNDO,                    false, true,  false, VK_BACK,     0},
	{L"SCI_REDO",                    SCI_REDO,                    true,  false, false, VK_Y,        IDM_EDIT_REDO},
	{L"",                            SCI_REDO,                    true,  false, true,  VK_Z,        0},
	{L"SCI_NEWLINE",                 SCI_NEWLINE,                 false, false, false, VK_RETURN,   0},
	{L"",                            SCI_NEWLINE,                 false, false, true,  VK_RETURN,   0},
	{L"SCI_TAB",                     SCI_TAB,                     false, false, false, VK_TAB,      0},
	{L"SCI_BACKTAB",                 SCI_BACKTAB,                 false, false, true,  VK_TAB,      0},
	{L"SCI_FORMFEED",                SCI_FORMFEED,                false, false, false, 0,           0},
	{L"SCI_ZOOMIN",                  SCI_ZOOMIN,                  true,  false, false, VK_ADD,      IDM_VIEW_ZOOMIN},
	{L"SCI_ZOOMOUT",                 SCI_ZOOMOUT,                 true,  false, false, VK_SUBTRACT, IDM_VIEW_ZOOMOUT},
	{L"SCI_SETZOOM",                 SCI_SETZOOM,                 true,  false, false, VK_DIVIDE,   IDM_VIEW_ZOOMRESTORE},
	{L"SCI_SELECTIONDUPLICATE",      SCI_SELECTIONDUPLICATE,      true,  false, false, VK_D,        0},
	{L"SCI_LINESJOIN",               SCI_LINESJOIN,               false, false, false, 0,           0},
	{L"SCI_SCROLLCARET",             SCI_SCROLLCARET,             false, false, false, 0,           0},
	{L"SCI_EDITTOGGLEOVERTYPE",      SCI_EDITTOGGLEOVERTYPE,      false, false, false, VK_INSERT,   0},
	{L"SCI_MOVECARETINSIDEVIEW",     SCI_MOVECARETINSIDEVIEW,     false, false, false, 0,           0},
	{L"SCI_LINEDOWN",                SCI_LINEDOWN,                false, false, false, VK_DOWN,     0},
	{L"SCI_LINEDOWNEXTEND",          SCI_LINEDOWNEXTEND,          false, false, true,  VK_DOWN,     0},
	{L"SCI_LINEDOWNRECTEXTEND",      SCI_LINEDOWNRECTEXTEND,      false, true,  true,  VK_DOWN,     0},
	{L"SCI_LINESCROLLDOWN",          SCI_LINESCROLLDOWN,          true,  false, false, VK_DOWN,     0},
	{L"SCI_LINEUP",                  SCI_LINEUP,                  false, false, false, VK_UP,       0},
	{L"SCI_LINEUPEXTEND",            SCI_LINEUPEXTEND,            false, false, true,  VK_UP,       0},
	{L"SCI_LINEUPRECTEXTEND",        SCI_LINEUPRECTEXTEND,        false, true,  true,  VK_UP,       0},
	{L"SCI_LINESCROLLUP",            SCI_LINESCROLLUP,            true,  false, false, VK_UP,       0},
	{L"SCI_PARADOWN",                SCI_PARADOWN,                true,  false, false, VK_OEM_6,    0},
	{L"SCI_PARADOWNEXTEND",          SCI_PARADOWNEXTEND,          true,  false, true,  VK_OEM_6,    0},
	{L"SCI_PARAUP",                  SCI_PARAUP,                  true,  false, false, VK_OEM_4,    0},
	{L"SCI_PARAUPEXTEND",            SCI_PARAUPEXTEND,            true,  false, true,  VK_OEM_4,    0},
	{L"SCI_CHARLEFT",                SCI_CHARLEFT,                false, false, false, VK_LEFT,     0},
	{L"SCI_CHARLEFTEXTEND",          SCI_CHARLEFTEXTEND,          false, false, true,  VK_LEFT,     0},
	{L"SCI_CHARLEFTRECTEXTEND",      SCI_CHARLEFTRECTEXTEND,      false, true,  true,  VK_LEFT,     0},
	{L"SCI_CHARRIGHT",               SCI_CHARRIGHT,               false, false, false, VK_RIGHT,    0},
	{L"SCI_CHARRIGHTEXTEND",         SCI_CHARRIGHTEXTEND,         false, false, true,  VK_RIGHT,    0},
	{L"SCI_CHARRIGHTRECTEXTEND",     SCI_CHARRIGHTRECTEXTEND,     false, true,  true,  VK_RIGHT,    0},
	{L"SCI_WORDLEFT",                SCI_WORDLEFT,                true,  false, false, VK_LEFT,     0},
	{L"SCI_WORDLEFTEXTEND",          SCI_WORDLEFTEXTEND,          true,  false, true,  VK_LEFT,     0},
	{L"SCI_WORDRIGHT",               SCI_WORDRIGHT,               true,  false, false, VK_RIGHT,    0},
	{L"SCI_WORDRIGHTEXTEND",         SCI_WORDRIGHTEXTEND,         false, false, false, 0,           0},
	{L"SCI_WORDLEFTEND",             SCI_WORDLEFTEND,             false, false, false, 0,           0},
	{L"SCI_WORDLEFTENDEXTEND",       SCI_WORDLEFTENDEXTEND,       false, false, false, 0,           0},
	{L"SCI_WORDRIGHTEND",            SCI_WORDRIGHTEND,            false, false, false, 0,           0},
	{L"SCI_WORDRIGHTENDEXTEND",      SCI_WORDRIGHTENDEXTEND,      true,  false, true,  VK_RIGHT,    0},
	{L"SCI_WORDPARTLEFT",            SCI_WORDPARTLEFT,            true,  false, false, VK_OEM_2,    0},
	{L"SCI_WORDPARTLEFTEXTEND",      SCI_WORDPARTLEFTEXTEND,      true,  false, true,  VK_OEM_2,    0},
	{L"SCI_WORDPARTRIGHT",           SCI_WORDPARTRIGHT,           true,  false, false, VK_OEM_5,    0},
	{L"SCI_WORDPARTRIGHTEXTEND",     SCI_WORDPARTRIGHTEXTEND,     true,  false, true,  VK_OEM_5,    0},
	{L"SCI_HOME",                    SCI_HOME,                    false, false, false, 0,           0},
	{L"SCI_HOMEEXTEND",              SCI_HOMEEXTEND,              false, false, false, 0,           0},
	{L"SCI_HOMERECTEXTEND",          SCI_HOMERECTEXTEND,          false, false, false, 0,           0},
	{L"SCI_HOMEDISPLAY",             SCI_HOMEDISPLAY,             false, true,  false, VK_HOME,     0},
	{L"SCI_HOMEDISPLAYEXTEND",       SCI_HOMEDISPLAYEXTEND,       false, false, false, 0,           0},
	{L"SCI_HOMEWRAP",                SCI_HOMEWRAP,                false, false, false, 0,           0},
	{L"SCI_HOMEWRAPEXTEND",          SCI_HOMEWRAPEXTEND,          false, false, false, 0,           0},
	{L"SCI_VCHOME",                  SCI_VCHOME,                  false, false, false, 0,           0},
	{L"SCI_VCHOMEEXTEND",            SCI_VCHOMEEXTEND,            false, false, false, 0,           0},
	{L"SCI_VCHOMERECTEXTEND",        SCI_VCHOMERECTEXTEND,        false, true,  true,  VK_HOME,     0},
	{L"SCI_VCHOMEDISPLAY",           SCI_VCHOMEDISPLAY,           false, false, false, 0,           0},
	{L"SCI_VCHOMEDISPLAYEXTEND",     SCI_VCHOMEDISPLAYEXTEND,     false, false, false, 0,           0},
	{L"SCI_VCHOMEWRAP",              SCI_VCHOMEWRAP,              false, false, false, VK_HOME,     0},
	{L"SCI_VCHOMEWRAPEXTEND",        SCI_VCHOMEWRAPEXTEND,        false, false, true,  VK_HOME,     0},
	{L"SCI_LINEEND",                 SCI_LINEEND,                 false, false, false, 0,           0},
	{L"SCI_LINEENDWRAPEXTEND",       SCI_LINEENDWRAPEXTEND,       false, false, true,  VK_END,      0},
	{L"SCI_LINEENDRECTEXTEND",       SCI_LINEENDRECTEXTEND,       false, true,  true,  VK_END,      0},
	{L"SCI_LINEENDDISPLAY",          SCI_LINEENDDISPLAY,          false, true,  false, VK_END,      0},
	{L"SCI_LINEENDDISPLAYEXTEND",    SCI_LINEENDDISPLAYEXTEND,    false, false, false, 0,           0},
	{L"SCI_LINEENDWRAP",             SCI_LINEENDWRAP,             false, false, false, VK_END,      0},
	{L"SCI_LINEENDEXTEND",           SCI_LINEENDEXTEND,           false, false, false, 0,           0},
	{L"SCI_DOCUMENTSTART",           SCI_DOCUMENTSTART,           true,  false, false, VK_HOME,     0},
	{L"SCI_DOCUMENTSTARTEXTEND",     SCI_DOCUMENTSTARTEXTEND,     true,  false, true,  VK_HOME,     0},
	{L"SCI_DOCUMENTEND",             SCI_DOCUMENTEND,             true,  false, false, VK_END,      0},
	{L"SCI_DOCUMENTENDEXTEND",       SCI_DOCUMENTENDEXTEND,       true,  false, true,  VK_END,      0},
	{L"SCI_PAGEUP",                  SCI_PAGEUP,                  false, false, false, VK_PRIOR,    0},
	{L"SCI_PAGEUPEXTEND",            SCI_PAGEUPEXTEND,            false, false, true,  VK_PRIOR,    0},
	{L"SCI_PAGEUPRECTEXTEND",        SCI_PAGEUPRECTEXTEND,        false, true,  true,  VK_PRIOR,    0},
	{L"SCI_PAGEDOWN",                SCI_PAGEDOWN,                false, false, false, VK_NEXT,     0},
	{L"SCI_PAGEDOWNEXTEND",          SCI_PAGEDOWNEXTEND,          false, false, true,  VK_NEXT,     0},
	{L"SCI_PAGEDOWNRECTEXTEND",      SCI_PAGEDOWNRECTEXTEND,      false, true,  true,  VK_NEXT,     0},
	{L"SCI_STUTTEREDPAGEUP",         SCI_STUTTEREDPAGEUP,         false, false, false, 0,           0},
	{L"SCI_STUTTEREDPAGEUPEXTEND",   SCI_STUTTEREDPAGEUPEXTEND,   false, false, false, 0,           0},
	{L"SCI_STUTTEREDPAGEDOWN",       SCI_STUTTEREDPAGEDOWN,       false, false, false, 0,           0},
	{L"SCI_STUTTEREDPAGEDOWNEXTEND", SCI_STUTTEREDPAGEDOWNEXTEND, false, false, false, 0,           0},
	{L"SCI_DELETEBACK",              SCI_DELETEBACK,              false, false, false, VK_BACK,     0},
	{L"",                            SCI_DELETEBACK,              false, false, true,  VK_BACK,     0},
	{L"SCI_DELETEBACKNOTLINE",       SCI_DELETEBACKNOTLINE,       false, false, false, 0,           0},
	{L"SCI_DELWORDLEFT",             SCI_DELWORDLEFT,             true,  false, false, VK_BACK,     0},
	{L"SCI_DELWORDRIGHT",            SCI_DELWORDRIGHT,            true,  false, false, VK_DELETE,   0},
	{L"SCI_DELLINELEFT",             SCI_DELLINELEFT,             true,  false, true,  VK_BACK,     0},
	{L"SCI_DELLINERIGHT",            SCI_DELLINERIGHT,            true,  false, true,  VK_DELETE,   0},
	{L"SCI_LINEDELETE",              SCI_LINEDELETE,              true,  false, true,  VK_L,        0},
	{L"SCI_LINECUT",                 SCI_LINECUT,                 true,  false, false, VK_L,        0},
	{L"SCI_LINECOPY",                SCI_LINECOPY,                true,  false, true,  VK_X,        0},
	{L"SCI_LINETRANSPOSE",           SCI_LINETRANSPOSE,           true,  false, false, VK_T,        0},
	{L"SCI_LINEDUPLICATE",           SCI_LINEDUPLICATE,           false, false, false, 0,           IDM_EDIT_DUP_LINE},
	{L"SCI_CANCEL",                  SCI_CANCEL,                  false, false, false, VK_ESCAPE,   0},
	{L"SCI_SWAPMAINANCHORCARET",     SCI_SWAPMAINANCHORCARET,     false, false, false, 0,           0},
	{L"SCI_ROTATESELECTION",         SCI_ROTATESELECTION,         false, false, false, 0,           0}
};

#define SHORTCUTSXML_FILENAME L"shortcuts.xml"
#define SHORTCUTSXML_MODEL_FILENAME L"shortcuts.model.xml"

#define CONTEXTMENUXML_FILENAME L"contextMenu.xml"
#define CONTEXTMENUXML_MODEL_FILENAME L"contextMenu.model.xml"

#define SESSION_BACKUP_EXT L".inCaseOfCorruption.bak"

using PGNSI = void (WINAPI*)(LPSYSTEM_INFO);

static int strVal(const char* str, int base)
{
	if (!str) return -1;
	if (!str[0]) return 0;

	char* finStr;
	const int result = std::strtol(str, &finStr, base);
	if (*finStr != '\0')
		return -1;
	return result;
}

static int hexStrVal(const char* str)
{
	return strVal(str, 16);
}

static int getKwClassFromName(const char* str)
{
	if(!str) return -1;
	if (std::strcmp(str, "instre1") == 0) return LANG_INDEX_INSTR;
	if (std::strcmp(str, "instre2") == 0) return LANG_INDEX_INSTR2;
	if (std::strcmp(str, "type1") == 0) return LANG_INDEX_TYPE;
	if (std::strcmp(str, "type2") == 0) return LANG_INDEX_TYPE2;
	if (std::strcmp(str, "type3") == 0) return LANG_INDEX_TYPE3;
	if (std::strcmp(str, "type4") == 0) return LANG_INDEX_TYPE4;
	if (std::strcmp(str, "type5") == 0) return LANG_INDEX_TYPE5;
	if (std::strcmp(str, "type6") == 0) return LANG_INDEX_TYPE6;
	if (std::strcmp(str, "type7") == 0) return LANG_INDEX_TYPE7;
	if (std::strcmp(str, "substyle1") == 0) return LANG_INDEX_SUBSTYLE1;
	if (std::strcmp(str, "substyle2") == 0) return LANG_INDEX_SUBSTYLE2;
	if (std::strcmp(str, "substyle3") == 0) return LANG_INDEX_SUBSTYLE3;
	if (std::strcmp(str, "substyle4") == 0) return LANG_INDEX_SUBSTYLE4;
	if (std::strcmp(str, "substyle5") == 0) return LANG_INDEX_SUBSTYLE5;
	if (std::strcmp(str, "substyle6") == 0) return LANG_INDEX_SUBSTYLE6;
	if (std::strcmp(str, "substyle7") == 0) return LANG_INDEX_SUBSTYLE7;
	if (std::strcmp(str, "substyle8") == 0) return LANG_INDEX_SUBSTYLE8;

	if ((str[1] == '\0') && (str[0] >= '0') && (str[0] <= '8')) // up to KEYWORDSET_MAX
		return str[0] - '0';

	return -1;
}

static constexpr DWORD RGBHEX(COLORREF color)
{
	return (((color & 0x0000FF) << 16) | ((color & 0x00FF00)) | ((color & 0xFF0000) >> 16));
}

} // anonymous namespace

enum class XmlAttrResult
{
	failed = -1,
	isFalse,
	isTrue
};

static constexpr std::array<const char*, 2> STR_BOOL_YESNO{ { "yes", "no" } };
static constexpr std::array<const char*, 2> STR_BOOL_SHOWHIDE{ { "show", "hide" } };

[[nodiscard]] static bool getBoolAttribute(const NppXml::Element& elem, const char* name, bool defaultVal = false, const std::array<const char*, 2>& strs2cmp = STR_BOOL_YESNO)
{
	const char* str = NppXml::attribute(elem, name);
	if (str)
	{
		if (std::strcmp(str, strs2cmp[0]) == 0)
			return true;
		if (std::strcmp(str, strs2cmp[1]) == 0)
			return false;
	}
	return defaultVal;
}

[[nodiscard]] static XmlAttrResult getResultAttribute(const NppXml::Element& elem, const char* name, const std::array<const char*, 2>& strs2cmp = STR_BOOL_YESNO)
{
	const char* str = NppXml::attribute(elem, name);
	if (str)
	{
		if (std::strcmp(str, strs2cmp[0]) == 0)
			return XmlAttrResult::isTrue;
		if (std::strcmp(str, strs2cmp[1]) == 0)
			return XmlAttrResult::isFalse;
	}
	return XmlAttrResult::failed;
}

template <typename T>
[[nodiscard]] static T getRangeClampAttribute(const NppXml::Element& elem, const char* name, T minVal, T maxVal, T defaultVal)
{
	const int val = NppXml::intAttribute(elem, name, static_cast<int>(defaultVal));
	if (val != static_cast<int>(defaultVal))
	{
		return static_cast<T>(std::max<int>(static_cast<int>(minVal), std::min<int>(val, static_cast<int>(maxVal))));
	}
	return defaultVal;
}

template <typename T>
[[nodiscard]] static T getRangeDefaultAttribute(const NppXml::Element& elem, const char* name, T minVal, T maxVal, T defaultVal)
{
	const int val = NppXml::intAttribute(elem, name, static_cast<int>(defaultVal));
	if (val < static_cast<int>(minVal))
		return defaultVal;
	if (val > static_cast<int>(maxVal))
		return defaultVal;
	return static_cast<T>(val);
}

static void setBoolAttribute(NppXml::Element& elem, const char* name, bool isTrue, const std::array<const char*, 2>& strs2set = STR_BOOL_YESNO)
{
	NppXml::setAttribute(elem, name, isTrue ? strs2set[0] : strs2set[1]);
}

[[nodiscard]] static bool getBoolChildTextNode(const NppXml::Element& elemParent, bool defaultVal = false, const std::array<const char*, 2>& strs2cmp = STR_BOOL_YESNO)
{
	NppXml::Node n = NppXml::firstChild(elemParent);
	if (n)
	{
		const char* val = NppXml::getValue(n);
		if (val)
		{
			if (std::strcmp(val, strs2cmp[0]) == 0)
				return true;
			if (std::strcmp(val, strs2cmp[1]) == 0)
				return false;
		}
	}
	return defaultVal;
}

[[nodiscard]] static XmlAttrResult getResultChildTextNode(const NppXml::Element& elemParent, const std::array<const char*, 2>& strs2cmp = STR_BOOL_YESNO)
{
	NppXml::Node n = NppXml::firstChild(elemParent);
	if (n)
	{
		const char* val = NppXml::getValue(n);
		if (val)
		{
			if (std::strcmp(val, strs2cmp[0]) == 0)
				return XmlAttrResult::isTrue;
			if (std::strcmp(val, strs2cmp[1]) == 0)
				return XmlAttrResult::isFalse;
		}
	}
	return XmlAttrResult::failed;
}

void cutString(const wchar_t* str2cut, std::vector<std::wstring>& patternVect)
{
	if (str2cut == nullptr) return;

	const wchar_t *pBegin = str2cut;
	const wchar_t *pEnd = pBegin;

	static const auto& loc = std::locale::classic();

	while (*pEnd != L'\0')
	{
		if (std::isspace(*pEnd, loc))
		{
			if (pBegin != pEnd)
				patternVect.emplace_back(pBegin, pEnd);
			pBegin = pEnd + 1;

		}
		++pEnd;
	}

	if (pBegin != pEnd)
		patternVect.emplace_back(pBegin, pEnd);
}

void cutStringBy(const wchar_t* str2cut, std::vector<std::wstring>& patternVect, wchar_t byChar, bool allowEmptyStr)
{
	if (str2cut == nullptr) return;

	const wchar_t* pBegin = str2cut;
	const wchar_t* pEnd = pBegin;

	while (*pEnd != L'\0')
	{
		if (*pEnd == byChar)
		{
			if (allowEmptyStr)
				patternVect.emplace_back(pBegin, pEnd);
			else if (pBegin != pEnd)
				patternVect.emplace_back(pBegin, pEnd);
			pBegin = pEnd + 1;
		}
		++pEnd;
	}
	if (allowEmptyStr)
		patternVect.emplace_back(pBegin, pEnd);
	else if (pBegin != pEnd)
		patternVect.emplace_back(pBegin, pEnd);
}


std::wstring LocalizationSwitcher::getLangFromXmlFileName(const wchar_t* fn)
{
	for (const auto& locDef : localizationDefs)
	{
		if (::_wcsicmp(fn, locDef._xmlFileName) == 0)
			return locDef._langName;
	}
	return L"";
}


std::wstring LocalizationSwitcher::getXmlFilePathFromLangName(const wchar_t *langName) const
{
	for (size_t i = 0, len = _localizationList.size(); i < len ; ++i)
	{
		if (_wcsicmp(langName, _localizationList[i].first.c_str()) == 0)
			return _localizationList[i].second;
	}
	return std::wstring();
}


bool LocalizationSwitcher::addLanguageFromXml(const std::wstring& xmlFullPath)
{
	const wchar_t * fn = ::PathFindFileNameW(xmlFullPath.c_str());
	const std::wstring foundLang = getLangFromXmlFileName(fn);
	if (!foundLang.empty())
	{
		_localizationList.emplace_back(foundLang, xmlFullPath);
		return true;
	}
	return false;
}


bool LocalizationSwitcher::switchToLang(const wchar_t *lang2switch) const
{
	const std::wstring langPath = getXmlFilePathFromLangName(lang2switch);
	if (langPath.empty())
		return false;

	return ::CopyFileW(langPath.c_str(), _nativeLangPath.c_str(), FALSE) != FALSE;
}


std::wstring ThemeSwitcher::getThemeFromXmlFileName(const wchar_t* xmlFullPath)
{
	if (!xmlFullPath || !xmlFullPath[0])
		return L"";
	std::wstring fn(::PathFindFileName(xmlFullPath));
	::PathRemoveExtension(fn.data());
	return fn;
}

int DynamicMenu::getTopLevelItemNumber() const
{
	int nb = 0;
	std::wstring previousFolderName;
	for (const MenuItemUnit& i : _menuItems)
	{
		if (i._parentFolderName.empty())
		{
			++nb;
		}
		else
		{
			if (previousFolderName.empty())
			{
				++nb;
				previousFolderName = i._parentFolderName;
			}
			else // previousFolderName is not empty
			{
				if (i._parentFolderName.empty())
				{
					++nb;
					previousFolderName = i._parentFolderName;
				}
				else if (previousFolderName == i._parentFolderName)
				{
					// maintain the number and do nothing
				}
				else
				{
					++nb;
					previousFolderName = i._parentFolderName;
				}
			}
		}
	}

	return nb;
}

bool DynamicMenu::attach(HMENU hMenu, unsigned int posBase, int lastCmd, const std::wstring& lastCmdLabel)
{
	if (!hMenu) return false;

	_hMenu = hMenu;
	_posBase = posBase;
	_lastCmd = lastCmd;
	_lastCmdLabel = lastCmdLabel;

	return createMenu();
}

bool DynamicMenu::clearMenu() const
{
	if (!_hMenu) return false;

	int nbTopItem = getTopLevelItemNumber();
	for (int i = nbTopItem + 1; i >= 0 ; --i)
	{
		::DeleteMenu(_hMenu, _posBase + i, MF_BYPOSITION);
	}

	return true;
}

bool DynamicMenu::createMenu() const
{
	if (!_hMenu) return false;

	bool lastIsSep = false;
	HMENU hParentFolder = NULL;
	std::wstring currentParentFolderStr;
	int j = 0;

	size_t nb = _menuItems.size();
	size_t i = 0;
	for (; i < nb; ++i)
	{
		const MenuItemUnit& item = _menuItems[i];
		if (item._parentFolderName.empty())
		{
			currentParentFolderStr.clear();
			hParentFolder = NULL;
			j = 0;
		}
		else
		{
			if (item._parentFolderName != currentParentFolderStr)
			{
				currentParentFolderStr = item._parentFolderName;
				hParentFolder = ::CreateMenu();
				j = 0;

				::InsertMenu(_hMenu, static_cast<UINT>(_posBase + i), MF_BYPOSITION | MF_POPUP, reinterpret_cast<UINT_PTR>(hParentFolder), currentParentFolderStr.c_str());
			}
		}

		unsigned int flag = MF_BYPOSITION | ((item._cmdID == 0) ? MF_SEPARATOR : 0);
		if (hParentFolder)
		{
			::InsertMenu(hParentFolder, j++, flag, item._cmdID, item._itemName.c_str());
			lastIsSep = false;
		}
		else if ((i == 0 || i == _menuItems.size() - 1) && item._cmdID == 0)
		{
			lastIsSep = true;
		}
		else if (item._cmdID != 0)
		{
			::InsertMenu(_hMenu, static_cast<UINT>(_posBase + i), flag, item._cmdID, item._itemName.c_str());
			lastIsSep = false;
		}
		else if (!lastIsSep)
		{
			::InsertMenu(_hMenu, static_cast<UINT>(_posBase + i), flag, item._cmdID, item._itemName.c_str());
			lastIsSep = true;
		}
		else // last item is separator and current item is separator
		{
			lastIsSep = true;
		}
	}

	if (nb > 0)
	{
		::InsertMenu(_hMenu, static_cast<UINT>(_posBase + i), MF_BYPOSITION | MF_SEPARATOR, 0, nullptr);
		::InsertMenu(_hMenu, static_cast<UINT>(_posBase + i + 2), MF_BYCOMMAND, _lastCmd, _lastCmdLabel.c_str());
	}

	return true;
}

winVer NppParameters::getWindowsVersion()
{
	OSVERSIONINFOEX osvi;
	SYSTEM_INFO si;
	PGNSI pGNSI;

	ZeroMemory(&si, sizeof(SYSTEM_INFO));
	ZeroMemory(&osvi, sizeof(OSVERSIONINFOEX));

	osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFOEX);
	const BOOL bOsVersionInfoEx = ::GetVersionExW(reinterpret_cast<OSVERSIONINFO*>(&osvi));
	if (!bOsVersionInfoEx)
	{
		osvi.dwOSVersionInfoSize = sizeof (OSVERSIONINFO);
		if (!::GetVersionExW(reinterpret_cast<OSVERSIONINFO*>(&osvi)))
			return WV_UNKNOWN;
	}

	pGNSI = reinterpret_cast<PGNSI>(::GetProcAddress(GetModuleHandle(L"kernel32.dll"), "GetNativeSystemInfo"));
	if (pGNSI != nullptr)
		pGNSI(&si);
	else
		GetSystemInfo(&si);

	switch (si.wProcessorArchitecture)
	{
	case PROCESSOR_ARCHITECTURE_IA64:
		_platForm = PF_IA64;
		break;

	case PROCESSOR_ARCHITECTURE_AMD64:
		_platForm = PF_X64;
		break;

	case PROCESSOR_ARCHITECTURE_INTEL:
		_platForm = PF_X86;
		break;

	case PROCESSOR_ARCHITECTURE_ARM64:
		_platForm = PF_ARM64;
		break;

	default:
		_platForm = PF_UNKNOWN;
	}

   switch (osvi.dwPlatformId)
   {
		case VER_PLATFORM_WIN32_NT:
		{
			if (osvi.dwMajorVersion == 10 && osvi.dwMinorVersion == 0 && osvi.dwBuildNumber >= 22000)
				return WV_WIN11;

			if (osvi.dwMajorVersion == 10 && osvi.dwMinorVersion == 0)
				return WV_WIN10;

			if (osvi.dwMajorVersion == 6 && osvi.dwMinorVersion == 3)
				return WV_WIN81;

			if (osvi.dwMajorVersion == 6 && osvi.dwMinorVersion == 2)
				return WV_WIN8;

			if (osvi.dwMajorVersion == 6 && osvi.dwMinorVersion == 1)
				return WV_WIN7;

			if (osvi.dwMajorVersion == 6 && osvi.dwMinorVersion == 0)
				return WV_VISTA;

			if (osvi.dwMajorVersion == 5 && osvi.dwMinorVersion == 2)
			{
				if (osvi.wProductType == VER_NT_WORKSTATION && si.wProcessorArchitecture==PROCESSOR_ARCHITECTURE_AMD64)
					return WV_XPX64;
				return WV_S2003;
			}

			if (osvi.dwMajorVersion == 5 && osvi.dwMinorVersion == 1)
				return WV_XP;

			if (osvi.dwMajorVersion == 5 && osvi.dwMinorVersion == 0)
				return WV_W2K;

			if (osvi.dwMajorVersion <= 4)
				return WV_NT;
			break;
		}

		// Test for the Windows Me/98/95.
		case VER_PLATFORM_WIN32_WINDOWS:
		{
			if (osvi.dwMajorVersion == 4 && osvi.dwMinorVersion == 0)
				return WV_95;

			if (osvi.dwMajorVersion == 4 && osvi.dwMinorVersion == 10)
				return WV_98;

			if (osvi.dwMajorVersion == 4 && osvi.dwMinorVersion == 90)
				return WV_ME;
			break;
		}

		case VER_PLATFORM_WIN32s:
			return WV_WIN32S;

		default:
			return WV_UNKNOWN;
   }

   return WV_UNKNOWN;
}


NppParameters::NppParameters()
{
	// Get windows version
	_winVersion = getWindowsVersion();

	// Get current system code page
	_currentSystemCodepage = GetACP();

	// Prepare for default path
	wchar_t nppPath[MAX_PATH];
	::GetModuleFileName(NULL, nppPath, MAX_PATH);

	PathRemoveFileSpec(nppPath);
	_nppPath = nppPath;

	//Initialize current directory to startup directory
	wchar_t curDir[MAX_PATH];
	::GetCurrentDirectory(MAX_PATH, curDir);
	_currentDirectory = curDir;

	_appdataNppDir.clear();
	std::wstring notepadStylePath(_nppPath);
	pathAppend(notepadStylePath, notepadStyleFile);

	_asNotepadStyle = (doesFileExist(notepadStylePath.c_str()) == TRUE);

	//Load initial accelerator key definitions
	initMenuKeys();
	initScintillaKeys();
}


NppParameters::~NppParameters()
{
	for (auto& docPath : _pXmlExternalLexerDoc)
	{
		delete docPath._doc;
		docPath._doc = nullptr;
	}

	_pXmlExternalLexerDoc.clear();
}


bool NppParameters::reloadStylers(const wchar_t* stylePath)
{
	delete _pXmlUserStylerDoc._doc;

	_pXmlUserStylerDoc._path = stylePath ? stylePath : _stylerPath.c_str();
	_pXmlUserStylerDoc._doc = new NppXml::NewDocument();

	const bool loadOkay = NppXml::loadFile(_pXmlUserStylerDoc._doc, _pXmlUserStylerDoc._path.c_str());
	if (!loadOkay)
	{
		if (!_pNativeLangSpeaker)
		{
			NppDarkMode::darkMessageBoxW(nullptr, _pXmlUserStylerDoc._path.c_str(), L"Load stylers.xml failed", MB_OK);
		}
		else
		{
			_pNativeLangSpeaker->messageBox("LoadStylersFailed",
				nullptr,
				L"Load \"$STR_REPLACE$\" failed!",
				L"Load stylers.xml failed",
				MB_OK,
				0,
				_pXmlUserStylerDoc._path.c_str());
		}
		delete _pXmlUserStylerDoc._doc;
		_pXmlUserStylerDoc._doc = nullptr;
		return false;
	}
	_lexerStylerVect.clear();
	_widgetStyleArray.clear();

	getUserStylersFromXmlTree();

	//  Reload plugin styles.
	for (size_t i = 0; i < getExternalLexerDoc()->size(); ++i)
	{
		NppXml::Document externalLexerDoc = getExternalLexerDoc()->at(i)._doc;
		NppXml::Element root = NppXml::firstChildElement(externalLexerDoc, "NotepadPlus");
		if (root)
			feedStylerArray(root);
	}
	return true;
}

bool NppParameters::reloadLang()
{
	// use user path
	std::wstring nativeLangPath(_localizationSwitcher._nativeLangPath);

	// if "nativeLang.xml" does not exist, use npp path
	if (!doesFileExist(nativeLangPath.c_str()))
	{
		nativeLangPath = _nppPath;
		pathAppend(nativeLangPath, std::wstring(L"nativeLang.xml"));
		if (!doesFileExist(nativeLangPath.c_str()))
			return false;
	}

	delete _pXmlNativeLangDoc;

	_pXmlNativeLangDoc = new NppXml::NewDocument();
	const bool loadOkay = NppXml::loadFileNativeLang(_pXmlNativeLangDoc, nativeLangPath.c_str());
	if (!loadOkay)
	{
		delete _pXmlNativeLangDoc;
		_pXmlNativeLangDoc = nullptr;
		return false;
	}
	return loadOkay;
}

std::wstring NppParameters::getSpecialFolderLocation(int folderKind)
{
	wchar_t path[MAX_PATH];
	const HRESULT specialLocationResult = SHGetFolderPath(nullptr, folderKind, nullptr, SHGFP_TYPE_CURRENT, path);

	std::wstring result;
	if (SUCCEEDED(specialLocationResult))
	{
		result = path;
	}
	return result;
}


std::wstring NppParameters::getSettingsFolder() const
{
	if (_isLocal)
		return _nppPath;

	std::wstring settingsFolderPath = getSpecialFolderLocation(CSIDL_APPDATA);

	if (settingsFolderPath.empty())
		return _nppPath;

	pathAppend(settingsFolderPath, L"Notepad++");
	return settingsFolderPath;
}


bool NppParameters::load()
{
	L_END = L_EXTERNAL;
	bool isAllLoaded = true;

	_isx64 = sizeof(void *) == 8;

	// Make localConf.xml path
	std::wstring localConfPath(_nppPath);
	pathAppend(localConfPath, localConfFile);

	// Test if doLocalConf.xml exists
	_isLocal = (doesFileExist(localConfPath.c_str()) == TRUE);

	// Under vista and windows 7, the usage of doLocalConf.xml is not allowed
	// if Notepad++ is installed in "program files" directory, because of UAC
	if (_isLocal)
	{
		// We check if OS is Vista or greater version
		if (_winVersion >= WV_VISTA)
		{
			std::wstring progPath = getSpecialFolderLocation(CSIDL_PROGRAM_FILES);
			wchar_t nppDirLocation[MAX_PATH];
			wcscpy_s(nppDirLocation, _nppPath.c_str());
			::PathRemoveFileSpec(nppDirLocation);

			if  (progPath == nppDirLocation)
				_isLocal = false;
		}
	}

	_pluginRootDir = _nppPath;
	pathAppend(_pluginRootDir, L"plugins");

	//
	// the 3rd priority: general default configuration
	//
	std::wstring nppPluginRootParent;
	if (_isLocal)
	{
		_userPath = nppPluginRootParent = _nppPath;
		_userPluginConfDir = _pluginRootDir;
		pathAppend(_userPluginConfDir, L"Config");
	}
	else
	{
		_userPath = getSpecialFolderLocation(CSIDL_APPDATA);

		pathAppend(_userPath, L"Notepad++");
		if (!doesDirectoryExist(_userPath.c_str()))
			::CreateDirectory(_userPath.c_str(), NULL);

		_appdataNppDir = _userPluginConfDir = _userPath;

		pathAppend(_userPluginConfDir, L"plugins");
		if (!doesDirectoryExist(_userPluginConfDir.c_str()))
			::CreateDirectory(_userPluginConfDir.c_str(), NULL);

		pathAppend(_userPluginConfDir, L"Config");
		if (!doesDirectoryExist(_userPluginConfDir.c_str()))
			::CreateDirectory(_userPluginConfDir.c_str(), NULL);

		// For PluginAdmin to launch the wingup with UAC
		setElevationRequired(true);
	}

	_pluginConfDir = _pluginRootDir; // for plugin list home
	pathAppend(_pluginConfDir, L"Config");

	if (!doesDirectoryExist(nppPluginRootParent.c_str()))
		::CreateDirectory(nppPluginRootParent.c_str(), NULL);
	if (!doesDirectoryExist(_pluginRootDir.c_str()))
		::CreateDirectory(_pluginRootDir.c_str(), NULL);

	_sessionPath = _userPath; // Session stores the absolute file path, it should never be on cloud

	// Detection cloud settings
	std::wstring cloudChoicePath{_userPath};
	cloudChoicePath += L"\\cloud\\choice";

	//
	// the 2nd priority: Cloud Choice Path
	//
	_isCloud = doesFileExist(cloudChoicePath.c_str());
	if (_isCloud)
	{
		// Read cloud choice
		std::wstring cloudChoiceStrW = L"";
		bool bLoadingFailed = false;
		std::string cloudChoiceStr = getFileContent(cloudChoicePath.c_str(), &bLoadingFailed);
		if (!bLoadingFailed)
		{
			WcharMbcsConvertor& wmc = WcharMbcsConvertor::getInstance();
			cloudChoiceStrW = wmc.char2wchar(cloudChoiceStr.c_str(), SC_CP_UTF8);
		}
		if (!cloudChoiceStrW.empty() && doesDirectoryExist(cloudChoiceStrW.c_str()))
		{
			_userPath = cloudChoiceStrW;
			_nppGUI._cloudPath = cloudChoiceStrW;
			_initialCloudChoice = _nppGUI._cloudPath;
		}
		else
		{
			_isCloud = false;
		}
	}

	//
	// the 1st priority: custom settings dir via command line argument
	//
	if (!_cmdSettingsDir.empty())
	{
		if (!doesDirectoryExist(_cmdSettingsDir.c_str()))
		{
			// The following text is not translatable.
			// _pNativeLangSpeaker is initialized AFTER _userPath being determined because nativeLang.xml is from _userPath.
			std::wstring errMsg = L"The given path\r";
			errMsg += _cmdSettingsDir;
			errMsg += L"\nvia command line \"-settingsDir=\" is not a valid directory.\rThis argument will be ignored.";
			NppDarkMode::darkMessageBoxW(nullptr, errMsg.c_str(), L"Invalid directory", MB_OK);
		}
		else
		{
			_userPath = _cmdSettingsDir;
			_sessionPath = _userPath; // reset session path
		}
	}

	//--------------------------//
	// langs.xml : for per-user //
	//--------------------------//
	std::wstring langs_xml_path(_userPath);
	pathAppend(langs_xml_path, L"langs.xml");

	std::wstring modelLangsPath(_nppPath);
	pathAppend(modelLangsPath, L"langs.model.xml");

	BOOL doRecover = FALSE;
	if (doesFileExist(langs_xml_path.c_str()))
	{
		WIN32_FILE_ATTRIBUTE_DATA attributes{};
		attributes.dwFileAttributes = INVALID_FILE_ATTRIBUTES;
		if (GetFileAttributesEx(langs_xml_path.c_str(), GetFileExInfoStandard, &attributes) != 0)
		{
			if (attributes.nFileSizeLow == 0 && attributes.nFileSizeHigh == 0)
			{
				if (_pNativeLangSpeaker)
				{
					doRecover = _pNativeLangSpeaker->messageBox("LoadLangsFailed",
						NULL,
						L"Load langs.xml failed!\rDo you want to recover your langs.xml?",
						L"Configurator",
						MB_YESNO);
				}
				else
				{
					doRecover = NppDarkMode::darkMessageBoxW(nullptr, L"Load langs.xml failed!\rDo you want to recover your langs.xml?", L"Configurator", MB_YESNO);
				}
			}
		}
	}
	else
		doRecover = true;

	if (doRecover)
	{
		::CopyFile(modelLangsPath.c_str(), langs_xml_path.c_str(), FALSE);
	}

	_pXmlDoc._path = langs_xml_path;
	_pXmlDoc._doc = new NppXml::NewDocument();

	bool loadOkay = NppXml::loadFile(_pXmlDoc._doc, _pXmlDoc._path.c_str());
	if (!loadOkay)
	{
		if (_pNativeLangSpeaker)
		{
			_pNativeLangSpeaker->messageBox("LoadLangsFailedFinal",
				NULL,
				L"Load langs.xml failed!",
				L"Configurator",
				MB_OK);
		}
		else
		{
			NppDarkMode::darkMessageBoxW(nullptr, L"Load langs.xml failed!", L"Configurator", MB_OK);
		}

		delete _pXmlDoc._doc;
		_pXmlDoc._doc = nullptr;
		isAllLoaded = false;
	}
	else
		getLangKeywordsFromXmlTree();


	//---------------------------//
	// config.xml : for per-user //
	//---------------------------//
	std::wstring configPath(_userPath);
	pathAppend(configPath, L"config.xml");

	std::wstring srcConfigPath(_nppPath);
	pathAppend(srcConfigPath, L"config.model.xml");

	if (!doesFileExist(configPath.c_str()))
		::CopyFile(srcConfigPath.c_str(), configPath.c_str(), FALSE);

	_xmlUserDoc._path = configPath;
	_xmlUserDoc._doc = new NppXml::NewDocument();
	loadOkay = NppXml::loadFile(_xmlUserDoc._doc, _xmlUserDoc._path.c_str());

	if (!loadOkay)
	{
		NppXml::createNewDeclaration(_xmlUserDoc._doc);
	}
	else
	{
		getUserParametersFromXmlTree();
	}

	//----------------------------//
	// stylers.xml : for per-user //
	//----------------------------//

	_stylerPath = _userPath;
	pathAppend(_stylerPath, L"stylers.xml");

	if (!doesFileExist(_stylerPath.c_str()))
	{
		std::wstring srcStylersPath(_nppPath);
		pathAppend(srcStylersPath, L"stylers.model.xml");
		::CopyFile(srcStylersPath.c_str(), _stylerPath.c_str(), TRUE);
	}

	if (_nppGUI._themeName.empty() || (!doesFileExist(_nppGUI._themeName.c_str())))
		_nppGUI._themeName.assign(_stylerPath);

	_pXmlUserStylerDoc._path = _nppGUI._themeName;
	_pXmlUserStylerDoc._doc = new NppXml::NewDocument();

	loadOkay = NppXml::loadFile(_pXmlUserStylerDoc._doc, _pXmlUserStylerDoc._path.c_str());
	if (!loadOkay)
	{
		if (_pNativeLangSpeaker)
		{
			_pNativeLangSpeaker->messageBox("LoadStylersFailed",
				NULL,
				L"Load \"$STR_REPLACE$\" failed!",
				L"Load stylers.xml failed",
				MB_OK,
				0,
				_stylerPath.c_str());
		}
		else
		{
			NppDarkMode::darkMessageBoxW(nullptr, _stylerPath.c_str(), L"Load stylers.xml failed", MB_OK);
		}
		delete _pXmlUserStylerDoc._doc;
		_pXmlUserStylerDoc._doc = nullptr;
		isAllLoaded = false;
	}
	else
		getUserStylersFromXmlTree();

	_themeSwitcher._stylesXmlPath = _stylerPath;
	// Firstly, add the default theme
	_themeSwitcher.addDefaultThemeFromXml(_stylerPath);

	//-----------------------------------//
	// userDefineLang.xml : for per-user //
	//-----------------------------------//
	_userDefineLangsFolderPath = _userDefineLangPath = _userPath;
	pathAppend(_userDefineLangPath, L"userDefineLang.xml");
	pathAppend(_userDefineLangsFolderPath, L"userDefineLangs");

	std::vector<std::wstring> udlFiles;
	getFilesInFolder(udlFiles, L"*.xml", _userDefineLangsFolderPath);

	_pXmlUserLangDoc._path = _userDefineLangPath;
	_pXmlUserLangDoc._doc = new NppXml::NewDocument();
	loadOkay = NppXml::loadFileUDL(_pXmlUserLangDoc._doc, _userDefineLangPath.c_str());
	if (!loadOkay)
	{
		delete _pXmlUserLangDoc._doc;
		_pXmlUserLangDoc._doc = nullptr;
		isAllLoaded = false;
	}
	else
	{
		auto r = addUserDefineLangsFromXmlTree(_pXmlUserLangDoc._doc);
		if (r.second - r.first > 0)
			_pXmlUserLangsDoc.emplace_back(_pXmlUserLangDoc._doc, _pXmlUserLangDoc._path, false, true, r);
	}

	for (const auto& i : udlFiles)
	{
		NppXml::Document udlDoc = new NppXml::NewDocument();
		loadOkay = NppXml::loadFileUDL(udlDoc, i.c_str());
		if (!loadOkay)
		{
			delete udlDoc;
		}
		else
		{
			auto r = addUserDefineLangsFromXmlTree(udlDoc);
			if (r.second - r.first > 0)
			{
				_pXmlUserLangsDoc.emplace_back(udlDoc, i, false, false, r);
			}
			else
			{
				delete udlDoc;
			}
		}
	}

	//----------------------------------------------//
	// nativeLang.xml : for per-user				//
	// In case of absence of user's nativeLang.xml, //
	// We'll look in the Notepad++ Dir.			    //
	//----------------------------------------------//

	std::wstring nativeLangPath;
	nativeLangPath = _userPath;
	pathAppend(nativeLangPath, L"nativeLang.xml");

	// LocalizationSwitcher should use always user path
	_localizationSwitcher._nativeLangPath = nativeLangPath;

	if (!_startWithLocFileName.empty()) // localization argument detected, use user wished localization
	{
		// overwrite nativeLangPath variable
		nativeLangPath = _nppPath;
		pathAppend(nativeLangPath, L"localization\\");
		pathAppend(nativeLangPath, _startWithLocFileName);
	}
	else // use %appdata% location, or (if absence then) npp installed location
	{
		if (!doesFileExist(nativeLangPath.c_str()))
		{
			nativeLangPath = _nppPath;
			pathAppend(nativeLangPath, L"nativeLang.xml");
		}
	}

	_pXmlNativeLangDoc = new NppXml::NewDocument();
	loadOkay = NppXml::loadFileNativeLang(_pXmlNativeLangDoc, nativeLangPath.c_str());
	if (!loadOkay)
	{
		delete _pXmlNativeLangDoc;
		_pXmlNativeLangDoc = nullptr;
		isAllLoaded = false;
	}

	//---------------------------------------//
	// toolbarButtonsConf.xml : for per-user //
	//---------------------------------------//
	std::wstring toolbarButtonsConfXmlPath(_userPath);
	pathAppend(toolbarButtonsConfXmlPath, L"toolbarButtonsConf.xml");

	_pXmlToolButtonsConfDoc = new NppXml::NewDocument();
	loadOkay = NppXml::loadFile(_pXmlToolButtonsConfDoc, toolbarButtonsConfXmlPath.c_str());
	if (!loadOkay)
	{
		delete _pXmlToolButtonsConfDoc;
		_pXmlToolButtonsConfDoc = nullptr;
		isAllLoaded = false;
	}

	//------------------------------//
	// shortcuts.xml : for per-user //
	//------------------------------//
	_shortcutsPath = _userPath;
	pathAppend(_shortcutsPath, SHORTCUTSXML_FILENAME);

	if (!doesFileExist(_shortcutsPath.c_str()))
	{
		std::wstring srcShortcutsPath(_nppPath);
		pathAppend(srcShortcutsPath, SHORTCUTSXML_MODEL_FILENAME);
		if (doesFileExist(srcShortcutsPath.c_str()))
			::CopyFile(srcShortcutsPath.c_str(), _shortcutsPath.c_str(), TRUE);
		else
			generateXmlFromScratch(_shortcutsPath.c_str(), SHORTCUT_XML_CONTENT);

		// Calculate the shortcuts.xml file HMAC to write it in config.xml for later integrity check

		std::string fileContent = getFileContent(_shortcutsPath.c_str());

		// Compute HMAC
		std::string machineGUID = getMachineGUID();
		_nppGUI._shortcutsOnDiskHmac = computeHMAC(machineGUID, fileContent);

		// For the HMAC of new copied or generated shortcuts.xml, store it in config.xml without any condition
		_nppGUI._shortcutsXmlHmacInConfig = _nppGUI._shortcutsOnDiskHmac;
	}
	else // shortcuts.xml already exists, keep tracking its HMAC for checking the integrity later
	{
		// Calculate the HMAC of shortcuts.xml on disk

		std::string fileContent = getFileContent(_shortcutsPath.c_str());

		// Compute HMAC
		std::string machineGUID = getMachineGUID();
		_nppGUI._shortcutsOnDiskHmac = computeHMAC(machineGUID, fileContent);
	}

	_pXmlShortcutDoc = new NppXml::NewDocument();
	loadOkay = NppXml::loadFileShortcut(_pXmlShortcutDoc, _shortcutsPath.c_str());
	if (!loadOkay)
	{
		delete _pXmlShortcutDoc;
		_pXmlShortcutDoc = nullptr;
		isAllLoaded = false;
	}
	else
	{
		getShortcutsFromXmlTree();
		getMacrosFromXmlTree();
		getUserCmdsFromXmlTree();

		// fill out _scintillaModifiedKeys :
		// those user-defined Scintilla keys will be used to remap the Scintilla Key Array
		getScintKeysFromXmlTree();
	}

	//--------------------------------//
	// contextMenu.xml : for per-user //
	//--------------------------------//
	_contextMenuPath = _userPath;
	pathAppend(_contextMenuPath, CONTEXTMENUXML_FILENAME);

	if (!doesFileExist(_contextMenuPath.c_str()))
	{
		std::wstring srcContextMenuPath(_nppPath);
		pathAppend(srcContextMenuPath, CONTEXTMENUXML_MODEL_FILENAME);

		if (doesFileExist(srcContextMenuPath.c_str()))
			::CopyFile(srcContextMenuPath.c_str(), _contextMenuPath.c_str(), TRUE);
		else
			generateXmlFromScratch(_contextMenuPath.c_str(), CONTEXTMENU_XML_CONTENT);
	}

	_pXmlContextMenuDoc = new NppXml::NewDocument();
	loadOkay = NppXml::loadFileContextMenu(_pXmlContextMenuDoc, _contextMenuPath.c_str());
	if (!loadOkay)
	{
		delete _pXmlContextMenuDoc;
		_pXmlContextMenuDoc = nullptr;
		isAllLoaded = false;
	}

	//---------------------------------------------//
	// tabContextMenu.xml : for per-user, optional //
	//---------------------------------------------//
	_tabContextMenuPath = _userPath;
	pathAppend(_tabContextMenuPath, L"tabContextMenu.xml");

	_pXmlTabContextMenuDoc = new NppXml::NewDocument();
	loadOkay = NppXml::loadFileContextMenu(_pXmlTabContextMenuDoc, _tabContextMenuPath.c_str());
	if (!loadOkay)
	{
		delete _pXmlTabContextMenuDoc;
		_pXmlTabContextMenuDoc = nullptr;
	}

	//-----------------------------------------------------------------------//
	// serverWhiteList.xml : for per-user                                    //
	// This xml file is optional - Notepad++ app or a user creates this file //
	// in order to automatically allow  files loading for predefined set     //
	// of safe net-servers, without asking for confirmation.                 //
	// This has to precede the session.xml loading.                          //
	//-----------------------------------------------------------------------//
	_serverWhiteListPath = _userPath;
	const std::wstring serverWhiteListFile = L"serverWhiteList.xml";
	pathAppend(_serverWhiteListPath, serverWhiteListFile);
	if (doesFileExist(_serverWhiteListPath.c_str()))
	{
		_pXmlServerWhiteListDoc = new NppXml::NewDocument();
		loadOkay = NppXml::loadFile(_pXmlServerWhiteListDoc, _serverWhiteListPath.c_str());
		if (!loadOkay)
		{
			delete _pXmlServerWhiteListDoc;
			_pXmlServerWhiteListDoc = nullptr;
		}
		else
		{
			bool isFileContentOk = false;
			NppXml::Element root = NppXml::firstChildElement(_pXmlServerWhiteListDoc, "NotepadPlus");
			if (root)
			{
				NppXml::Element childNode = NppXml::firstChildElement(root, "NetworkPathsAlwaysAction");
				if (childNode)
				{
					const std::string strValue = NppXml::attribute(childNode, "value");
					if (strValue.length() == 1)
					{
						switch (strValue[0])
						{
							case '?':
								_networkPathAlwaysAction = networkPathAlwaysAsk;
								isFileContentOk = true;
								break;
							case '!':
								_networkPathAlwaysAction = networkPathAlwaysSkip;
								isFileContentOk = true;
								break;
							case '*':
								_networkPathAlwaysAction = networkPathAlwaysLoad;
								isFileContentOk = true;
								break;
							default:
								// invalid, will be reset to default
								break;
						}
					}
				}
			}
			if (!isFileContentOk)
				makeDefaultServerWhiteList(true); // invalid content, reset to safe default
		}
	}

	//----------------------------//
	// session.xml : for per-user //
	//----------------------------//

	pathAppend(_sessionPath, L"session.xml");

	// Don't load session.xml if not required in order to speed up!!
	const NppGUI & nppGUI = (NppParameters::getInstance()).getNppGUI();
	if (nppGUI._rememberLastSession)
	{
		NppXml::Document pXmlSessionDoc = new NppXml::NewDocument();
		loadOkay = NppXml::loadFile(pXmlSessionDoc, _sessionPath.c_str());
		if (loadOkay)
		{
			loadOkay = getSessionFromXmlTree(pXmlSessionDoc, _session, _sessionPath, true);
		}

		if (!loadOkay)
		{
			std::wstring sessionInCaseOfCorruption_bak = _sessionPath;
			sessionInCaseOfCorruption_bak += SESSION_BACKUP_EXT;
			if (doesFileExist(sessionInCaseOfCorruption_bak.c_str()))
			{
				bool bFileSwapOk = false;
				if (doesFileExist(_sessionPath.c_str()))
				{
					// an invalid session.xml file exists
					bFileSwapOk = ::ReplaceFile(_sessionPath.c_str(), sessionInCaseOfCorruption_bak.c_str(), nullptr,
						REPLACEFILE_IGNORE_MERGE_ERRORS | REPLACEFILE_IGNORE_ACL_ERRORS, 0, 0);
				}
				else
				{
					// no session.xml file
					bFileSwapOk = ::MoveFileEx(sessionInCaseOfCorruption_bak.c_str(), _sessionPath.c_str(),
						MOVEFILE_REPLACE_EXISTING | MOVEFILE_COPY_ALLOWED | MOVEFILE_WRITE_THROUGH);
				}

				if (bFileSwapOk)
				{
					NppXml::Document pXmlSessionBackupDoc = new NppXml::NewDocument();
					loadOkay = NppXml::loadFile(pXmlSessionBackupDoc, _sessionPath.c_str());
					if (loadOkay)
						loadOkay = getSessionFromXmlTree(pXmlSessionBackupDoc, _session, _sessionPath, true);

					delete pXmlSessionBackupDoc;
				}

				if (!loadOkay)
					isAllLoaded = false; // either the backup file is also invalid or cannot be swapped with the session.xml
			}
			else
			{
				// no backup file
				isAllLoaded = false;
			}
		}

		delete pXmlSessionDoc;

		for (auto& extDoc : _pXmlExternalLexerDoc)
		{
			if (extDoc._doc)
			{
				delete extDoc._doc;
				extDoc._doc = nullptr;
			}
		}
	}

	std::wstring filePath, filePath2, issueFileName;
	//-------------------------------------------------------------//
	// nppLogNetworkDriveIssue.xml                                 //
	// This empty xml file is optional - user adds this empty file //
	// It's for debugging use only                                 //
	//-------------------------------------------------------------//
	filePath = _nppPath;
	issueFileName = nppLogNetworkDriveIssue;
	issueFileName += L".xml";
	pathAppend(filePath, issueFileName);
	_doNppLogNetworkDriveIssue = doesFileExist(filePath.c_str());
	if (!_doNppLogNetworkDriveIssue)
	{
		filePath2 = _userPath;
		pathAppend(filePath2, issueFileName);
		_doNppLogNetworkDriveIssue = doesFileExist(filePath2.c_str());
	}

	//-------------------------------------------------------------//
	// noRestartAutomatically.xml                                  //
	// This empty xml file is optional - user adds this empty file //
	// manually in order to prevent Notepad++ registration         //
	// for the Win10+ OS app-restart feature.                      //
	//-------------------------------------------------------------//
	filePath = _nppPath;
	std::wstring noRegForOSAppRestartTrigger = L"noRestartAutomatically.xml";
	pathAppend(filePath, noRegForOSAppRestartTrigger);
	_isRegForOSAppRestartDisabled = doesFileExist(filePath.c_str());
	if (!_isRegForOSAppRestartDisabled)
	{
		filePath = _userPath;
		pathAppend(filePath, noRegForOSAppRestartTrigger);
		_isRegForOSAppRestartDisabled = doesFileExist(filePath.c_str());
	}

	//-------------------------------------------------------------//
	// disableNppAutoUpdate.xml                                    //
	// This empty xml file is optional. If it exists, auto-update  //
	// will be disabled, even though WinGUp is present.            //
	//-------------------------------------------------------------//
	filePath = _nppPath;
	std::wstring disableNppAutoUpdateFileName = L"disableNppAutoUpdate.xml";
	pathAppend(filePath, disableNppAutoUpdateFileName);
	_isNppAutoUpdateDisabled = doesFileExist(filePath.c_str());

	return isAllLoaded;
}


void NppParameters::destroyInstance()
{
	delete _pXmlDoc._doc;
	delete _xmlUserDoc._doc;
	delete _pXmlUserStylerDoc._doc;

	//delete _pXmlUserLangDoc; will be deleted in the vector
	for (const auto& l : _pXmlUserLangsDoc)
	{
		delete l._udlXmlDoc;
	}

	if (_pXmlServerWhiteListDoc)
	{
		delete _pXmlServerWhiteListDoc;
		_pXmlServerWhiteListDoc = nullptr;
	}

	delete _pXmlNativeLangDoc;
	delete _pXmlToolButtonsConfDoc;
	delete _pXmlShortcutDoc;
	delete _pXmlContextMenuDoc;
	delete _pXmlTabContextMenuDoc;
	delete 	getInstancePointer();
}


void NppParameters::saveConfig_xml() const
{
	if (_xmlUserDoc._doc)
		static_cast<void>(NppXml::saveFile(_xmlUserDoc._doc, _xmlUserDoc._path.c_str()));
}


void NppParameters::setWorkSpaceFilePath(int i, const wchar_t* wsFile)
{
	if (i < 0 || i > 2 || !wsFile)
		return;
	_workSpaceFilePaths[i] = wsFile;
}


void NppParameters::removeTransparent(HWND hwnd)
{
	if (hwnd != nullptr)
		::SetWindowLongPtr(hwnd, GWL_EXSTYLE, ::GetWindowLongPtr(hwnd, GWL_EXSTYLE) & ~WS_EX_LAYERED);
}


void NppParameters::setTransparent(HWND hwnd, int percent)
{
	::SetWindowLongPtr(hwnd, GWL_EXSTYLE, ::GetWindowLongPtr(hwnd, GWL_EXSTYLE) | WS_EX_LAYERED);
	if (percent > 255)
		percent = 255;
	else if (percent < 0)
		percent = 0;
	::SetLayeredWindowAttributes(hwnd, 0, static_cast<BYTE>(percent), LWA_ALPHA);
}


bool NppParameters::isExistingExternalLangName(const char* newName) const
{
	if ((!newName) || (!newName[0]))
		return true;

	for (int i = 0 ; i < _nbExternalLang ; ++i)
	{
		if (_externalLangArray[i]->_name == newName)
			return true;
	}
	return false;
}


const wchar_t* NppParameters::getUserDefinedLangNameFromExt(const wchar_t* ext, const wchar_t* fullName) const
{
	if ((!ext) || (!ext[0]))
		return nullptr;

	std::vector<std::wstring> extVect;
	int iMatched = -1;
	for (int i = 0 ; i < _nbUserLang ; ++i)
	{
		extVect.clear();
		cutString(_userLangArray[i]->_ext.c_str(), extVect);

		// Force to use dark mode UDL in dark mode or to use  light mode UDL in light mode
		for (const auto& extStr : extVect)
		{
			if (::_wcsicmp(extStr.c_str(), ext) == 0 || (std::wcschr(fullName, L'.') && ::_wcsicmp(extStr.c_str(), fullName) == 0))
			{
				// preserve ext matched UDL
				iMatched = i;

				if (((NppDarkMode::isEnabled() && _userLangArray[i]->_isDarkModeTheme)) ||
					((!NppDarkMode::isEnabled() && !_userLangArray[i]->_isDarkModeTheme)))
					return _userLangArray[i]->_name.c_str();
			}
		}
	}

	// In case that we are in dark mode but no dark UDL or we are in light mode but no light UDL
	// We use it anyway
	if (iMatched >= 0)
	{
		return _userLangArray[iMatched]->_name.c_str();
	}

	return nullptr;
}


int NppParameters::getExternalLangIndexFromName(const wchar_t* externalLangName) const
{
	for (int i = 0 ; i < _nbExternalLang ; ++i)
	{
		if (externalLangName == string2wstring(_externalLangArray[i]->_name))
			return i;
	}
	return -1;
}


const UserLangContainer* NppParameters::getULCFromName(const wchar_t* userLangName) const
{
	for (int i = 0 ; i < _nbUserLang ; ++i)
	{
		if (userLangName == _userLangArray[i]->_name)
			return _userLangArray[i].get();
	}

	//qui doit etre jamais passer
	return nullptr;
}


COLORREF NppParameters::getCurLineHilitingColour()
{
	const Style* pStyle = _widgetStyleArray.findByName(L"Current line background colour");
	if (!pStyle)
		return static_cast<COLORREF>(-1);
	return pStyle->_bgColor;
}


void NppParameters::setCurLineHilitingColour(COLORREF colour2Set)
{
	Style * pStyle = _widgetStyleArray.findByName(L"Current line background colour");
	if (!pStyle)
		return;
	pStyle->_bgColor = colour2Set;
}



static int CALLBACK EnumFontFamExProc(const LOGFONT* lpelfe, const TEXTMETRIC*, DWORD, LPARAM lParam)
{
	auto& strVect = *reinterpret_cast<std::vector<std::wstring>*>(lParam);
	const auto vectSize = static_cast<int>(strVect.size());
	const wchar_t* lfFaceName = (reinterpret_cast<const ENUMLOGFONTEX*>(lpelfe))->elfLogFont.lfFaceName;

	//Search through all the fonts, EnumFontFamiliesEx never states anything about order
	//Start at the end though, that's the most likely place to find a duplicate
	for (int i = vectSize - 1; i >= 0; --i)
	{
		if (strVect[i] == lfFaceName)
			return 1;	//we already have seen this typeface, ignore it
	}

	//We can add the font
	//Add the face name and not the full name, we do not care about any styles
	strVect.push_back(lfFaceName);
	return 1; // I want to get all fonts
}


void NppParameters::setFontList(HWND hWnd)
{
	//---------------//
	// Sys font list //
	//---------------//
	LOGFONT lf{};
	_fontlist.clear();
	_fontlist.reserve(64); // arbitrary
	_fontlist.emplace_back(L"");

	lf.lfCharSet = DEFAULT_CHARSET;
	lf.lfFaceName[0]='\0';
	lf.lfPitchAndFamily = 0;
	HDC hDC = ::GetDC(hWnd);
	::EnumFontFamiliesEx(hDC, &lf, EnumFontFamExProc, reinterpret_cast<LPARAM>(&_fontlist), 0);
}

bool NppParameters::isInFontList(const std::wstring& fontName2Search) const
{
	if (fontName2Search.empty())
		return false;

	for (size_t i = 0, len = _fontlist.size(); i < len; i++)
	{
		if (_fontlist[i] == fontName2Search)
			return true;
	}
	return false;
}

void NppParameters::getLangKeywordsFromXmlTree()
{
	NppXml::Element root = NppXml::firstChildElement(_pXmlDoc._doc, "NotepadPlus");
	if (!root) return;
	updateFromModelXml(root, ConfXml::lang);	// updateKeyWordsFromModelXml(root);
	feedKeyWordsParameters(root);
}

void NppParameters::getExternalLexerFromXmlTree(NppXml::Document externalLexerDoc)
{
	NppXml::Element root = NppXml::firstChildElement(externalLexerDoc, "NotepadPlus");
	if (!root) return;
	feedKeyWordsParameters(root);
	feedStylerArray(root);
}


int NppParameters::addExternalLangToEnd(std::unique_ptr<ExternalLangContainer> externalLang)
{
	_externalLangArray[_nbExternalLang] = std::move(externalLang);
	++_nbExternalLang;
	++L_END;
	return _nbExternalLang - 1;
}


bool NppParameters::getUserStylersFromXmlTree()
{
	NppXml::Element root = NppXml::firstChildElement(_pXmlUserStylerDoc._doc, "NotepadPlus");
	if (!root)
		return false;

	addDefaultStyles(root);	// make sure that GlobalStyles > WidgetStyles has certain elements, allowing defaults to be populated based on other existing WidgetStyles if needed
	updateFromModelXml(root, ConfXml::styles);	// look for any WidgetStyles or LexerType>WordsStyles that are missing in the current XML and populate from Model if needed
	return feedStylerArray(root);	// transfer the XML data structure into Notepad++'s internal data structure
}


bool NppParameters::updateFromModelXml(NppXml::Element& rootUser, ConfXml whichConf)
{
	// Determine conf-specific information first
	std::wstring modelXmlFilename;
	NppXml::Document pXmlDocument = nullptr;
	std::string mainElementName;
	std::wstring docPath;
	switch (whichConf)
	{
		case ConfXml::lang:
		{
			modelXmlFilename = L"langs.model.xml";
			pXmlDocument = _pXmlDoc._doc;
			docPath = _pXmlDoc._path;
			mainElementName = "Languages";
			break;
		}
		case ConfXml::styles:
		{
			modelXmlFilename = L"stylers.model.xml";
			pXmlDocument = _pXmlUserStylerDoc._doc;
			docPath = _pXmlUserStylerDoc._path;
			mainElementName = "LexerStyles";
			break;
		}
		default:
		{
			// if it's an unknown config file, return immediately, as there's nothing to do
			return false;
		}
	}

	// Need the name of the XML model document
	std::wstring modelXmlPath(_nppPath);
	pathAppend(modelXmlPath, modelXmlFilename);

	// compare the *.model.xml's filesystem "modified" timestamp (date only) to the value stored in the user file modelFileLastModifiedDate attribute
	const int userModelLastModifDate = NppXml::intAttribute(rootUser, "modelFileLastModifiedDate", 0);

	// read the actual timestamp from the model file; if there's a problem reading the attributes, just exit out (don't need to warn the user, since the main XML has already been loaded)
	WIN32_FILE_ATTRIBUTE_DATA attributes{};
	if (!::GetFileAttributesExW(modelXmlPath.c_str(), GetFileExInfoStandard, &attributes))
		return false;

	int modifiedDate = 0;
	if (!fileTimeToYMD(attributes.ftLastWriteTime, modifiedDate))
		return false;

	// if modifiedDate is not later than user stored model timestamp, no need to check more.
	// Note: in case of absence of attribute "modelModifDate", userModelModifTimestamp will be 0
	if (userModelLastModifDate >= modifiedDate)
		return false;

	// update immediately the modelModifDate stored in the active XML
	NppXml::setAttribute(rootUser, "modelFileLastModifiedDate", modifiedDate);

	// At this point, need to parse the model file
	// if there's a problem loading the model XML, just exit out (don't need to warn the user, since the main XML has already been loaded
	// the same logic will be used for any other errors while trying to do this XML merge)
	NppXml::Document pXmlModel = new NppXml::NewDocument();

	auto handleErrorThenExit = [&]() {
		switch (whichConf)
		{
			case ConfXml::lang:
			{
				static_cast<void>(NppXml::saveFile(pXmlDocument, docPath.c_str()));
				break;
			}
			case ConfXml::styles:
			{
				writeStyles(_lexerStylerVect, _widgetStyleArray);
				break;
			}
		}

		delete pXmlModel;
		return false;
	};

	if (!NppXml::loadFile(pXmlModel, modelXmlPath.c_str()))
	{
		return handleErrorThenExit();
	}

	NppXml::Element rootModel = NppXml::firstChildElement(pXmlModel, "NotepadPlus");
	if (!rootModel)
	{
		return handleErrorThenExit();
	}

	// compare the *.model.xml's modelDate to that of the active XML
	const int v_model = NppXml::intAttribute(rootModel, "modelDate", 0);

	if (v_model == 0) // in case modelDate is absent in *.model.xml, no update will happen
	{
		return handleErrorThenExit();
	}

	const int v_user = NppXml::intAttribute(rootUser, "modelDate", 0);

	// v_user is 0 when "modelDate" is absent.
	if (v_user >= v_model)
	{
		return handleErrorThenExit();
	}

	// update (or add) the modelDate stored in the active XML
	NppXml::setAttribute(rootUser, "modelDate", v_model);

	// get the main internal <Languages> element from both user and model
	NppXml::Element mainElemUser = NppXml::firstChildElement(rootUser, mainElementName.c_str());
	NppXml::Element mainElemModel = NppXml::firstChildElement(rootModel, mainElementName.c_str());
	if (!mainElemUser || !mainElemModel)
	{
		return handleErrorThenExit();
	}

	switch (whichConf)
	{
		case ConfXml::lang:
		{
			updateLangXml(mainElemUser, mainElemModel);
			static_cast<void>(NppXml::saveFile(pXmlDocument, docPath.c_str()));
			break;
		}
		case ConfXml::styles:
		{
			updateStylesXml(rootUser, docPath, rootModel, mainElemUser, mainElemModel);
			writeStyles(_lexerStylerVect, _widgetStyleArray);
			break;
		}
	}

	delete pXmlModel;
	return true;
}

void NppParameters::updateLangXml(NppXml::Element& mainElemUser, const NppXml::Element& mainElemModel)
{
	// map each of the user-file's languages -> element-pointer, to keep track of the languages already in the user-file
	std::map<std::string, NppXml::Element> mapUserLanguages{};
	for (NppXml::Element langFromUser = NppXml::firstChildElement(mainElemUser, "Language");
		langFromUser;
		langFromUser = NppXml::nextSiblingElement(langFromUser, "Language"))
	{
		const char* languageName = NppXml::attribute(langFromUser, "name");
		if (languageName)
			mapUserLanguages[languageName] = langFromUser;
	}

	// for each language in the Model,
	for (NppXml::Element langFromModel = NppXml::firstChildElement(mainElemModel, "Language");
		langFromModel;
		langFromModel = NppXml::nextSiblingElement(langFromModel, "Language"))
	{
		std::string modelLanguageName = NppXml::attribute(langFromModel, "name", "");
		if (modelLanguageName.empty())
			continue;

		// see if language already exists in UserLanguages
		if (mapUserLanguages.contains(modelLanguageName))
		{
			// if so, see if I need to update individual entries

			// first, enumerate each keywords name -> element pointer, so I know what's already there
			std::map<std::string, NppXml::Element> mapUserKeywords{};
			for (NppXml::Element keywordsFromUser = NppXml::firstChildElement(mapUserLanguages[modelLanguageName], "Keywords");
				keywordsFromUser;
				keywordsFromUser = NppXml::nextSiblingElement(keywordsFromUser, "Keywords"))
			{
				const char* keywordsName = NppXml::attribute(keywordsFromUser, "name");
				if (keywordsName)
					mapUserKeywords[keywordsName] = keywordsFromUser;
			}

			// then, for each Keywords entry in the model, check to see if it already exists in the user list
			for (NppXml::Element keywordsFromModel = NppXml::firstChildElement(langFromModel, "Keywords");
				keywordsFromModel;
				keywordsFromModel = NppXml::nextSiblingElement(keywordsFromModel, "Keywords"))
			{
				const char* modelKwName = NppXml::attribute(keywordsFromModel, "name");
				std::string modelKeywordsName = modelKwName ? modelKwName : "";
				if (modelKeywordsName.empty())
					continue;

				// does this Keywords element exist in User already?
				if (mapUserKeywords.contains(modelKeywordsName))
				{
					// if Keywords element in user langs.xml, need to check to see if any words are missing from its contents

					// start by extracting the list of words in the user version of this Keywords element
					NppXml::Node pKwsValue = NppXml::firstChild(mapUserKeywords[modelKeywordsName]);
					std::string sText = pKwsValue ? NppXml::getValue(pKwsValue) : "";
					std::vector<std::string> vsUserWords{};
					std::map<std::string, bool> mapUserWords{};
					if (!sText.empty())
					{
						std::string sToken;
						std::istringstream strm(sText);
						while (strm >> sToken)
						{
							vsUserWords.push_back(sToken);
							mapUserWords[sToken] = true;
						}
					}

					// then go through each word in the model, and add it to the list if it's not already there
					int nWordsAdded = 0;
					NppXml::Node pKwsValueModel = NppXml::firstChild(keywordsFromModel);
					std::string sTextModel = pKwsValueModel ? NppXml::getValue(pKwsValueModel) : "";
					if (!pKwsValue)
					{
						if (pKwsValueModel)
						{
							NppXml::insertEndChild(mapUserKeywords[modelKeywordsName], pKwsValueModel);
						}
					}
					else
					{
						if (!sTextModel.empty())
						{
							std::string sToken;
							std::istringstream strm(sTextModel);
							while (strm >> sToken)
							{
								if (!mapUserWords.contains(sToken))
								{
									vsUserWords.push_back(sToken);
									++nWordsAdded;
								}
							}
						}

						// if there were any words added to the list, need to update the element contents
						if (nWordsAdded)
						{
							// sort the words in standard case-sensitive alphabetical order
							std::sort(vsUserWords.begin(), vsUserWords.end());

							// convert that list into space-separated string, with at most 8000 characters per line
							size_t lineLength = 0;
							static constexpr size_t maxLineLength = 8000;
							bool first = true;
							std::string sOutputWords;
							for (const auto& sWord : vsUserWords)
							{
								if (!first)
								{
									// space between words
									sOutputWords += " ";
									lineLength += 1;
								}
								first = false;

								if (lineLength + sWord.length() >= maxLineLength)
								{
									// start next line
									lineLength = 0;
									sOutputWords += "\n                ";
								}

								// add this word to the output string
								sOutputWords += sWord;
								lineLength += sWord.length();
							}

							// and update the XML's value
							NppXml::setValue(pKwsValue, sOutputWords);
						}
					}
				}
				else
				{
					// if this Keywords element doesn't exist in user list, need to clone it from model to the right parent language in the user list
					NppXml::insertEndChild(mapUserLanguages[modelLanguageName], keywordsFromModel);
				}
			}

			// Also, since <Language name="..." ...> can have other attributes, need to check to make sure that
			// the user langs copy of language isn't missing any of the attributes from the model
			NppXml::Element thisLanguageFromUser = mapUserLanguages[modelLanguageName];
			for (NppXml::Attribute attrModel = NppXml::firstAttribute(langFromModel);
				attrModel;
				attrModel = NppXml::next(attrModel))
			{
				// if attribute not in user, need to add it (but leave it alone if the user-langs has it, but is just an empty string, because that's intentionally blank)
				const char* attrName = NppXml::getName(attrModel);
				const char* pcUserValue = NppXml::attribute(thisLanguageFromUser, attrName);
				if (!pcUserValue)
					NppXml::setAttribute(thisLanguageFromUser, attrName, NppXml::getValue(attrModel));
				else if (std::strcmp(attrName, "ext") == 0)
				{
					// Get both user and model values for the ext attribute
					std::string sExtValues = std::string(pcUserValue) + " " + NppXml::getValue(attrModel);
					std::string sExtUpdated;
					std::map<std::string, bool> isExtDone{};
					std::string sToken;
					std::istringstream strm(sExtValues);
					while (strm >> sToken)
					{
						if (!isExtDone.contains(sToken))
						{
							if (!sExtUpdated.empty())
								sExtUpdated += " ";
							sExtUpdated += sToken;
							isExtDone[sToken] = true;
						}
					}
					NppXml::setAttribute(thisLanguageFromUser, attrName, sExtUpdated);
				}
			}
		}
		else
		{
			// otherwise, since Language doesn't exist in User Languages, need to duplicate/clone from model to user-langs structure
			NppXml::insertEndChild(mainElemUser, langFromModel);
		}
	}

	return;
}

void NppParameters::updateStylesXml(const NppXml::Element& rootUser, const std::wstring& userDocPath, const NppXml::Element& rootModel, NppXml::Element& mainElemUser, const NppXml::Element& mainElemModel)
{
	std::string defaultFgColor, defaultBgColor;

	auto endsWith = [](std::wstring const& fullString, std::wstring const& suffix) -> bool
	{
		if (fullString.length() >= suffix.length())
		{
			// Compare the last 'suffix.length()' characters of 'fullString' with 'suffix'
			return fullString.compare(fullString.length() - suffix.length(), suffix.length(), suffix) == 0;
		}
		else
		{
			return false;
		}
	};
	const bool useDefaultColors = !endsWith(userDocPath, L"stylers.xml"); // use the Colors from "Default Style", except when it's stylers.xml

	// Start with GlobalStyles
	//		(even though it comes later in the actual XML file, need to be able to extract the defaultFgColor and defaultBgColor before doing the individual lexers)
	NppXml::Element gsUser = NppXml::firstChildElement(rootUser, "GlobalStyles");
	NppXml::Element gsModel = NppXml::firstChildElement(rootModel, "GlobalStyles");
	if (!gsUser || !gsModel)
		return;

	// map UserStyler's widget styleID||name -> node-pointer
	std::map<std::string, NppXml::Element> mapUserWidgets{};
	for (NppXml::Element widgetFromUser = NppXml::firstChildElement(gsUser, "WidgetStyle");
		widgetFromUser;
		widgetFromUser = NppXml::nextSiblingElement(widgetFromUser, "WidgetStyle"))
	{
		// use StyleID for the map's key, or if styleID not found or if "0" then use the widget's name (lowercase) instead
		const int styleID = NppXml::intAttribute(widgetFromUser, "styleID", 0);
		std::string widgetKey;
		if (styleID > 0 && styleID <= 256)
			widgetKey = std::to_string(styleID);
		else
			widgetKey = NppXml::attribute(widgetFromUser, "name");

		// add widget to map using the key
		if (!widgetKey.empty())
		{
			mapUserWidgets[widgetKey] = widgetFromUser;

			// save the colors from <WidgetStyle name="Default Style" styleID="32" ...>
			if (widgetKey == "32")
			{
				defaultFgColor = NppXml::attribute(widgetFromUser, "fgColor");
				defaultBgColor = NppXml::attribute(widgetFromUser, "bgColor");
			}
		}
	}

	// for each WidgetStyle in the model,
	for (NppXml::Element widgetFromModel = NppXml::firstChildElement(gsModel, "WidgetStyle");
		widgetFromModel;
		widgetFromModel = NppXml::nextSiblingElement(widgetFromModel, "WidgetStyle"))
	{
		// extract the key
		const int styleID = NppXml::intAttribute(widgetFromModel, "styleID", 0);
		std::string widgetKey;
		if (styleID > 0 && styleID <= 256)
			widgetKey = std::to_string(styleID);
		else if (const char* name = NppXml::attribute(widgetFromModel, "name"); name)
			widgetKey = name;

		if (widgetKey.empty())
			continue;

		// see if WidgetStyle already exists in UserStyles
		if (mapUserWidgets.contains(widgetKey))
		{
			// if so, see if I need to update individual attributes
			for (NppXml::Attribute attrModel = NppXml::firstAttribute(widgetFromModel);
				attrModel;
				attrModel = NppXml::next(attrModel))
			{
				// if attribute not in user, need to add it (but leave it alone if it's there but an empty string, because then it's intentionally set blank)
				const char* attrName = NppXml::getName(attrModel);
				const char* pcUserValue = NppXml::attribute(mapUserWidgets[widgetKey], attrName);
				if (!pcUserValue)
				{
					NppXml::setAttribute(mapUserWidgets[widgetKey], attrName, NppXml::getValue(attrModel));

					if (useDefaultColors)
					{
						// override the value from the model file with the default value, for fgColor and bgColor only
						if (std::strcmp(attrName, "fgColor") == 0)
							NppXml::setAttribute(mapUserWidgets[widgetKey], attrName, defaultFgColor);
						else if (std::strcmp(attrName, "bgColor") == 0)
							NppXml::setAttribute(mapUserWidgets[widgetKey], attrName, defaultBgColor);
					}
				}
			}
		}
		else
		{
			// otherwise, need to duplicate/clone from model to userStyles
			NppXml::Element p_cloneElement = NppXml::insertEndChild(gsUser, widgetFromModel);

			// if using the default colors, need to override fgColor and bgColor
			if (useDefaultColors)
			{
				if (NppXml::attribute(p_cloneElement, "fgColor"))
					NppXml::setAttribute(p_cloneElement, "fgColor", defaultFgColor);
				if (NppXml::attribute(p_cloneElement, "bgColor"))
					NppXml::setAttribute(p_cloneElement, "bgColor", defaultBgColor);
			}
		}
	}


	// map UserStyler's lexer name -> element-pointer
	std::map<std::string, NppXml::Element> mapUserLexers{};
	for (NppXml::Element lexerFromUser = NppXml::firstChildElement(mainElemUser, "LexerType");
		lexerFromUser;
		lexerFromUser = NppXml::nextSiblingElement(lexerFromUser, "LexerType"))
	{
		const char* lexerName = NppXml::attribute(lexerFromUser, "name");
		if (lexerName)
			mapUserLexers[lexerName] = lexerFromUser;
	}

	// For each lexer in the model,
	for (NppXml::Element lexerFromModel = NppXml::firstChildElement(mainElemModel, "LexerType");
		lexerFromModel;
		lexerFromModel = NppXml::nextSiblingElement(lexerFromModel, "LexerType"))
	{
		const char* modelLexerName = NppXml::attribute(lexerFromModel, "name");
		
		if (!modelLexerName)
			continue;

		// map styleID numbers: index will be the target dot-js ID, intermediate index is fgColor/bgColor, stored value will be the source embedded-javascript color string
		std::map <std::string, std::map<std::string, std::string>> mapColorsEmbeddedToDotJs;
		if (std::strcmp(modelLexerName, "javascript.js") == 0 && mapUserLexers.contains("javascript"))
		{
			NppXml::Element srcEmbeddedLexer = mapUserLexers["javascript"];

			// iterate through each embedded WordsStyle element
			for (NppXml::Element embeddedWordsStyle = NppXml::firstChildElement(srcEmbeddedLexer, "WordsStyle");
				embeddedWordsStyle;
				embeddedWordsStyle = NppXml::nextSiblingElement(embeddedWordsStyle, "WordsStyle"))
			{
				const char* embeddedID = NppXml::attribute(embeddedWordsStyle, "styleID");
				const char* embeddedFG = NppXml::attribute(embeddedWordsStyle, "fgColor");
				const char* embeddedBG = NppXml::attribute(embeddedWordsStyle, "bgColor");
				if (embeddedID)
				{
					auto do_embedded_to_dot_js_map = [](std::map <std::string, std::map<std::string, std::string>>&colorid_map, const std::string& dotjs_id, const std::string& emb_id_desired, const char* embID, const char* embFG, const char* embBG) {
						if (emb_id_desired == embID)
						{
							if (embFG)
								colorid_map[dotjs_id]["fgColor"] = embFG;
							if (embBG)
								colorid_map[dotjs_id]["bgColor"] = embBG;
						}
					};
					do_embedded_to_dot_js_map(mapColorsEmbeddedToDotJs, "11", "41", embeddedID, embeddedFG, embeddedBG);    // get DOTJS::DEFAULT from EMBEDDED::DEFAULT
					do_embedded_to_dot_js_map(mapColorsEmbeddedToDotJs, "4", "45", embeddedID, embeddedFG, embeddedBG);     // get DOTJS::NUMBER from EMBEDDED::NUMBER
					do_embedded_to_dot_js_map(mapColorsEmbeddedToDotJs, "16", "46", embeddedID, embeddedFG, embeddedBG);    // get DOTJS::TYPE_WORD<type1> from EMBEDDED::WORD
					do_embedded_to_dot_js_map(mapColorsEmbeddedToDotJs, "5", "47", embeddedID, embeddedFG, embeddedBG);     // get DOTJS::INSTRUCTION_WORD <instre1> from EMBEDDED::KEYWORD <instre1>
					do_embedded_to_dot_js_map(mapColorsEmbeddedToDotJs, "19", "47", embeddedID, embeddedFG, embeddedBG);    // get DOTJS::WINDOW_INSTRUCTION <instre2> also from EMBEDDED::KEYWORD <instre1> (there isn't 1:1 mapping, so multiple .js styles inherit from from same embedded style)
					do_embedded_to_dot_js_map(mapColorsEmbeddedToDotJs, "6", "48", embeddedID, embeddedFG, embeddedBG);     // get DOTJS::STRING from EMBEDDED::DOUBLE STRING
					do_embedded_to_dot_js_map(mapColorsEmbeddedToDotJs, "20", "48", embeddedID, embeddedFG, embeddedBG);    // get DOTJS::STRING_RAW also from EMBEDDED::DOUBLE STRING
					do_embedded_to_dot_js_map(mapColorsEmbeddedToDotJs, "7", "49", embeddedID, embeddedFG, embeddedBG);     // get DOTJS::CHARACTER from EMBEDDED::SINGLE STRING
					do_embedded_to_dot_js_map(mapColorsEmbeddedToDotJs, "10", "50", embeddedID, embeddedFG, embeddedBG);    // get DOTJS::OPERATOR from EMBEDDED::SYMBOLS
					do_embedded_to_dot_js_map(mapColorsEmbeddedToDotJs, "14", "52", embeddedID, embeddedFG, embeddedBG);    // get DOTJS::REGEX from EMBEDDED::REGEX
					do_embedded_to_dot_js_map(mapColorsEmbeddedToDotJs, "1", "42", embeddedID, embeddedFG, embeddedBG);     // get DOTJS::COMMENT from EMBEDDED::COMMENT
					do_embedded_to_dot_js_map(mapColorsEmbeddedToDotJs, "2", "43", embeddedID, embeddedFG, embeddedBG);     // get DOTJS::COMMENT LINE from EMBEDDED::COMMENT LINE
					do_embedded_to_dot_js_map(mapColorsEmbeddedToDotJs, "3", "44", embeddedID, embeddedFG, embeddedBG);     // get DOTJS::COMMENT DOC from EMBEDDED::COMMENT DOC
					do_embedded_to_dot_js_map(mapColorsEmbeddedToDotJs, "15", "44", embeddedID, embeddedFG, embeddedBG);    // get DOTJS::COMMENT LINE DOC also from EMBEDDED::COMMENT DOC
					do_embedded_to_dot_js_map(mapColorsEmbeddedToDotJs, "17", "44", embeddedID, embeddedFG, embeddedBG);    // get DOTJS::COMMENT LINE DOC also from EMBEDDED::COMMENT DOC
					do_embedded_to_dot_js_map(mapColorsEmbeddedToDotJs, "18", "44", embeddedID, embeddedFG, embeddedBG);    // get DOTJS::COMMENT DOC KEYWORD also from EMBEDDED::COMMENT DOC
					do_embedded_to_dot_js_map(mapColorsEmbeddedToDotJs, "19", "44", embeddedID, embeddedFG, embeddedBG);    // get DOTJS::COMMENT DOC KEYWORD ERROR also from EMBEDDED::COMMENT DOC
					do_embedded_to_dot_js_map(mapColorsEmbeddedToDotJs, "128", "200", embeddedID, embeddedFG, embeddedBG);  // get DOTJS::USER* from EMBEDDED::USER*
					do_embedded_to_dot_js_map(mapColorsEmbeddedToDotJs, "129", "201", embeddedID, embeddedFG, embeddedBG);  // get DOTJS::USER* from EMBEDDED::USER*
					do_embedded_to_dot_js_map(mapColorsEmbeddedToDotJs, "130", "202", embeddedID, embeddedFG, embeddedBG);  // get DOTJS::USER* from EMBEDDED::USER*
					do_embedded_to_dot_js_map(mapColorsEmbeddedToDotJs, "131", "203", embeddedID, embeddedFG, embeddedBG);  // get DOTJS::USER* from EMBEDDED::USER*
					do_embedded_to_dot_js_map(mapColorsEmbeddedToDotJs, "132", "204", embeddedID, embeddedFG, embeddedBG);  // get DOTJS::USER* from EMBEDDED::USER*
					do_embedded_to_dot_js_map(mapColorsEmbeddedToDotJs, "133", "205", embeddedID, embeddedFG, embeddedBG);  // get DOTJS::USER* from EMBEDDED::USER*
					do_embedded_to_dot_js_map(mapColorsEmbeddedToDotJs, "134", "206", embeddedID, embeddedFG, embeddedBG);  // get DOTJS::USER* from EMBEDDED::USER*
					do_embedded_to_dot_js_map(mapColorsEmbeddedToDotJs, "135", "207", embeddedID, embeddedFG, embeddedBG);  // get DOTJS::USER* from EMBEDDED::USER*
				}
			}
		}

		// see if lexer already exists in UserStyles
		if (mapUserLexers.contains(modelLexerName))
		{
			// if so, see if I need to update individual entries

			// first, enumerate each words-style ID -> element-pointer, so I know what's already there
			std::map<std::string, NppXml::Element> mapUserWordsStyles{};
			for (NppXml::Element wordsStyleFromUser = NppXml::firstChildElement(mapUserLexers[modelLexerName], "WordsStyle");
				wordsStyleFromUser;
				wordsStyleFromUser = NppXml::nextSiblingElement(wordsStyleFromUser, "WordsStyle"))
			{
				const char* wordsStyleID = NppXml::attribute(wordsStyleFromUser, "styleID");
				if (wordsStyleID)
					mapUserWordsStyles[wordsStyleID] = wordsStyleFromUser;
			}

			// then, for each words-style in the Model, check to see if it already exists in the user list
			for (NppXml::Element wordsStyleFromModel = NppXml::firstChildElement(lexerFromModel, "WordsStyle");
				wordsStyleFromModel;
				wordsStyleFromModel = NppXml::nextSiblingElement(wordsStyleFromModel, "WordsStyle"))
			{
				std::string modelWordsStyleID = NppXml::attribute(wordsStyleFromModel, "styleID", "");
				if (modelWordsStyleID.empty())
					continue;

				// does it exist in User already?
				if (mapUserWordsStyles.contains(modelWordsStyleID))
				{
					// if already exists, check for missing attributes

					// need the element from user, to be able to check its attributes against the model's attributes
					NppXml::Element elementFromUser = mapUserWordsStyles[modelWordsStyleID];

					// loop through each attribute in the model's element
					for (NppXml::Attribute attrModel = NppXml::firstAttribute(wordsStyleFromModel);
						attrModel;
						attrModel = NppXml::next(attrModel))
					{
						// if attribute not in user, need to add it (but leave it alone if it's there but an empty string, because then it's intentionally set blank)
						const char* attrName = NppXml::getName(attrModel);
						const char* pcUserValue = NppXml::attribute(elementFromUser, attrName);
						if (!pcUserValue)
						{
							NppXml::setAttribute(elementFromUser, attrName, NppXml::getValue(attrModel));

							if (useDefaultColors)
							{
								std::string newFg = defaultFgColor;
								std::string newBg = defaultBgColor;
								std::string dest_id = NppXml::attribute(elementFromUser, "styleID", "");
								if (!dest_id.empty() && mapColorsEmbeddedToDotJs.contains(dest_id))
								{
									//std::string src_id = mapColorsEmbeddedToDotJs[dest_id];
									if (std::strcmp(attrName, "fgColor") == 0 && mapColorsEmbeddedToDotJs[dest_id].contains(attrName))
										newFg =  mapColorsEmbeddedToDotJs[dest_id][attrName];
									if (std::strcmp(attrName, "bgColor") == 0 && mapColorsEmbeddedToDotJs[dest_id].contains(attrName))
										newBg = mapColorsEmbeddedToDotJs[dest_id][attrName];
								}

								// override the value from the model file with the default value, for fgColor and bgColor only
								if (std::strcmp(attrName, "fgColor") == 0)
									NppXml::setAttribute(elementFromUser, attrName, newFg);
								else if (std::strcmp(attrName, "bgColor") == 0)
									NppXml::setAttribute(elementFromUser, attrName, newBg);
							}
						}
					}
				}
				else
				{
					// if WordsStyle doesn't exist, need to clone it from model to the right parent lexer in the user list
					NppXml::Element p_cloneElement = NppXml::insertEndChild(mapUserLexers[modelLexerName], wordsStyleFromModel);

					// if using the default colors, need to override fgColor and bgColor
					if (useDefaultColors)
					{
						std::string newFg = defaultFgColor;
						std::string newBg = defaultBgColor;
						std::string dest_id = NppXml::attribute(p_cloneElement, "styleID", "");
						if (!dest_id.empty() && mapColorsEmbeddedToDotJs.contains(dest_id))
						{
							if (NppXml::attribute(p_cloneElement, "fgColor") && mapColorsEmbeddedToDotJs[dest_id].contains("fgColor"))
								newFg = mapColorsEmbeddedToDotJs[dest_id]["fgColor"];
							if (NppXml::attribute(p_cloneElement, "bgColor") && mapColorsEmbeddedToDotJs[dest_id].contains("bgColor"))
								newBg = mapColorsEmbeddedToDotJs[dest_id]["bgColor"];
						}

						if (NppXml::attribute(p_cloneElement, "fgColor"))
							NppXml::setAttribute(p_cloneElement, "fgColor", newFg);
						if (NppXml::attribute(p_cloneElement, "bgColor"))
							NppXml::setAttribute(p_cloneElement, "bgColor", newBg);
					}
				}
			}
		}
		else
		{
			// otherwise, if Lexer doesn't exist in the userStyles, need to duplicate/clone from model to userStyles
			NppXml::Node p_clone = NppXml::insertEndChild(mainElemUser, lexerFromModel);

			if (useDefaultColors)
			{
				std::string newFg = defaultFgColor;
				std::string newBg = defaultBgColor;

				// iterate through all WordsStyle in the clone, and override fg and bg colors as needed
				for (NppXml::Element wordsStyleFromClone = NppXml::firstChildElement(p_clone, "WordsStyle");
					wordsStyleFromClone;
					wordsStyleFromClone = NppXml::nextSiblingElement(wordsStyleFromClone, "WordsStyle"))
				{
					std::string dest_id = NppXml::attribute(wordsStyleFromClone, "styleID", "");
					if (!dest_id.empty() && mapColorsEmbeddedToDotJs.contains(dest_id))
					{
						if (NppXml::attribute(wordsStyleFromClone, "fgColor") && mapColorsEmbeddedToDotJs[dest_id].contains("fgColor"))
							newFg = mapColorsEmbeddedToDotJs[dest_id]["fgColor"];
						if (NppXml::attribute(wordsStyleFromClone, "bgColor") && mapColorsEmbeddedToDotJs[dest_id].contains("bgColor"))
							newBg = mapColorsEmbeddedToDotJs[dest_id]["bgColor"];
					}

					if (NppXml::attribute(wordsStyleFromClone, "fgColor"))
						NppXml::setAttribute(wordsStyleFromClone, "fgColor", newFg);
					if (NppXml::attribute(wordsStyleFromClone, "bgColor"))
						NppXml::setAttribute(wordsStyleFromClone, "bgColor", newBg);
				}
			}
		}
	}

	// Ensure searchResult LexerType is always the last child of mainElemUser,
	// regardless of where it appeared in the original XML or where new entries
	// were appended during the merge above.
	NppXml::Element searchResultNode;
	for (NppXml::Element lexerNode = NppXml::firstChildElement(mainElemUser, "LexerType");
		lexerNode;
		lexerNode = NppXml::nextSiblingElement(lexerNode, "LexerType"))
	{
		const char* name = NppXml::attribute(lexerNode, "name");
		if (name && std::strcmp(name, "searchResult") == 0)
		{
			searchResultNode = lexerNode;
			break;
		}
	}

	if (searchResultNode)
	{
		NppXml::deleteChild(mainElemUser, searchResultNode);
		NppXml::insertEndChild(mainElemUser, searchResultNode);
	}

	return;
}

bool NppParameters::getUserParametersFromXmlTree()
{
	if (!_xmlUserDoc._doc)
		return false;

	NppXml::Element root = NppXml::firstChildElement(_xmlUserDoc._doc, "NotepadPlus");
	if (!root)
		return false;

	// Get GUI parameters
	feedGUIParameters(root);

	// Get History parameters
	feedFileListParameters(root);

	// Erase the History root
	NppXml::Element histRoot = NppXml::firstChildElement(root, "History");
	NppXml::deleteChild(root, histRoot);

	// Add a new empty History root
	NppXml::createChildElement(root, "History");

	//Get Find history parameters
	feedFindHistoryParameters(root);

	//Get Project Panel parameters
	feedProjectPanelsParameters(root);

	//Get File browser parameters
	feedFileBrowserParameters(root);

	//Get Column editor parameters
	feedColumnEditorParameters(root);

	return true;
}


std::pair<unsigned char, unsigned char> NppParameters::addUserDefineLangsFromXmlTree(NppXml::Document xmldoc)
{
	if (!xmldoc)
		return std::make_pair(static_cast<unsigned char>(0), static_cast<unsigned char>(0));

	NppXml::Element root = NppXml::firstChildElement(xmldoc, "NotepadPlus");
	if (!root)
		return std::make_pair(static_cast<unsigned char>(0), static_cast<unsigned char>(0));

	return feedUserLang(root);
}



bool NppParameters::getShortcutsFromXmlTree()
{
	if (!_pXmlShortcutDoc)
		return false;

	NppXml::Element root = NppXml::firstChildElement(_pXmlShortcutDoc, "NotepadPlus");
	if (!root)
		return false;

	feedShortcut(root);
	return true;
}


bool NppParameters::getMacrosFromXmlTree()
{
	if (!_pXmlShortcutDoc)
		return false;

	NppXml::Element root = NppXml::firstChildElement(_pXmlShortcutDoc, "NotepadPlus");
	if (!root)
		return false;

	feedMacros(root);
	return true;
}


bool NppParameters::getUserCmdsFromXmlTree()
{
	if (!_pXmlShortcutDoc)
		return false;

	NppXml::Element root = NppXml::firstChildElement(_pXmlShortcutDoc, "NotepadPlus");
	if (!root)
		return false;

	feedUserCmds(root);
	return true;
}


bool NppParameters::getPluginCmdsFromXmlTree()
{
	if (!_pXmlShortcutDoc)
		return false;

	NppXml::Element root = NppXml::firstChildElement(_pXmlShortcutDoc, "NotepadPlus");
	if (!root)
		return false;

	feedPluginCustomizedCmds(root);
	return true;
}


bool NppParameters::getScintKeysFromXmlTree()
{
	if (!_pXmlShortcutDoc)
		return false;

	NppXml::Element root = NppXml::firstChildElement(_pXmlShortcutDoc, "NotepadPlus");
	if (!root)
		return false;

	feedScintKeys(root);
	return true;
}

void NppParameters::initMenuKeys()
{
	int previousFuncID = 0;
	for (const auto& wkd : winKeyDefs)
	{
		Shortcut sc((wkd.specialName ? wstring2string(wkd.specialName).c_str() : ""), wkd.isCtrl, wkd.isAlt, wkd.isShift, static_cast<unsigned char>(wkd.vKey));
		_shortcuts.emplace_back(sc, wkd.functionId, previousFuncID == wkd.functionId);
		previousFuncID = wkd.functionId;
	}
}

void NppParameters::initScintillaKeys()
{
	//Warning! Matching function have to be consecutive
	int prevIndex = -1;
	int prevID = -1;
	for (const auto& skd : scintKeyDefs)
	{
		if (skd.functionId == prevID)
		{
			KeyCombo kc;
			kc._isCtrl = skd.isCtrl;
			kc._isAlt = skd.isAlt;
			kc._isShift = skd.isShift;
			kc._key = static_cast<unsigned char>(skd.vKey);
			_scintillaKeyCommands[prevIndex].addKeyCombo(kc);
		}
		else
		{
			Shortcut s = Shortcut(wstring2string(skd.name).c_str(), skd.isCtrl, skd.isAlt, skd.isShift, static_cast<unsigned char>(skd.vKey));
			_scintillaKeyCommands.emplace_back(s, skd.functionId, skd.redirFunctionId);
			++prevIndex;
		}
		prevID = skd.functionId;
	}
}

bool NppParameters::reloadContextMenuFromXmlTree(HMENU mainMenuHandle, HMENU pluginsMenu)
{
	_contextMenuItems.clear();
	return getContextMenuFromXmlTree(mainMenuHandle, pluginsMenu);
}

int NppParameters::getCmdIdFromMenuEntryItemName(HMENU mainMenuHandle, const std::wstring& menuEntryName, const std::wstring& menuItemName)
{
	int nbMenuEntry = ::GetMenuItemCount(mainMenuHandle);
	for (int i = 0; i < nbMenuEntry; ++i)
	{
		wchar_t menuEntryString[menuItemStrLenMax];
		::GetMenuString(mainMenuHandle, i, menuEntryString, menuItemStrLenMax, MF_BYPOSITION);
		if (_wcsicmp(menuEntryName.c_str(), purgeMenuItemString(menuEntryString).c_str()) == 0)
		{
			std::vector<std::pair<HMENU, int>> parentMenuPos;
			HMENU topMenu = ::GetSubMenu(mainMenuHandle, i);
			int maxTopMenuPos = ::GetMenuItemCount(topMenu);
			HMENU currMenu = topMenu;
			int currMaxMenuPos = maxTopMenuPos;

			int currMenuPos = 0;
			bool notFound = false;

			do {
				if (::GetSubMenu(currMenu, currMenuPos))
				{
					//  Go into sub menu
					parentMenuPos.emplace_back(currMenu, currMenuPos);
					currMenu = ::GetSubMenu(currMenu, currMenuPos);
					currMenuPos = 0;
					currMaxMenuPos = ::GetMenuItemCount(currMenu);
				}
				else
				{
					//  Check current menu position.
					wchar_t cmdStr[menuItemStrLenMax];
					::GetMenuString(currMenu, currMenuPos, cmdStr, menuItemStrLenMax, MF_BYPOSITION);
					if (_wcsicmp(menuItemName.c_str(), purgeMenuItemString(cmdStr).c_str()) == 0)
					{
						return ::GetMenuItemID(currMenu, currMenuPos);
					}

					if ((currMenuPos >= currMaxMenuPos) && (parentMenuPos.size() > 0))
					{
						currMenu = parentMenuPos.back().first;
						currMenuPos = parentMenuPos.back().second;
						parentMenuPos.pop_back();
						currMaxMenuPos = ::GetMenuItemCount(currMenu);
					}

					if ((currMenu == topMenu) && (currMenuPos >= maxTopMenuPos))
					{
						notFound = true;
					}
					else
					{
						++currMenuPos;
					}
				}
			} while (!notFound);
		}
	}
	return -1;
}

int NppParameters::getPluginCmdIdFromMenuEntryItemName(HMENU pluginsMenu, const std::wstring& pluginName, const std::wstring& pluginCmdName)
{
	int nbPlugins = ::GetMenuItemCount(pluginsMenu);
	for (int i = 0; i < nbPlugins; ++i)
	{
		wchar_t menuItemString[menuItemStrLenMax];
		::GetMenuString(pluginsMenu, i, menuItemString, menuItemStrLenMax, MF_BYPOSITION);
		if (_wcsicmp(pluginName.c_str(), purgeMenuItemString(menuItemString).c_str()) == 0)
		{
			HMENU pluginMenu = ::GetSubMenu(pluginsMenu, i);
			int nbPluginCmd = ::GetMenuItemCount(pluginMenu);
			for (int j = 0; j < nbPluginCmd; ++j)
			{
				wchar_t pluginCmdStr[menuItemStrLenMax];
				::GetMenuString(pluginMenu, j, pluginCmdStr, menuItemStrLenMax, MF_BYPOSITION);
				if (_wcsicmp(pluginCmdName.c_str(), purgeMenuItemString(pluginCmdStr).c_str()) == 0)
				{
					return ::GetMenuItemID(pluginMenu, j);
				}
			}
		}
	}
	return -1;
}

bool NppParameters::getContextMenuFromXmlTree(HMENU mainMenuHandle, HMENU pluginsMenu, bool isEditCM)
{
	NppXml::Document pXmlContextMenuDoc = isEditCM ? _pXmlContextMenuDoc : _pXmlTabContextMenuDoc;
	std::string cmName = isEditCM ? "ScintillaContextMenu" : "TabContextMenu";

	if (!pXmlContextMenuDoc)
		return false;
	NppXml::Element root = NppXml::firstChildElement(pXmlContextMenuDoc, "NotepadPlus");
	if (!root)
		return false;

	WcharMbcsConvertor& wmc = WcharMbcsConvertor::getInstance();
	NativeLangSpeaker* pNativeSpeaker = (NppParameters::getInstance()).getNativeLangSpeaker();

	NppXml::Element contextMenuRoot = NppXml::firstChildElement(root, cmName.c_str());
	if (contextMenuRoot)
	{
		std::vector<MenuItemUnit>& contextMenuItems = isEditCM ? _contextMenuItems : _tabContextMenuItems;

		for (NppXml::Element childNode = NppXml::firstChildElement(contextMenuRoot, "Item");
			childNode;
			childNode = NppXml::nextSiblingElement(childNode, "Item"))
		{
			const char* folderNameDefaultA = NppXml::attribute(childNode, "FolderName");
			const char* folderNameTranslateID_A = NppXml::attribute(childNode, "TranslateID");
			const char* displayAsA = NppXml::attribute(childNode, "ItemNameAs");

			std::wstring folderName = folderNameDefaultA ? wmc.char2wchar(folderNameDefaultA, SC_CP_UTF8) : L"";
			std::wstring displayAs = displayAsA ? wmc.char2wchar(displayAsA, SC_CP_UTF8) : L"";

			if (folderNameTranslateID_A)
			{
				folderName = pNativeSpeaker->getLocalizedStrFromID(folderNameTranslateID_A, folderName);
			}

			const int id = NppXml::intAttribute(childNode, "id", -1);
			if (id >= 0)
			{
				contextMenuItems.emplace_back(id, displayAs.c_str(), folderName.c_str());
			}
			else
			{
				const char* menuEntryNameA = NppXml::attribute(childNode, "MenuEntryName");
				const char* menuItemNameA = NppXml::attribute(childNode, "MenuItemName");

				std::wstring menuEntryName = menuEntryNameA ? wmc.char2wchar(menuEntryNameA, SC_CP_UTF8) : L"";
				std::wstring menuItemName = menuItemNameA ? wmc.char2wchar(menuItemNameA, SC_CP_UTF8) : L"";

				if (!menuEntryName.empty() && !menuItemName.empty())
				{
					int cmd = getCmdIdFromMenuEntryItemName(mainMenuHandle, menuEntryName, menuItemName);
					if (cmd != -1)
						contextMenuItems.emplace_back(cmd, displayAs.c_str(), folderName.c_str());
				}
				else
				{
					const char* pluginNameA = NppXml::attribute(childNode, "PluginEntryName");
					const char* pluginCmdNameA = NppXml::attribute(childNode, "PluginCommandItemName");

					std::wstring pluginName = pluginNameA ? wmc.char2wchar(pluginNameA, SC_CP_UTF8) : L"";
					std::wstring pluginCmdName = pluginCmdNameA ? wmc.char2wchar(pluginCmdNameA, SC_CP_UTF8) : L"";

					// if plugin menu exists, also the value of PluginEntryName and PluginCommandItemName are valid
					if (pluginsMenu && !pluginName.empty() && !pluginCmdName.empty())
					{
						const int pluginCmdId = getPluginCmdIdFromMenuEntryItemName(pluginsMenu, pluginName, pluginCmdName);
						if (pluginCmdId != -1)
							contextMenuItems.emplace_back(pluginCmdId, displayAs.c_str(), folderName.c_str());
					}
				}
			}
		}
	}
	return true;
}


void NppParameters::setWorkingDir(const wchar_t * newPath)
{
	if (newPath && newPath[0])
	{
		_currentDirectory = newPath;
	}
	else
	{
		if (doesDirectoryExist(_nppGUI._defaultDirExp))
			_currentDirectory = _nppGUI._defaultDirExp;
		else
			_currentDirectory = _nppPath;
	}
}

bool NppParameters::loadSession(Session& session, const wchar_t* sessionFileName, const bool bSuppressErrorMsg)
{
	NppXml::Document pXmlSessionDocument = new NppXml::NewDocument();
	bool loadOkay = NppXml::loadFile(pXmlSessionDocument, sessionFileName);
	if (loadOkay)
		loadOkay = getSessionFromXmlTree(pXmlSessionDocument, session, sessionFileName, true);

	if (!loadOkay && !bSuppressErrorMsg)
	{
		_pNativeLangSpeaker->messageBox("SessionFileInvalidError",
			nullptr,
			L"Session file is either corrupted or not valid.",
			L"Could not Load Session",
			MB_OK);
	}

	delete pXmlSessionDocument;
	return loadOkay;
}

bool NppParameters::isServerAllowed(const char* path2check, bool bCaseSensitive)
{
	if (!path2check || !_pXmlServerWhiteListDoc)
		return false;

	switch (_networkPathAlwaysAction)
	{
		case networkPathAlwaysSkip:
			return false;
		case networkPathAlwaysLoad:
			return true;
		case networkPathAlwaysAsk:
		default:
			break;
	}

	std::string path2checkServerName;
	if (!getServerName(path2check, path2checkServerName))
		return false;

	NppXml::Element root = NppXml::firstChildElement(_pXmlServerWhiteListDoc, "NotepadPlus");
	if (!root)
		return false;

	for (NppXml::Element childNode = NppXml::firstChildElement(root, "ServerAllowed");
		childNode;
		childNode = NppXml::nextSiblingElement(childNode, "ServerAllowed"))
	{
		const std::string allowedItem = NppXml::attribute(childNode, "name");
		if (allowedItem.empty())
			continue;

		if (bCaseSensitive)
		{
			if (path2checkServerName == allowedItem)
				return true;
		}
		else
		{
			// Windows default
			if (_stricmp(path2checkServerName.c_str(), allowedItem.c_str()) == 0)
				return true;
		}
	}

	return false;
}

bool NppParameters::getServerName(const std::string& path2check, std::string& serverNameOutput)
{
	serverNameOutput.clear();

	if (path2check.length() < 3)
		return false; // cannot be a net-path with server name

	// case insensitive starts_with
	auto starts_with_ci = [](std::string_view str, std::string_view prefix) {
		if (str.size() < prefix.size()) return false;
		return std::equal(prefix.begin(), prefix.end(), str.begin(), [](char a, char b) {
			return std::tolower(static_cast<unsigned char>(a)) == std::tolower(static_cast<unsigned char>(b));
		});
	};

	std::string path2checkNormStrip = path2check;
	std::replace(path2checkNormStrip.begin(), path2checkNormStrip.end(), '/', '\\'); // 1st normalize to backslashes
	if (starts_with_ci(path2checkNormStrip, "\\\\?\\"))
	{
		if (starts_with_ci(path2checkNormStrip, "\\\\?\\UNC\\"))
			path2checkNormStrip = "\\\\" + path2checkNormStrip.substr(8);
		else
			path2checkNormStrip = path2checkNormStrip.substr(4);
	}
	else if (starts_with_ci(path2checkNormStrip, "file:\\\\"))
	{
		path2checkNormStrip = path2checkNormStrip.substr(5);
	}

	// a valid net-path starting with double-backslash?
	if ((path2checkNormStrip.length() < 3) || (path2checkNormStrip[0] != L'\\') || (path2checkNormStrip[1] != L'\\'))
		return false;

	// extract the server name between the prefix and the next backslash
	const size_t serverStartPos = 2;
	size_t serverEndPos = path2checkNormStrip.find('\\', serverStartPos);
	if ((serverEndPos == std::wstring::npos) || (serverEndPos == serverStartPos))
		return false; // invalid, missing a share file specification after

	serverNameOutput = path2checkNormStrip.substr(serverStartPos, serverEndPos - serverStartPos);

	return true;
}

bool NppParameters::makeDefaultServerWhiteList(bool bSave2File)
{
	if (_pXmlServerWhiteListDoc)
	{
		_pXmlServerWhiteListDoc->reset();
	}
	else
	{
		_pXmlServerWhiteListDoc = new NppXml::NewDocument();
		if (!_pXmlServerWhiteListDoc)
			return false;
	}

	NppXml::createNewDeclaration(_pXmlServerWhiteListDoc);
	NppXml::Element root = NppXml::createChildElement(_pXmlServerWhiteListDoc, "NotepadPlus");

	NppXml::Element childElement = NppXml::createChildElement(root, "NetworkPathsAlwaysAction");
	NppXml::setAttribute(childElement, "value", "?"); // default (networkPathAlwaysAsk)

	return bSave2File ?
		_pXmlServerWhiteListDoc->save_file(_serverWhiteListPath.c_str(), "    ", pugi::format_indent | pugi::format_no_declaration | pugi::format_save_file_text) 
		: true;
}

bool NppParameters::addServerToWhiteList(const char* netpath, bool bCaseSensitive)
{
	if (!netpath)
		return false;

	std::string netpathServerName;
	if (!getServerName(netpath, netpathServerName))
		return false;

	if (!_pXmlServerWhiteListDoc)
	{
		if (!makeDefaultServerWhiteList(false))
			return false;
	}

	NppXml::Element root = NppXml::firstChildElement(_pXmlServerWhiteListDoc, "NotepadPlus");
	if (!root)
		return false;

	for (NppXml::Element childNode = NppXml::firstChildElement(root, "ServerAllowed");
		childNode;
		childNode = NppXml::nextSiblingElement(childNode, "ServerAllowed"))
	{
		std::string allowedItem = NppXml::attribute(childNode, "name");
		if (bCaseSensitive)
		{
			if (netpathServerName == allowedItem)
				return true; // already there
		}
		else
		{
			// Windows default
			if (_stricmp(netpathServerName.c_str(), allowedItem.c_str()) == 0)
				return true; // already there
		}
	}

	// add new record
	NppXml::Element elementServerAllowed = NppXml::createChildElement(root, "ServerAllowed");
	NppXml::setAttribute(elementServerAllowed, "name", netpathServerName.c_str());

	return _pXmlServerWhiteListDoc->save_file(_serverWhiteListPath.c_str(), "    ", pugi::format_indent | pugi::format_no_declaration | pugi::format_save_file_text);
}

bool NppParameters::setNetworkPathAlwaysActionInServerWhitelist(NetworkPathAlwaysAction mode)
{
	if (!_pXmlServerWhiteListDoc)
	{
		if (!makeDefaultServerWhiteList(false))
			return false;
	}

	NppXml::Element root = NppXml::firstChildElement(_pXmlServerWhiteListDoc, "NotepadPlus");
	if (root)
	{
		NppXml::Element childNode = NppXml::firstChildElement(root, "NetworkPathsAlwaysAction");
		if (childNode)
		{
			switch (mode)
			{
				case networkPathAlwaysAsk:
					NppXml::setAttribute(childNode, "value", "?");
					break;
				case networkPathAlwaysSkip:
					NppXml::setAttribute(childNode, "value", "!");
					break;
				case networkPathAlwaysLoad:
					NppXml::setAttribute(childNode, "value", "*");
					break;
				default:
					assert(false);
					return false; // unknown
			}

			_networkPathAlwaysAction = mode;

			return _pXmlServerWhiteListDoc->save_file(_serverWhiteListPath.c_str(), "    ", pugi::format_indent | pugi::format_no_declaration | pugi::format_save_file_text);
		}
	}

	return false;
}

bool NppParameters::getSessionFromXmlTree(const NppXml::Document& pSessionDoc, Session& session, const std::wstring& sessionDocFileName, bool detectNetworkPath)
{
	if (!pSessionDoc)
		return false;

	NppXml::Element root = NppXml::firstChildElement(pSessionDoc, "NotepadPlus");
	if (!root)
		return false;

	NppXml::Element sessionRoot = NppXml::firstChildElement(root, "Session");
	if (!sessionRoot)
		return false;

	bool bNeedsSessionXmlFileUpdateAfter = false;

	const int index = NppXml::intAttribute(sessionRoot, "activeView", -1);
	if (index >= 0)
	{
		session._activeView = index;
	}

	WcharMbcsConvertor& wmc = WcharMbcsConvertor::getInstance();

	static constexpr size_t nbView = 2;
	NppXml::Element viewRoots[nbView] {
		NppXml::firstChildElement(sessionRoot, "mainView"),
		NppXml::firstChildElement(sessionRoot, "subView")
	};

	HINSTANCE hInst = ::GetModuleHandle(nullptr);
	HWND nppHwnd = ::FindWindow(Notepad_plus_Window::getClassName(), NULL);

	bool isNppExit = false;
	if (g_bNppExitFlag.load())
		isNppExit = true; // NetworkPathWarning should not be shown at the Notepad++ exit

	for (size_t k = 0; k < nbView; ++k)
	{
		if (viewRoots[k])
		{
			const int index2 = NppXml::intAttribute(viewRoots[k], "activeIndex", -1);
			if (index2 >= 0)
			{
				if (k == 0)
					session._activeMainIndex = index2;
				else // k == 1
					session._activeSubIndex = index2;
			}

			for (NppXml::Element childNode = NppXml::firstChildElement(viewRoots[k], "File"), nextNode;
				childNode;
				childNode = nextNode)
			{
				// cache the possible next sibling before doing anything else (nodes can be removed further in the cycle...)
				nextNode = NppXml::nextSiblingElement(childNode, "File");

				const char* fileName = NppXml::attribute(childNode, "filename");
				if (fileName)
				{
					const std::wstring wstrFileName = string2wstring(fileName);

					if (!isNppExit && detectNetworkPath && isUncPath(wstrFileName))
					{
						if (!isServerAllowed(fileName)) // is in the serverWhiteList.xml ?
						{
							if (_networkPathAlwaysAction == networkPathAlwaysAsk)
							{
								NetworkPathWarningBox networkPathWarningBox;
								networkPathWarningBox.init(hInst, nppHwnd, wstrFileName);
								networkPathWarningBox.doDialog(_pNativeLangSpeaker ? _pNativeLangSpeaker->isRTL() : false);
								int buttonID = networkPathWarningBox.getClickedButtonId();
								networkPathWarningBox.destroy();

								if (buttonID == IDCANCEL || buttonID == IDNO) // Skip once or Always skip
								{
									// as the Skip or AlwaysSkip causes the current filename will not be in the Notepad++ session anymore,
									// it is important to update also the current session.xml content on disk accordingly,
									// otherwise any subsequent indirect Notepad++ app launching (e.g. via the NppShell context menu)
									// causes this getSessionFromXmlTree will check old out-of-date session.xml content
									bNeedsSessionXmlFileUpdateAfter = true;
									viewRoots[k].remove_child(childNode);
									continue;
								}
							}
							else if (_networkPathAlwaysAction == networkPathAlwaysSkip)
							{
								bNeedsSessionXmlFileUpdateAfter = true;
								viewRoots[k].remove_child(childNode);
								continue;
							}
							else if (_networkPathAlwaysAction == networkPathAlwaysLoad)
							{
								// do nothing, continue to load the file
							}
						}
					}

					Position position{
						._firstVisibleLine = static_cast<intptr_t>(NppXml::int64Attribute(childNode, "firstVisibleLine", 0)),
						._startPos = static_cast<intptr_t>(NppXml::int64Attribute(childNode, "startPos", 0)),
						._endPos = static_cast<intptr_t>(NppXml::int64Attribute(childNode, "endPos", 0)),
						._xOffset = static_cast<intptr_t>(NppXml::int64Attribute(childNode, "xOffset", 0)),
						._selMode = static_cast<intptr_t>(NppXml::int64Attribute(childNode, "selMode", 0)),
						._scrollWidth = static_cast<intptr_t>(NppXml::int64Attribute(childNode, "scrollWidth", 1)),
						._offset = static_cast<intptr_t>(NppXml::int64Attribute(childNode, "offset", 0)),
						._wrapCount = static_cast<intptr_t>(NppXml::int64Attribute(childNode, "wrapCount", 0))
					};

					MapPosition mapPosition{
						._firstVisibleDisplayLine = static_cast<intptr_t>(NppXml::int64Attribute(childNode, "mapFirstVisibleDisplayLine", -1)),
						._firstVisibleDocLine = static_cast<intptr_t>(NppXml::int64Attribute(childNode, "mapFirstVisibleDocLine", -1)),
						._lastVisibleDocLine = static_cast<intptr_t>(NppXml::int64Attribute(childNode, "mapLastVisibleDocLine", -1)),
						._nbLine = static_cast<intptr_t>(NppXml::int64Attribute(childNode, "mapNbLine", -1)),
						._higherPos = static_cast<intptr_t>(NppXml::int64Attribute(childNode, "mapHigherPos", -1)),
						._width = static_cast<intptr_t>(NppXml::int64Attribute(childNode, "mapWidth", -1)),
						._height = static_cast<intptr_t>(NppXml::int64Attribute(childNode, "mapHeight", -1)),
						._wrapIndentMode = static_cast<intptr_t>(NppXml::int64Attribute(childNode, "mapWrapIndentMode", -1)),
						._KByteInDoc = static_cast<intptr_t>(NppXml::int64Attribute(childNode, "mapKByteInDoc", MapPosition::getMaxPeekLenInKB())),
						._isWrap = getBoolAttribute(childNode, "mapIsWrap")
					};

					const char* langName = NppXml::attribute(childNode, "lang");
					const std::wstring wstrLangName = langName ? string2wstring(langName) : L"";

					const char* backupFilePath = NppXml::attribute(childNode, "backupFilePath");
					const std::wstring wstrBackupFilePath = wmc.char2wchar(backupFilePath ? backupFilePath : "", CP_UTF8);

					if (!isNppExit && detectNetworkPath && isUncPath(wstrBackupFilePath))
					{
						if (!isServerAllowed(backupFilePath)) // is in the serverWhiteList.xml ?
						{
							if (_networkPathAlwaysAction == networkPathAlwaysAsk)
							{
								NetworkPathWarningBox networkPathWarningBox;
								networkPathWarningBox.init(hInst, nppHwnd, wstrBackupFilePath);
								networkPathWarningBox.doDialog(_pNativeLangSpeaker ? _pNativeLangSpeaker->isRTL() : false);
								int buttonID = networkPathWarningBox.getClickedButtonId();
								networkPathWarningBox.destroy();

								if (buttonID == IDCANCEL || buttonID == IDNO) // Skip once or Always skip
								{
									bNeedsSessionXmlFileUpdateAfter = true;
									viewRoots[k].remove_child(childNode);
									continue;
								}
							}
							else if (_networkPathAlwaysAction == networkPathAlwaysSkip)
							{
								bNeedsSessionXmlFileUpdateAfter = true;
								viewRoots[k].remove_child(childNode);
								continue;
							}
							else if (_networkPathAlwaysAction == networkPathAlwaysLoad)
							{
								// do nothing, continue to load the file
							}
						}
					}

					wchar_t normalizedBackupFilePath[MAX_PATH]{};

					if (!wstrBackupFilePath.empty() && (wstrBackupFilePath.length() < MAX_PATH))
					{
						std::wstring sanitizedPath = wstrBackupFilePath;
						std::replace(sanitizedPath.begin(), sanitizedPath.end(), L'/', L'\\');

						if (!::PathCanonicalize(normalizedBackupFilePath, sanitizedPath.c_str()))
							normalizedBackupFilePath[0] = L'\0'; // treat failure as "no path" -> falls through to reconstruction below
					}
					else if (!wstrBackupFilePath.empty())
					{
						wchar_t* fn = ::PathFindFileNameW(wstrBackupFilePath.c_str());
						::StringCchCopyW(normalizedBackupFilePath, MAX_PATH, fn);
					}

					std::wstring currentBackupFilePath = NppParameters::getInstance().getUserPath() + L"\\backup\\";

					wchar_t normalizedBackupDir[MAX_PATH]{};
					if (::GetFullPathNameW(currentBackupFilePath.c_str(), MAX_PATH, normalizedBackupDir, NULL) == 0)
						::StringCchCopyW(normalizedBackupDir, MAX_PATH, currentBackupFilePath.c_str());

					if (normalizedBackupFilePath[0])
					{
						std::wstring backupFilePath = normalizedBackupFilePath;
						bool isConfined = false;
						size_t normalizedBackupDirLen = wcslen(normalizedBackupDir);
						if (backupFilePath.size() >= normalizedBackupDirLen)
						{
							int res = ::CompareStringOrdinal(backupFilePath.c_str(), static_cast<int>(normalizedBackupDirLen), normalizedBackupDir, static_cast<int>(normalizedBackupDirLen), TRUE);
							isConfined = res == CSTR_EQUAL;
						}

						if (!isConfined)
						{
							// reconstruct backupFilePath
							wchar_t* fn = ::PathFindFileNameW(normalizedBackupFilePath);

							std::wstring safePath = normalizedBackupDir;
							safePath += fn;
							::StringCchCopyW(normalizedBackupFilePath, MAX_PATH, safePath.c_str());
						}
					}

					FILETIME fileModifiedTimestamp {
						.dwLowDateTime = static_cast<DWORD>(NppXml::uint64Attribute(childNode, "originalFileLastModifTimestamp", 0)),
						.dwHighDateTime = static_cast<DWORD>(NppXml::uint64Attribute(childNode, "originalFileLastModifTimestampHigh", 0))
					};

					const int encoding = NppXml::intAttribute(childNode, "encoding", -1);

					const bool isUserReadOnly = getBoolAttribute(childNode, "userReadOnly");
					const bool isPinned = getBoolAttribute(childNode, "tabPinned");
					const bool isUntitleTabRenamed = getBoolAttribute(childNode, "untitleTabRenamed");

					sessionFileInfo sfi(wstrFileName.c_str(), wstrLangName.c_str(), encoding,
						isUserReadOnly, isPinned, isUntitleTabRenamed,
						position, normalizedBackupFilePath, fileModifiedTimestamp, mapPosition);

					sfi._individualTabColour = NppXml::intAttribute(childNode, "tabColourId", -1);
					sfi._isRTL = getBoolAttribute(childNode, "RTL");

					for (NppXml::Element markNode = NppXml::firstChildElement(childNode, "Mark");
						markNode;
						markNode = NppXml::nextSiblingElement(markNode, "Mark"))
					{
						const auto lineNumber = static_cast<intptr_t>(NppXml::int64Attribute(markNode, "line", -1));
						if (lineNumber > -1)
						{
							sfi._marks.push_back(static_cast<size_t>(lineNumber));
						}
					}

					for (NppXml::Element foldNode = NppXml::firstChildElement(childNode, "Fold");
						foldNode;
						foldNode = NppXml::nextSiblingElement(foldNode, "Fold"))
					{
						const auto lineNumber = static_cast<intptr_t>(NppXml::int64Attribute(foldNode, "line", -1));
						if (lineNumber > -1)
						{
							sfi._foldStates.push_back(static_cast<size_t>(lineNumber));
						}
					}
					if (k == 0)
						session._mainViewFiles.push_back(sfi);
					else // k == 1
						session._subViewFiles.push_back(sfi);
				}
			}
		}
	}

	// Node structure and naming corresponds to config.xml
	NppXml::Element fileBrowserRoot = NppXml::firstChildElement(sessionRoot, "FileBrowser");
	if (fileBrowserRoot)
	{
		const char* selectedItemPath = NppXml::attribute(fileBrowserRoot, "latestSelectedItem");
		if (selectedItemPath && selectedItemPath[0])
		{
			session._fileBrowserSelectedItem = string2wstring(selectedItemPath);
		}

		for (NppXml::Element childNode = NppXml::firstChildElement(fileBrowserRoot, "root"), nextNode;
			childNode;
			childNode = nextNode)
		{
			// cache the possible next sibling before doing anything else (nodes can be removed further in the cycle...)
			nextNode = NppXml::nextSiblingElement(childNode, "root");

			const char* fileName = NppXml::attribute(childNode, "foldername");
			if (fileName && fileName[0])
			{
				std::wstring rootFolder = string2wstring(fileName);

				if (!isNppExit && detectNetworkPath && isUncPath(rootFolder))
				{
					if (!isServerAllowed(fileName)) // is in the serverWhiteList.xml ?
					{
						if (_networkPathAlwaysAction == networkPathAlwaysAsk)
						{
							NetworkPathWarningBox networkPathWarningBox;
							networkPathWarningBox.init(hInst, nppHwnd, rootFolder);
							networkPathWarningBox.doDialog(_pNativeLangSpeaker ? _pNativeLangSpeaker->isRTL() : false);
							int buttonID = networkPathWarningBox.getClickedButtonId();
							networkPathWarningBox.destroy();

							if (buttonID == IDCANCEL || buttonID == IDNO) // Skip once or Always skip
							{
								bNeedsSessionXmlFileUpdateAfter = true;
								fileBrowserRoot.remove_child(childNode);
								continue;
							}
						}
						else if (_networkPathAlwaysAction == networkPathAlwaysSkip)
						{
							bNeedsSessionXmlFileUpdateAfter = true;
							fileBrowserRoot.remove_child(childNode);
							continue;
						}
						else if (_networkPathAlwaysAction == networkPathAlwaysLoad)
						{
							// do nothing, continue to load the file
						}
					}
				}

				std::wstring lowerRoot = stringToLower(rootFolder);
				FileBrowserRootsInfo fileRootInfo(std::move(rootFolder));

				std::unordered_set<std::wstring> seenLower;
				for (NppXml::Element expNode = NppXml::firstChildElement(childNode, "expanded");
					expNode;
					expNode = NppXml::nextSiblingElement(expNode, "expanded"))
				{
					const char* pathAttr = NppXml::attribute(expNode, "path");
					if (!pathAttr || !pathAttr[0])
						continue;

					std::wstring expandedPath = string2wstring(pathAttr);
					std::wstring lowerExpanded = stringToLower(expandedPath);

					if (lowerExpanded.rfind(lowerRoot, 0) != 0)
						continue;

					auto [it, inserted] = seenLower.insert(std::move(lowerExpanded));
					if (!inserted)
						continue;

					fileRootInfo._expandedPaths.insert(std::move(expandedPath));
				}

				session._fileBrowserRoots.push_back(std::move(fileRootInfo));
			}
		}
	}

	if (bNeedsSessionXmlFileUpdateAfter && !sessionDocFileName.empty())
		pSessionDoc->save_file(sessionDocFileName.c_str());

	return true;
}

void NppParameters::feedFileListParameters(const NppXml::Element& element)
{
	NppXml::Element historyRoot = NppXml::firstChildElement(element, "History");
	if (!historyRoot) return;

	// nbMaxFile value
	_nbMaxRecentFile = getRangeClampAttribute<UINT>(historyRoot, "nbMaxFile", 0, static_cast<UINT>(NB_MAX_LRF_FILE), _nbMaxRecentFile);

	// customLen value
	const int customLen = NppXml::intAttribute(historyRoot, "customLength", RECENTFILES_SHOWFULLPATH);
	_recentFileCustomLength = std::min<int>(customLen, NB_MAX_LRF_CUSTOMLENGTH);

	// inSubMenu value
	_putRecentFileInSubMenu = getBoolAttribute(historyRoot, "inSubMenu");

	for (NppXml::Element childNode = NppXml::firstChildElement(historyRoot, "File");
		childNode && (_nbRecentFile < NB_MAX_LRF_FILE);
		childNode = NppXml::nextSiblingElement(childNode, "File"))
	{
		const std::wstring filePath = string2wstring(NppXml::attribute(childNode, "filename", ""));
		if (!filePath.empty())
		{
			_LRFileList[_nbRecentFile] = std::make_unique<std::wstring>(filePath);
			++_nbRecentFile;
		}
	}
}

void NppParameters::feedFileBrowserParameters(const NppXml::Element& element)
{
	NppXml::Element fileBrowserRoot = NppXml::firstChildElement(element, "FileBrowser");
	if (!fileBrowserRoot) return;

	const char* selectedItemPath = NppXml::attribute(fileBrowserRoot, "latestSelectedItem");
	if (selectedItemPath && selectedItemPath[0])
	{
		_fileBrowserSelectedItemPath = string2wstring(selectedItemPath);
	}

	for (NppXml::Element childNode = NppXml::firstChildElement(fileBrowserRoot, "root");
		childNode;
		childNode = NppXml::nextSiblingElement(childNode, "root"))
	{
		const char* filePath = NppXml::attribute(childNode, "foldername");
		if (filePath && filePath[0])
		{
			std::wstring rootFolder = string2wstring(filePath);
			std::wstring lowerRoot = stringToLower(rootFolder);
			FileBrowserRootsInfo fileRootInfo(std::move(rootFolder));

			std::unordered_set<std::wstring> seenLower;
			for (NppXml::Element expNode = NppXml::firstChildElement(childNode, "expanded");
				expNode;
				expNode = NppXml::nextSiblingElement(expNode, "expanded"))
			{
				const char* pathAttr = NppXml::attribute(expNode, "path");
				if (!pathAttr || !pathAttr[0])
					continue;

				std::wstring expandedPath = string2wstring(pathAttr);
				std::wstring lowerExpanded = stringToLower(expandedPath);

				if (lowerExpanded.rfind(lowerRoot, 0) != 0)
					continue;

				auto [it, inserted] = seenLower.insert(std::move(lowerExpanded));
				if (!inserted)
					continue;

				fileRootInfo._expandedPaths.insert(std::move(expandedPath));
			}

			_fileBrowserRoots.push_back(fileRootInfo);
		}
	}
}

void NppParameters::feedProjectPanelsParameters(const NppXml::Element& element)
{
	NppXml::Element projPanelRoot = NppXml::firstChildElement(element, "ProjectPanels");
	if (!projPanelRoot) return;

	for (NppXml::Element childNode = NppXml::firstChildElement(projPanelRoot, "ProjectPanel");
		childNode;
		childNode = NppXml::nextSiblingElement(childNode, "ProjectPanel"))
	{
		const int index = NppXml::intAttribute(childNode, "id", 0);
		if (index >= 0 && index <= 2)
		{
			const char* filePath = NppXml::attribute(childNode, "workSpaceFile");
			if (filePath && filePath[0])
			{
				_workSpaceFilePaths[index] = string2wstring(filePath);
			}
		}
	}
}

void NppParameters::feedColumnEditorParameters(const NppXml::Element& element)
{
	NppXml::Element  columnEditorRoot = NppXml::firstChildElement(element, "ColumnEditor");
	if (!columnEditorRoot) return;

	const char* strVal = NppXml::attribute(columnEditorRoot, "choice");
	if (strVal)
	{
		if (std::strcmp(strVal, "text") == 0)
			_columnEditParam._mainChoice = activeText;
		else
			_columnEditParam._mainChoice = activeNumeric;
	}
	NppXml::Element childNode = NppXml::firstChildElement(columnEditorRoot, "text");
	if (!childNode) return;

	const char* content = NppXml::attribute(childNode, "content");
	if (content && content[0])
	{
		_columnEditParam._insertedTextContent = string2wstring(content);
	}

	childNode = NppXml::firstChildElement(columnEditorRoot, "number");
	if (!childNode) return;

	int val = NppXml::intAttribute(childNode, "initial", -1);
	if (val > -1)
		_columnEditParam._initialNum = val;

	val = NppXml::intAttribute(childNode, "increase", -1);
	if (val > -1)
		_columnEditParam._increaseNum = val;

	val = NppXml::intAttribute(childNode, "repeat", -1);
	if (val > -1)
		_columnEditParam._repeatNum = val;

	strVal = NppXml::attribute(childNode, "formatChoice");
	if (strVal)
	{
		using enum NumBase;
		if (std::strcmp(strVal, "hex") == 0)
			_columnEditParam._formatChoice = BASE_16;
		else if (std::strcmp(strVal, "hexuc") == 0)
			_columnEditParam._formatChoice = BASE_16_UPPERCASE;
		else if (std::strcmp(strVal, "oct") == 0)
			_columnEditParam._formatChoice = BASE_08;
		else if (std::strcmp(strVal, "bin") == 0)
			_columnEditParam._formatChoice = BASE_02;
		else // "dec"
			_columnEditParam._formatChoice = BASE_10;
	}

	strVal = NppXml::attribute(childNode, "leadingChoice");
	if (strVal)
	{
		using enum ColumnEditorParam::leadingChoice;
		if (std::strcmp(strVal, "zeros") == 0)
		{
			_columnEditParam._leadingChoice = zeroLeading;
		}
		else if (std::strcmp(strVal, "spaces") == 0)
		{
			_columnEditParam._leadingChoice = spaceLeading;
		}
		else // "none"
		{
			_columnEditParam._leadingChoice = noneLeading;
		}
	}
}

void NppParameters::feedFindHistoryParameters(const NppXml::Element& element)
{
	NppXml::Element findHistoryRoot = NppXml::firstChildElement(element, "FindHistory");
	if (!findHistoryRoot) return;

	_findHistory._nbMaxFindHistoryPath = NppXml::intAttribute(findHistoryRoot, "nbMaxFindHistoryPath", _findHistory._nbMaxFindHistoryPath);
	if (_findHistory._nbMaxFindHistoryPath > NB_MAX_FINDHISTORY_PATH)
	{
		_findHistory._nbMaxFindHistoryPath = NB_MAX_FINDHISTORY_PATH;
	}
	if ((_findHistory._nbMaxFindHistoryPath > 0) && (_findHistory._nbMaxFindHistoryPath <= NB_MAX_FINDHISTORY_PATH))
	{
		for (NppXml::Element childNode = NppXml::firstChildElement(findHistoryRoot, "Path");
			childNode && (_findHistory._findHistoryPaths.size() < NB_MAX_FINDHISTORY_PATH);
			childNode = NppXml::nextSiblingElement(childNode, "Path"))
		{
			const char* filePath = NppXml::attribute(childNode, "name");
			if (filePath)
			{
				_findHistory._findHistoryPaths.push_back(string2wstring(filePath));
			}
		}
	}

	_findHistory._nbMaxFindHistoryFilter = NppXml::intAttribute(findHistoryRoot, "nbMaxFindHistoryFilter", _findHistory._nbMaxFindHistoryFilter);
	if (_findHistory._nbMaxFindHistoryFilter > NB_MAX_FINDHISTORY_FILTER)
	{
		_findHistory._nbMaxFindHistoryFilter = NB_MAX_FINDHISTORY_FILTER;
	}
	if ((_findHistory._nbMaxFindHistoryFilter > 0) && (_findHistory._nbMaxFindHistoryFilter <= NB_MAX_FINDHISTORY_FILTER))
	{
		for (NppXml::Element childNode = NppXml::firstChildElement(findHistoryRoot, "Filter");
			childNode && (_findHistory._findHistoryFilters.size() < NB_MAX_FINDHISTORY_FILTER);
			childNode = NppXml::nextSiblingElement(childNode, "Filter"))
		{
			const char* fileFilter = NppXml::attribute(childNode, "name");
			if (fileFilter)
			{
				_findHistory._findHistoryFilters.push_back(string2wstring(fileFilter));
			}
		}
	}

	_findHistory._nbMaxFindHistoryFind = NppXml::intAttribute(findHistoryRoot, "nbMaxFindHistoryFind", _findHistory._nbMaxFindHistoryFind);
	if (_findHistory._nbMaxFindHistoryFind > NB_MAX_FINDHISTORY_FIND)
	{
		_findHistory._nbMaxFindHistoryFind = NB_MAX_FINDHISTORY_FIND;
	}
	if ((_findHistory._nbMaxFindHistoryFind > 0) && (_findHistory._nbMaxFindHistoryFind <= NB_MAX_FINDHISTORY_FIND))
	{
		for (NppXml::Element childNode = NppXml::firstChildElement(findHistoryRoot, "Find");
			childNode && (_findHistory._findHistoryFinds.size() < NB_MAX_FINDHISTORY_FIND);
			childNode = NppXml::nextSiblingElement(childNode, "Find"))
		{
			const char* fileFind = NppXml::attribute(childNode, "name");
			if (fileFind)
			{
				_findHistory._findHistoryFinds.push_back(string2wstring(fileFind));
			}
		}
	}

	_findHistory._nbMaxFindHistoryReplace = NppXml::intAttribute(findHistoryRoot, "nbMaxFindHistoryReplace", _findHistory._nbMaxFindHistoryReplace);
	if (_findHistory._nbMaxFindHistoryReplace > NB_MAX_FINDHISTORY_REPLACE)
	{
		_findHistory._nbMaxFindHistoryReplace = NB_MAX_FINDHISTORY_REPLACE;
	}
	if ((_findHistory._nbMaxFindHistoryReplace > 0) && (_findHistory._nbMaxFindHistoryReplace <= NB_MAX_FINDHISTORY_REPLACE))
	{
		for (NppXml::Element childNode = NppXml::firstChildElement(findHistoryRoot, "Replace");
			childNode && (_findHistory._findHistoryReplaces.size() < NB_MAX_FINDHISTORY_REPLACE);
			childNode = NppXml::nextSiblingElement(childNode, "Replace"))
		{
			const char* fileReplace = NppXml::attribute(childNode, "name");
			if (fileReplace)
			{
				_findHistory._findHistoryReplaces.push_back(string2wstring(fileReplace));
			}
		}
	}

	_findHistory._isMatchWord = getBoolAttribute(findHistoryRoot, "matchWord");
	_findHistory._isMatchCase = getBoolAttribute(findHistoryRoot, "matchCase");
	_findHistory._isWrap = getBoolAttribute(findHistoryRoot, "wrap", _findHistory._isWrap);
	_findHistory._isDirectionDown = getBoolAttribute(findHistoryRoot, "directionDown", _findHistory._isDirectionDown);
	_findHistory._isFifRecursive = getBoolAttribute(findHistoryRoot, "fifRecuisive", _findHistory._isFifRecursive);
	_findHistory._isFifInHiddenFolder = getBoolAttribute(findHistoryRoot, "fifInHiddenFolder");
	_findHistory._isFifProjectPanel_1 = getBoolAttribute(findHistoryRoot, "fifProjectPanel1");
	_findHistory._isFifProjectPanel_2 = getBoolAttribute(findHistoryRoot, "fifProjectPanel2");
	_findHistory._isFifProjectPanel_3 = getBoolAttribute(findHistoryRoot, "fifProjectPanel3");
	_findHistory._isFilterFollowDoc = getBoolAttribute(findHistoryRoot, "fifFilterFollowsDoc");

	{
		using enum FindHistory::searchMode;
		_findHistory._searchMode = getRangeDefaultAttribute(findHistoryRoot, "searchMode", normal, regExpr, _findHistory._searchMode);
	}

	{
		using enum FindHistory::transparencyMode;
		_findHistory._transparencyMode = getRangeDefaultAttribute(findHistoryRoot, "transparencyMode", none, persistent, _findHistory._transparencyMode);
	}

	_findHistory._transparency = getRangeDefaultAttribute(findHistoryRoot, "transparency", 1, 200, _findHistory._transparency);

	_findHistory._dotMatchesNewline = getBoolAttribute(findHistoryRoot, "dotMatchesNewline");
	_findHistory._isSearch2ButtonsMode = getBoolAttribute(findHistoryRoot, "isSearch2ButtonsMode");
	_findHistory._regexBackward4PowerUser = getBoolAttribute(findHistoryRoot, "regexBackward4PowerUser");
	_findHistory._isBookmarkLine = getBoolAttribute(findHistoryRoot, "bookmarkLine");
	_findHistory._isPurge = getBoolAttribute(findHistoryRoot, "purge");
}

void NppParameters::feedShortcut(const NppXml::Element& element)
{
	NppXml::Element shortcutsRoot = NppXml::firstChildElement(element, "InternalCommands");
	if (!shortcutsRoot) return;

	for (NppXml::Element childNode = NppXml::firstChildElement(shortcutsRoot, "Shortcut");
		childNode;
		childNode = NppXml::nextSiblingElement(childNode, "Shortcut"))
	{
		const int id = NppXml::intAttribute(childNode, "id", -1);
		if (id > 0)
		{
			//find the commandid that matches this Shortcut sc and alter it, push back its index in the modified list, if not present
			size_t len = _shortcuts.size();
			bool isFound = false;
			for (size_t i = 0; i < len && !isFound; ++i)
			{
				if (_shortcuts[i].getID() == static_cast<unsigned long>(id))
				{	//found our match
					isFound = getInternalCommandShortcuts(childNode, _shortcuts[i]);

					if (isFound)
						addUserModifiedIndex(i);
				}
			}
		}
	}
}

void NppParameters::feedMacros(const NppXml::Element& element)
{
	NppXml::Element macrosRoot = NppXml::firstChildElement(element, "Macros");
	if (!macrosRoot) return;

	for (NppXml::Element childNode = NppXml::firstChildElement(macrosRoot, "Macro");
		childNode;
		childNode = NppXml::nextSiblingElement(childNode, "Macro"))
	{
		Shortcut sc;
		std::string fdnm;
		if (getShortcuts(childNode, sc, &fdnm))
		{
			Macro macro;
			getActions(childNode, macro);
			const auto cmdID = ID_MACRO + static_cast<int>(_macros.size());
			_macros.emplace_back(sc, macro, cmdID);
			_macroMenuItems.emplace_back(cmdID, string2wstring(sc.getName()), string2wstring(fdnm));
		}
	}
}


void NppParameters::getActions(const NppXml::Element& element, Macro& macro)
{
	for (NppXml::Element childNode = NppXml::firstChildElement(element, "Action");
		childNode;
		childNode = NppXml::nextSiblingElement(childNode, "Action") )
	{
		const int type = NppXml::intAttribute(childNode, "type", 4);
		if (type > 3)
			continue;

		const int msg = NppXml::intAttribute(childNode, "message", 0);
		const int wParam = NppXml::intAttribute(childNode, "wParam", 0);
		const int lParam = NppXml::intAttribute(childNode, "lParam", 0);

		const char* sParam = NppXml::attribute(childNode, "sParam", "");

		// Normalize end-of-line (EOL) characters for macro steps to address issues with old saved macros
		// potentially having inconsistent EOL formats due to TinyXML1 and the native API.
		//
		// The logic replaces macro steps that use SCI_REPLACESEL with a single EOL with step using SCI_NEWLINE.
		// Special handling is implemented for previous step that used CR (carriage return) EOL.
		// If the current step has CRLF or LF, the previous step with CR is removed
		// to avoid generating consecutive double newlines.

		const bool isPrevMacroCR =
			!macro.empty()
			&& macro.back()._message == SCI_REPLACESEL
			&& macro.back()._sParameter == "\r";

		const bool isCR = std::strcmp(sParam, "\r") == 0;

		if (msg == SCI_REPLACESEL
			&& sParam[0] != '\0'
			&& (isCR
				|| std::strcmp(sParam, "\r\n") == 0
				|| std::strcmp(sParam, "\n") == 0))
		{
			if (isPrevMacroCR)
			{
				if (isCR)
				{
					macro.back() = recordedMacroStep(SCI_NEWLINE, 0, 0, nullptr, 0);
				}
				else
				{
					// Remove the last macro step to prevent double newlines.
					macro.pop_back();
				}
			}

			if (isCR)
			{
				// Insert the original macro step with SCI_REPLACESEL and CR for later checking.
				// See check for `isPrevMacroCR`.
				macro.emplace_back(msg, wParam, lParam, sParam, type);
			}
			else
			{
				macro.emplace_back(SCI_NEWLINE, 0, 0, nullptr, 0);
			}
		}
		else
		{
			if (isPrevMacroCR)
			{
				macro.back() = recordedMacroStep(SCI_NEWLINE, 0, 0, nullptr, 0);
			}

			macro.emplace_back(msg, wParam, lParam, sParam, type);
		}
	}

	// Ensure the last macro step is correctly recorded as SCI_NEWLINE if it had an original CR.
	if (!macro.empty()
		&& macro.back()._message == SCI_REPLACESEL
		&& macro.back()._sParameter == "\r")
	{
		macro.back() = recordedMacroStep(SCI_NEWLINE, 0, 0, nullptr, 0);
	}
}

void NppParameters::feedUserCmds(const NppXml::Element& element)
{
	NppXml::Element userCmdsRoot = NppXml::firstChildElement(element, "UserDefinedCommands");
	if (!userCmdsRoot) return;

	for (NppXml::Element childNode = NppXml::firstChildElement(userCmdsRoot, "Command");
		childNode;
		childNode = NppXml::nextSiblingElement(childNode, "Command"))
	{
		Shortcut sc;
		std::string fdnm;
		if (getShortcuts(childNode, sc, &fdnm))
		{
			NppXml::Node aNode = NppXml::firstChild(childNode); // text node
			if (aNode)
			{
				const char* cmdStr = NppXml::getValue(aNode);
				if (cmdStr)
				{
					const auto cmdID = ID_USER_CMD + static_cast<int>(_userCommands.size());
					_userCommands.emplace_back(sc, cmdStr, cmdID);
					_runMenuItems.emplace_back(cmdID, string2wstring(sc.getName()), string2wstring(fdnm));
				}
			}
		}
	}
}

void NppParameters::feedPluginCustomizedCmds(const NppXml::Element& element)
{
	NppXml::Element pluginCustomizedCmdsRoot = NppXml::firstChildElement(element, "PluginCommands");
	if (!pluginCustomizedCmdsRoot) return;

	for (NppXml::Element childNode = NppXml::firstChildElement(pluginCustomizedCmdsRoot, "PluginCommand");
		childNode;
		childNode = NppXml::nextSiblingElement(childNode, "PluginCommand"))
	{
		const char *moduleName = NppXml::attribute(childNode, "moduleName");
		if (!moduleName)
			continue;

		const int internalID = NppXml::intAttribute(childNode, "internalID", -1);
		if (internalID == -1)
			continue;

		//Find the corresponding plugincommand and alter it, put the index in the list
		size_t len = _pluginCommands.size();
		for (size_t i = 0; i < len; ++i)
		{
			PluginCmdShortcut& pscOrig = _pluginCommands[i];
			if (!::_strnicmp(pscOrig.getModuleName(), moduleName, std::strlen(moduleName)) && pscOrig.getInternalID() == internalID)
			{
				//Found matching command
				getShortcuts(childNode, _pluginCommands[i]);
				addPluginModifiedIndex(i);
				break;
			}
		}
	}
}

void NppParameters::feedScintKeys(const NppXml::Element& element)
{
	NppXml::Element scintKeysRoot = NppXml::firstChildElement(element, "ScintillaKeys");
	if (!scintKeysRoot) return;

	for (NppXml::Element childNode = NppXml::firstChildElement(scintKeysRoot, "ScintKey");
		childNode;
		childNode = NppXml::nextSiblingElement(childNode, "ScintKey"))
	{
		const int scintKey = NppXml::intAttribute(childNode, "ScintID", -1);
		if (scintKey == -1)
			continue;

		const int menuID = NppXml::intAttribute(childNode, "menuCmdID", -1);
		if (menuID == -1)
			continue;

		//Find the corresponding scintillacommand and alter it, put the index in the list
		size_t len = _scintillaKeyCommands.size();
		for (int i = 0; i < static_cast<int>(len); ++i)
		{
			ScintillaKeyMap & skmOrig = _scintillaKeyCommands[i];
			if (skmOrig.getScintillaKeyID() == static_cast<unsigned long>(scintKey) && skmOrig.getMenuCmdID() == menuID)
			{
				//Found matching command
				_scintillaKeyCommands[i].clearDups();
				getShortcuts(childNode, _scintillaKeyCommands[i]);
				_scintillaKeyCommands[i].setKeyComboByIndex(0, _scintillaKeyCommands[i].getKeyCombo());
				addScintillaModifiedIndex(i);
				KeyCombo kc;
				for (NppXml::Element nextNode = NppXml::firstChildElement(childNode, "NextKey");
					nextNode;
					nextNode = NppXml::nextSiblingElement(nextNode, "NextKey"))
				{
					const char *str = NppXml::attribute(nextNode, "Ctrl");
					if (!str)
						continue;
					kc._isCtrl = (strcmp("yes", str) == 0);

					str = NppXml::attribute(nextNode, "Alt");
					if (!str)
						continue;
					kc._isAlt = (strcmp("yes", str) == 0);

					str = NppXml::attribute(nextNode, "Shift");
					if (!str)
						continue;
					kc._isShift = (strcmp("yes", str) == 0);

					const int key = NppXml::intAttribute(nextNode, "Key", -1);
					if (key == -1)
						continue;
					kc._key = static_cast<unsigned char>(key);
					_scintillaKeyCommands[i].addKeyCombo(kc);
				}
				break;
			}
		}
	}
}

bool NppParameters::getInternalCommandShortcuts(const NppXml::Element& element, CommandShortcut& cs, std::string* folderName)
{
	assert(element && "Element in NppParameters::getInternalCommandShortcuts is null node.");

	const char* name = NppXml::attribute(element, "name", "");

	const bool isCtrl = getBoolAttribute(element, "Ctrl");
	const bool isAlt = getBoolAttribute(element, "Alt");
	const bool isShift = getBoolAttribute(element, "Shift");

	const int key = NppXml::intAttribute(element, "Key", -1);
	if (key == -1)
		return false;

	const int nth = NppXml::intAttribute(element, "nth", -1); // 0 based
	if (nth == 1)
	{
		if (cs.getNth() != nth)
			return false;
	}

	if (folderName)
	{
		*folderName = NppXml::attribute(element, "FolderName", "");
	}

	cs = Shortcut(name, isCtrl, isAlt, isShift, static_cast<unsigned char>(key));
	return true;
}

bool NppParameters::getShortcuts(const NppXml::Element& element, Shortcut& sc, std::string* folderName)
{
	assert(element && "Element in NppParameters::getShortcuts is null node.");

	const char* name = NppXml::attribute(element, "name", "");

	const bool isCtrl = getBoolAttribute(element, "Ctrl");
	const bool isAlt = getBoolAttribute(element, "Alt");
	const bool isShift = getBoolAttribute(element, "Shift");

	const int key = NppXml::intAttribute(element, "Key", -1);
	if (key == -1)
		return false;


	if (folderName)
	{
		*folderName = NppXml::attribute(element, "FolderName", "");
	}

	sc = Shortcut(name, isCtrl, isAlt, isShift, static_cast<unsigned char>(key));
	return true;
}


std::pair<unsigned char, unsigned char> NppParameters::feedUserLang(const NppXml::Element& element)
{
	const int iBegin = _nbUserLang;

	for (NppXml::Element childNode = NppXml::firstChildElement(element, "UserLang");
		childNode && (_nbUserLang < NB_MAX_USER_LANG);
		childNode = NppXml::nextSiblingElement(childNode, "UserLang"))
	{
		std::wstring name = string2wstring(NppXml::attribute(childNode, "name", ""));
		std::wstring ext = string2wstring(NppXml::attribute(childNode, "ext", ""));
		std::string udlVersion = NppXml::attribute(childNode, "udlVersion", "");

		if (name.empty())
		{
			// UserLang name is missing, just ignore this entry
			continue;
		}

		const bool isDarkModeTheme = getBoolAttribute(childNode, "darkModeTheme");

		try {
			_userLangArray[_nbUserLang] = std::make_unique<UserLangContainer>(name.c_str(), ext.c_str(), udlVersion.c_str(), isDarkModeTheme);

			++_nbUserLang;

			NppXml::Element settingsRoot = NppXml::firstChildElement(childNode, "Settings");
			if (!settingsRoot)
				throw std::runtime_error("NppParameters::feedUserLang : Settings node is missing");

			feedUserSettings(settingsRoot);

			NppXml::Element keywordListsRoot = NppXml::firstChildElement(childNode, "KeywordLists");
			if (!keywordListsRoot)
				throw std::runtime_error("NppParameters::feedUserLang : KeywordLists node is missing");

			feedUserKeywordList(keywordListsRoot);

			NppXml::Element stylesRoot = NppXml::firstChildElement(childNode, "Styles");
			if (!stylesRoot)
				throw std::runtime_error("NppParameters::feedUserLang : Styles node is missing");

			feedUserStyles(stylesRoot);

			// styles that were not read from xml file should get default values
			for (int i = 0 ; i < SCE_USER_STYLE_TOTAL_STYLES ; ++i)
			{
				const Style * pStyle = _userLangArray[_nbUserLang - 1]->_styles.findByID(i);
				if (!pStyle)
					_userLangArray[_nbUserLang - 1]->_styles.addStyler(i, string2wstring(globalMappper().styleNameMapper[i]).c_str());
			}
			_userLangArray[_nbUserLang - 1]->_isUnset = false;

		}
		catch (const std::exception&)
		{
			_userLangArray[--_nbUserLang].reset();
		}
	}
	const int iEnd = _nbUserLang;
	return std::pair<unsigned char, unsigned char>(static_cast<unsigned char>(iBegin), static_cast<unsigned char>(iEnd));
}

std::pair<unsigned char, unsigned char> NppParameters::importUDLFromFile(const std::wstring& sourceFile)
{
	NppXml::Document pXmlUserLangDoc = new NppXml::NewDocument();

	std::pair<unsigned char, unsigned char> addUdlResult(static_cast<unsigned char>(0), static_cast<unsigned char>(0));
	
	const bool loadOkay = NppXml::loadFileUDL(pXmlUserLangDoc, sourceFile.c_str());
	if (loadOkay)
	{
		addUdlResult = addUserDefineLangsFromXmlTree(pXmlUserLangDoc);
		unsigned char addedUdlNumber = addUdlResult.second - addUdlResult.first;

		if (addedUdlNumber)
		{
			_pXmlUserLangsDoc.emplace_back(nullptr, sourceFile, true, true, addUdlResult);

			// imported UDL from xml file will be added into default udl, so we should make default udl dirty
			setUdlXmlDirtyFromXmlDoc(_pXmlUserLangDoc._doc);
		}
	}
	delete pXmlUserLangDoc;
	return addUdlResult;
}

bool NppParameters::exportUDLToFile(size_t langIndex2export, const std::wstring& fileName2save)
{
	if (langIndex2export >= NB_MAX_USER_LANG)
		return false;

	if (langIndex2export >= _nbUserLang)
		return false;

	NppXml::Document pNewXmlUserLangDoc = new NppXml::NewDocument();
	NppXml::createNewDeclaration(pNewXmlUserLangDoc);
	NppXml::Element newRoot2export = NppXml::createChildElement(pNewXmlUserLangDoc, "NotepadPlus");

	insertUserLang2Tree(newRoot2export, _userLangArray[langIndex2export].get());
	const bool result = NppXml::saveFileUDL(pNewXmlUserLangDoc, fileName2save.c_str());

	delete pNewXmlUserLangDoc;
	return result;
}

LangType NppParameters::getLangFromExt(const wchar_t *ext)
{
	// first check a user defined extensions for styles
	LexerStylerArray &lexStyleList = getLStylerArray();
	for (size_t i = 0 ; i < lexStyleList.getNbLexer(); ++i)
	{
		const LexerStyler& styler = lexStyleList.getLexerFromIndex(i);
		const wchar_t *extList = styler.getLexerUserExt();

		if (isInList(ext, extList))
			return getLangIDFromStr(styler.getLexerName());
	}

	// then check languages extensions
	int i = getNbLang() - 1;
	while (i >= 0)
	{
		const Lang* l = getLangFromIndex(i--);
		const wchar_t *defList = l->getDefaultExtList();

		if (defList[0] && isInList(ext, defList))
			return l->getLangID();
	}
	return L_TEXT;
}

void NppParameters::setCloudChoice(const wchar_t* pathChoice) const
{
	std::wstring cloudChoicePath = getSettingsFolder();
	cloudChoicePath += L"\\cloud\\";

	if (!doesDirectoryExist(cloudChoicePath.c_str()))
	{
		::CreateDirectory(cloudChoicePath.c_str(), NULL);
	}
	cloudChoicePath += L"choice";

	WcharMbcsConvertor& wmc = WcharMbcsConvertor::getInstance();
	std::string cloudPathA = wmc.wchar2char(pathChoice, SC_CP_UTF8);

	writeFileContent(cloudChoicePath.c_str(), cloudPathA.c_str());
}

void NppParameters::removeCloudChoice() const
{
	std::wstring cloudChoicePath = getSettingsFolder();

	cloudChoicePath += L"\\cloud\\choice";
	if (doesFileExist(cloudChoicePath.c_str()))
	{
		::DeleteFile(cloudChoicePath.c_str());
	}
}

bool NppParameters::isCloudPathChanged() const
{
	if (_initialCloudChoice == _nppGUI._cloudPath)
		return false;
	else if (_initialCloudChoice.size() - _nppGUI._cloudPath.size() == 1)
	{
		wchar_t c = _initialCloudChoice.at(_initialCloudChoice.size()-1);
		if (c == '\\' || c == '/')
		{
			if (_initialCloudChoice.starts_with(_nppGUI._cloudPath))
				return false;
		}
	}
	else if (_nppGUI._cloudPath.size() - _initialCloudChoice.size() == 1)
	{
		wchar_t c = _nppGUI._cloudPath.at(_nppGUI._cloudPath.size() - 1);
		if (c == '\\' || c == '/')
		{
			if (_nppGUI._cloudPath.starts_with(_initialCloudChoice))
				return false;
		}
	}
	return true;
}

bool NppParameters::writeSettingsFilesOnCloudForThe1stTime(const std::wstring& cloudSettingsPath) const
{
	bool isOK = false;

	if (cloudSettingsPath.empty())
		return false;

	// config.xml
	std::wstring cloudConfigPath = cloudSettingsPath;
	pathAppend(cloudConfigPath, L"config.xml");
	if (!doesFileExist(cloudConfigPath.c_str()) && _xmlUserDoc._doc)
	{
		isOK = NppXml::saveFile(_xmlUserDoc._doc, cloudConfigPath.c_str());
		if (!isOK)
			return false;
	}

	// stylers.xml
	std::wstring cloudStylersPath = cloudSettingsPath;
	pathAppend(cloudStylersPath, L"stylers.xml");
	if (!doesFileExist(cloudStylersPath.c_str()) && _pXmlUserStylerDoc._doc)
	{
		isOK = NppXml::saveFile(_pXmlUserStylerDoc._doc, cloudStylersPath.c_str());
		if (!isOK)
			return false;
	}

	// langs.xml
	std::wstring cloudLangsPath = cloudSettingsPath;
	pathAppend(cloudLangsPath, L"langs.xml");
	if (!doesFileExist(cloudLangsPath.c_str()) && _pXmlDoc._doc)
	{
		isOK = NppXml::saveFile(_pXmlDoc._doc, cloudLangsPath.c_str());
		if (!isOK)
			return false;
	}

	// userDefineLang.xml
	std::wstring cloudUserLangsPath = cloudSettingsPath;
	pathAppend(cloudUserLangsPath, L"userDefineLang.xml");
	if (!doesFileExist(cloudUserLangsPath.c_str()) && _pXmlUserLangDoc._doc)
	{
		isOK = NppXml::saveFile(_pXmlUserLangDoc._doc, cloudUserLangsPath.c_str());
		if (!isOK)
			return false;
	}

	// shortcuts.xml
	std::wstring cloudShortcutsPath = cloudSettingsPath;
	pathAppend(cloudShortcutsPath, SHORTCUTSXML_FILENAME);
	if (!doesFileExist(cloudShortcutsPath.c_str()) && _pXmlShortcutDoc)
	{
		isOK = NppXml::saveFileShortcut(_pXmlShortcutDoc, cloudShortcutsPath.c_str());
		if (!isOK)
			return false;
	}

	// contextMenu.xml
	std::wstring cloudContextMenuPath = cloudSettingsPath;
	pathAppend(cloudContextMenuPath, L"contextMenu.xml");
	if (!doesFileExist(cloudContextMenuPath.c_str()) && _pXmlContextMenuDoc)
	{
		isOK = NppXml::saveFile(_pXmlContextMenuDoc, cloudContextMenuPath.c_str());
		if (!isOK)
			return false;
	}

	// nativeLang.xml
	std::wstring cloudNativeLangPath = cloudSettingsPath;
	pathAppend(cloudNativeLangPath, L"nativeLang.xml");
	if (!doesFileExist(cloudNativeLangPath.c_str()) && _pXmlNativeLangDoc != nullptr)
	{
		isOK = NppXml::saveFile(_pXmlNativeLangDoc, cloudNativeLangPath.c_str());
		if (!isOK)
			return false;
	}

	return true;
}

/*
Default UDL + Created + Imported
*/
void NppParameters::writeDefaultUDL()
{
	bool firstCleanDone = false;
	std::vector<std::pair<bool, bool>> deleteState; //vector< pair<toDel, isInDefaultSharedContainer> >
	for (const auto& udl : _pXmlUserLangsDoc)
	{
		if (!_pXmlUserLangDoc._doc)
		{
			_pXmlUserLangDoc._doc = new NppXml::NewDocument();
			NppXml::createNewDeclaration(_pXmlUserLangDoc._doc);
			NppXml::createChildElement(_pXmlUserLangDoc._doc, "NotepadPlus");
		}

		bool toDelete = (udl._indexRange.second - udl._indexRange.first) == 0;
		deleteState.emplace_back(toDelete, udl._isInDefaultSharedContainer);
		if ((!udl._udlXmlDoc || udl._udlXmlDoc == _pXmlUserLangDoc._doc) && udl._isDirty && !toDelete) // new created or/and imported UDL plus _pXmlUserLangDoc (if exist)
		{
			NppXml::Element root = NppXml::firstChildElement(_pXmlUserLangDoc._doc, "NotepadPlus");
			if (root && !firstCleanDone)
			{
				NppXml::deleteChild(_pXmlUserLangDoc._doc, root);
				NppXml::createChildElement(_pXmlUserLangDoc._doc, "NotepadPlus");
				firstCleanDone = true;
			}

			root = NppXml::firstChildElement(_pXmlUserLangDoc._doc, "NotepadPlus");

			for (int i = udl._indexRange.first; i < udl._indexRange.second; ++i)
			{
				insertUserLang2Tree(root, _userLangArray[i].get());
			}
		}
	}

	bool deleteAll = true;
	for (const auto& udlState : deleteState)
	{
		if (!udlState.first && udlState.second) // if not marked to be delete udl is (&&) in default shared container (ie. "userDefineLang.xml" file)
		{
			deleteAll = false; // let's keep "userDefineLang.xml" file
			break;
		}
	}

	if (firstCleanDone) // at least one udl is for saving, the udl to be deleted are ignored
	{
		static_cast<void>(NppXml::saveFileUDL(_pXmlUserLangDoc._doc, _userDefineLangPath.c_str()));
	}
	else if (deleteAll)
	{
		if (doesFileExist(_userDefineLangPath.c_str()))
		{
			::DeleteFile(_userDefineLangPath.c_str());
		}
	}
	// else nothing to change, do nothing
}

void NppParameters::writeNonDefaultUDL()
{
	for (auto& udl : _pXmlUserLangsDoc)
	{
		if (udl._isDirty && udl._udlXmlDoc != nullptr && udl._udlXmlDoc != _pXmlUserLangDoc._doc)
		{
			if (udl._indexRange.second == udl._indexRange.first) // no more udl for this xmldoc container
			{
				// no need to save, delete file
				const std::wstring& docFilePath = udl._path;
				if (!docFilePath.empty() && doesFileExist(docFilePath.c_str()))
				{
					::DeleteFile(docFilePath.c_str());
				}
			}
			else
			{
				NppXml::Element root = NppXml::firstChildElement(udl._udlXmlDoc, "NotepadPlus");
				if (root)
				{
					NppXml::deleteChild(udl._udlXmlDoc, root);
				}

				NppXml::createChildElement(udl._udlXmlDoc, "NotepadPlus");

				root = NppXml::firstChildElement(udl._udlXmlDoc, "NotepadPlus");

				for (int i = udl._indexRange.first; i < udl._indexRange.second; ++i)
				{
					insertUserLang2Tree(root, _userLangArray[i].get());
				}
				static_cast<void>(NppXml::saveFileUDL(udl._udlXmlDoc, udl._path.c_str()));
			}
		}
	}
}

void NppParameters::writeNeed2SaveUDL()
{
	writeDefaultUDL();
	writeNonDefaultUDL();
}


void NppParameters::insertCmd(NppXml::Element& cmdRoot, const CommandShortcut& cmd)
{
	const KeyCombo& key = cmd.getKeyCombo();
	NppXml::Element sc = NppXml::createChildElement(cmdRoot, "Shortcut");

	NppXml::setAttribute(sc, "id", cmd.getID());
	setBoolAttribute(sc, "Ctrl", key._isCtrl);
	setBoolAttribute(sc, "Alt", key._isAlt);
	setBoolAttribute(sc, "Shift", key._isShift);
	NppXml::setAttribute(sc, "Key", key._key);
	if (cmd.getNth() != 0)
		NppXml::setAttribute(sc, "nth", cmd.getNth());
}


void NppParameters::insertMacro(NppXml::Element& macrosRoot, const MacroShortcut& macro, const std::string& folderName)
{
	const KeyCombo& key = macro.getKeyCombo();
	NppXml::Element macroRoot = NppXml::createChildElement(macrosRoot, "Macro");

	NppXml::setAttribute(macroRoot, "name", macro.getMenuName());
	setBoolAttribute(macroRoot, "Ctrl", key._isCtrl);
	setBoolAttribute(macroRoot, "Alt", key._isAlt);
	setBoolAttribute(macroRoot, "Shift", key._isShift);
	NppXml::setAttribute(macroRoot, "Key", key._key);
	if (!folderName.empty())
	{
		NppXml::setAttribute(macroRoot, "FolderName", folderName);
	}

	for (size_t i = 0, len = macro._macro.size(); i < len; ++i)
	{
		const recordedMacroStep& action = macro._macro[i];
		NppXml::Element actionNode = NppXml::createChildElement(macroRoot, "Action");

		NppXml::setAttribute(actionNode, "type", action._macroType);
		NppXml::setAttribute(actionNode, "message", action._message);
		NppXml::setAttribute(actionNode, "wParam", action._wParameter);
		NppXml::setAttribute(actionNode, "lParam", action._lParameter);
		NppXml::setAttribute(actionNode, "sParam", action._sParameter);
	}
}


void NppParameters::insertUserCmd(NppXml::Element& userCmdRoot, const UserCommand& userCmd, const std::string& folderName)
{
	const KeyCombo& key = userCmd.getKeyCombo();
	NppXml::Element cmdRoot = NppXml::createChildElement(userCmdRoot, "Command");

	NppXml::setAttribute(cmdRoot, "name", userCmd.getMenuName());
	setBoolAttribute(cmdRoot, "Ctrl", key._isCtrl);
	setBoolAttribute(cmdRoot, "Alt", key._isAlt);
	setBoolAttribute(cmdRoot, "Shift", key._isShift);
	NppXml::setAttribute(cmdRoot, "Key", key._key);

	NppXml::createChildText(cmdRoot, userCmd._cmd);
	if (!folderName.empty())
	{
		NppXml::setAttribute(cmdRoot, "FolderName", folderName);
	}
}


void NppParameters::insertPluginCmd(NppXml::Element& pluginCmdRoot, const PluginCmdShortcut& pluginCmd)
{
	const KeyCombo& key = pluginCmd.getKeyCombo();
	NppXml::Element pluginCmdNode = NppXml::createChildElement(pluginCmdRoot, "PluginCommand");

	NppXml::setAttribute(pluginCmdNode, "moduleName", pluginCmd.getModuleName());
	NppXml::setAttribute(pluginCmdNode, "internalID", pluginCmd.getInternalID());
	setBoolAttribute(pluginCmdNode, "Ctrl", key._isCtrl);
	setBoolAttribute(pluginCmdNode, "Alt", key._isAlt);
	setBoolAttribute(pluginCmdNode, "Shift", key._isShift);
	NppXml::setAttribute(pluginCmdNode, "Key", key._key);
}


void NppParameters::insertScintKey(NppXml::Element& scintKeyRoot, const ScintillaKeyMap& scintKeyMap)
{
	NppXml::Element keyRoot = NppXml::createChildElement(scintKeyRoot, "ScintKey");

	NppXml::setAttribute(keyRoot, "ScintID", scintKeyMap.getScintillaKeyID());
	NppXml::setAttribute(keyRoot, "menuCmdID", scintKeyMap.getMenuCmdID());

	//Add main shortcut
	KeyCombo key = scintKeyMap.getKeyComboByIndex(0);
	setBoolAttribute(keyRoot, "Ctrl", key._isCtrl);
	setBoolAttribute(keyRoot, "Alt", key._isAlt);
	setBoolAttribute(keyRoot, "Shift", key._isShift);
	NppXml::setAttribute(keyRoot, "Key", key._key);

	//Add additional shortcuts
	size_t size = scintKeyMap.getSize();
	if (size > 1)
	{
		for (size_t i = 1; i < size; ++i)
		{
			key = scintKeyMap.getKeyComboByIndex(i);
			NppXml::Element keyNext = NppXml::createChildElement(keyRoot, "NextKey");

			setBoolAttribute(keyNext, "Ctrl", key._isCtrl);
			setBoolAttribute(keyNext, "Alt", key._isAlt);
			setBoolAttribute(keyNext, "Shift", key._isShift);
			NppXml::setAttribute(keyNext, "Key", key._key);
		}
	}
}


void NppParameters::writeSession(const Session& session, const wchar_t* fileName)
{
	const wchar_t* sessionPathName = fileName ? fileName : _sessionPath.c_str();

	//
	// Make sure session file is not read-only
	//
	removeReadOnlyFlagFromFileAttributes(sessionPathName);

	//
	// Backup session file before overriting it
	//
	std::wstring backupPathName;
	BOOL doesBackupCopyExist = FALSE;
	if (doesFileExist(sessionPathName))
	{
		backupPathName = sessionPathName;
		backupPathName += SESSION_BACKUP_EXT;

		// Make sure backup file is not read-only, if it exists
		removeReadOnlyFlagFromFileAttributes(backupPathName.c_str());
		doesBackupCopyExist = CopyFile(sessionPathName, backupPathName.c_str(), FALSE);
		if (!doesBackupCopyExist && !isEndSessionCritical())
		{
			std::wstring errTitle = L"Session file backup error: ";
			errTitle += GetLastErrorAsString(0);
			NppDarkMode::darkMessageBoxW(nullptr, sessionPathName, errTitle.c_str(), MB_OK);
		}
	}

	//
	// Prepare for writing
	//
	NppXml::Document pXmlSessionDoc = new NppXml::NewDocument();
	NppXml::createNewDeclaration(pXmlSessionDoc);
	NppXml::Element root = NppXml::createChildElement(pXmlSessionDoc, "NotepadPlus");

	if (root)
	{
		NppXml::Element sessionNode = NppXml::createChildElement(root, "Session");
		NppXml::setAttribute(sessionNode, "activeView", session._activeView);

		struct ViewElem {
			NppXml::Element viewNode;
			const std::vector<sessionFileInfo>* viewFiles = nullptr;
			size_t activeIndex = 0;
		};

		static constexpr int nbElem = 2;
		ViewElem viewElems[nbElem]{
			ViewElem{.viewNode = NppXml::createChildElement(sessionNode, "mainView"), .viewFiles = &session._mainViewFiles, .activeIndex = session._activeMainIndex},
			ViewElem{.viewNode = NppXml::createChildElement(sessionNode, "subView"), .viewFiles = &session._subViewFiles, .activeIndex = session._activeSubIndex}
		};

		for (size_t k = 0; k < nbElem ; ++k)
		{
			NppXml::setAttribute(viewElems[k].viewNode, "activeIndex", viewElems[k].activeIndex);
			const std::vector<sessionFileInfo>& viewSessionFiles = *(viewElems[k].viewFiles);

			for (const auto& vsFile : viewSessionFiles)
			{
				NppXml::Element fileNameNode = NppXml::createChildElement(viewElems[k].viewNode, "File");

				NppXml::setAttribute(fileNameNode, "firstVisibleLine", vsFile._firstVisibleLine);
				NppXml::setAttribute(fileNameNode, "xOffset", vsFile._xOffset);
				NppXml::setAttribute(fileNameNode, "scrollWidth", vsFile._scrollWidth);
				NppXml::setAttribute(fileNameNode, "startPos", vsFile._startPos);
				NppXml::setAttribute(fileNameNode, "endPos", vsFile._endPos);
				NppXml::setAttribute(fileNameNode, "selMode", vsFile._selMode);
				NppXml::setAttribute(fileNameNode, "offset", vsFile._offset);
				NppXml::setAttribute(fileNameNode, "wrapCount", vsFile._wrapCount);
				NppXml::setAttribute(fileNameNode, "lang", wstring2string(vsFile._langName));
				NppXml::setAttribute(fileNameNode, "encoding", vsFile._encoding);
				setBoolAttribute(fileNameNode, "userReadOnly", (vsFile._isUserReadOnly && !vsFile._isMonitoring));
				NppXml::setAttribute(fileNameNode, "filename", wstring2string(vsFile._fileName));
				NppXml::setAttribute(fileNameNode, "backupFilePath", wstring2string(vsFile._backupFilePath));
				NppXml::setAttribute(fileNameNode, "originalFileLastModifTimestamp", vsFile._originalFileLastModifTimestamp.dwLowDateTime);
				NppXml::setAttribute(fileNameNode, "originalFileLastModifTimestampHigh", vsFile._originalFileLastModifTimestamp.dwHighDateTime);
				NppXml::setAttribute(fileNameNode, "tabColourId", vsFile._individualTabColour);
				setBoolAttribute(fileNameNode, "RTL", vsFile._isRTL);
				setBoolAttribute(fileNameNode, "tabPinned", vsFile._isPinned);

				// Save this info only when it's an untitled entry
				if (vsFile._isUntitledTabRenamed)
					NppXml::setAttribute(fileNameNode, "untitleTabRenamed", "yes");

				// docMap
				NppXml::setAttribute(fileNameNode, "mapFirstVisibleDisplayLine", vsFile._mapPos._firstVisibleDisplayLine);
				NppXml::setAttribute(fileNameNode, "mapFirstVisibleDocLine", vsFile._mapPos._firstVisibleDocLine);
				NppXml::setAttribute(fileNameNode, "mapLastVisibleDocLine", vsFile._mapPos._lastVisibleDocLine);
				NppXml::setAttribute(fileNameNode, "mapNbLine", vsFile._mapPos._nbLine);
				NppXml::setAttribute(fileNameNode, "mapHigherPos", vsFile._mapPos._higherPos);
				NppXml::setAttribute(fileNameNode, "mapWidth", vsFile._mapPos._width);
				NppXml::setAttribute(fileNameNode, "mapHeight", vsFile._mapPos._height);
				NppXml::setAttribute(fileNameNode, "mapKByteInDoc", vsFile._mapPos._KByteInDoc);
				NppXml::setAttribute(fileNameNode, "mapWrapIndentMode", vsFile._mapPos._wrapIndentMode);
				setBoolAttribute(fileNameNode, "mapIsWrap", vsFile._mapPos._isWrap);

				for (const auto& markLine : vsFile._marks)
				{
					NppXml::Element markNode = NppXml::createChildElement(fileNameNode, "Mark");
					NppXml::setAttribute(markNode, "line", markLine);
				}

				for (const auto& foldLine : vsFile._foldStates)
				{
					NppXml::Element foldNode = NppXml::createChildElement(fileNameNode, "Fold");
					NppXml::setAttribute(foldNode, "line", foldLine);
				}
			}
		}

		if (session._includeFileBrowser)
		{
			// Node structure and naming corresponds to config.xml
			NppXml::Element fileBrowserRootNode = NppXml::createChildElement(sessionNode, "FileBrowser");
			NppXml::setAttribute(fileBrowserRootNode, "latestSelectedItem", wstring2string(session._fileBrowserSelectedItem));
			for (const auto& fbRootInfo : session._fileBrowserRoots)
			{
				NppXml::Element fileNameNode = NppXml::createChildElement(fileBrowserRootNode, "root");
				NppXml::setAttribute(fileNameNode, "foldername", wstring2string(fbRootInfo._root));

				for (const auto& i : fbRootInfo._expandedPaths)
				{
					NppXml::Element expNode = NppXml::createChildElement(fileNameNode, "expanded");
					NppXml::setAttribute(expNode, "path", wstring2string(i));
				}
			}
		}
	}

	//
	// Write the session file
	//
	bool sessionSaveOK = NppXml::saveFile(pXmlSessionDoc, sessionPathName);

	//
	// Double checking: prevent written session file corrupted while writting
	//
	if (sessionSaveOK)
	{
		NppXml::Document pXmlSessionCheck = new NppXml::NewDocument();
		sessionSaveOK = NppXml::loadFile(pXmlSessionCheck, sessionPathName);
		if (sessionSaveOK)
		{
			Session sessionCheck;
			sessionSaveOK = getSessionFromXmlTree(pXmlSessionCheck, sessionCheck); // test only
		}
		delete pXmlSessionCheck;
	}
	else if (!isEndSessionCritical())
	{
		NppDarkMode::darkMessageBoxW(nullptr, sessionPathName, L"Error of saving session XML file", MB_OK | MB_APPLMODAL | MB_ICONWARNING);
	}

	//
	// If error after double checking, restore session backup file
	//
	if (!sessionSaveOK)
	{
		if (doesBackupCopyExist) // session backup file exists, restore it
		{
			if (!isEndSessionCritical())
				NppDarkMode::darkMessageBoxW(nullptr, backupPathName.c_str(), L"Saving session error - restoring from the backup:", MB_OK | MB_APPLMODAL | MB_ICONWARNING);

			std::wstring sessionPathNameFail2Load = sessionPathName;
			sessionPathNameFail2Load += L".fail2Load";
			ReplaceFile(sessionPathName, backupPathName.c_str(), sessionPathNameFail2Load.c_str(), REPLACEFILE_IGNORE_MERGE_ERRORS | REPLACEFILE_IGNORE_ACL_ERRORS, 0, 0);
		}
	}
	/*
	 * Keep session backup file in case of corrupted session file
	 *
	else
	{
		if (backupPathName[0]) // session backup file not useful, delete it
		{
			::DeleteFile(backupPathName);
		}
	}
	*/

	delete pXmlSessionDoc;
}


void NppParameters::writeShortcuts()
{
	if (!_isAnyShortcutModified) return;

	if (!_pXmlShortcutDoc)
	{
		//do the treatment
		_pXmlShortcutDoc = new NppXml::NewDocument();
		NppXml::createNewDeclaration(_pXmlShortcutDoc);
	}

	NppXml::Element root = NppXml::firstChildElement(_pXmlShortcutDoc, "NotepadPlus");
	if (!root)
	{
		root = NppXml::createChildElement(_pXmlShortcutDoc, "NotepadPlus");
	}

	NppXml::Element cmdRoot = NppXml::firstChildElement(root, "InternalCommands");
	if (cmdRoot)
		NppXml::deleteChild(root, cmdRoot);

	cmdRoot = NppXml::createChildElement(root, "InternalCommands");

	for (size_t i = 0, len = _customizedShortcuts.size(); i < len ; ++i)
	{
		size_t index = _customizedShortcuts[i];
		CommandShortcut csc = _shortcuts[index];
		insertCmd(cmdRoot, csc);
	}

	NppXml::Element macrosRoot = NppXml::firstChildElement(root, "Macros");
	if (macrosRoot)
		NppXml::deleteChild(root, macrosRoot);

	macrosRoot = NppXml::createChildElement(root, "Macros");

	for (size_t i = 0, len = _macros.size(); i < len ; ++i)
	{
		insertMacro(macrosRoot, _macros[i], wstring2string(_macroMenuItems.getItemFromIndex(i)._parentFolderName, CP_UTF8));
	}

	NppXml::Element userCmdRoot = NppXml::firstChildElement(root, "UserDefinedCommands");
	if (userCmdRoot)
		NppXml::deleteChild(root, userCmdRoot);

	userCmdRoot = NppXml::createChildElement(root, "UserDefinedCommands");

	for (size_t i = 0, len = _userCommands.size(); i < len ; ++i)
	{
		insertUserCmd(userCmdRoot, _userCommands[i], wstring2string(_runMenuItems.getItemFromIndex(i)._parentFolderName, CP_UTF8));
	}

	NppXml::Element pluginCmdRoot = NppXml::firstChildElement(root, "PluginCommands");
	if (pluginCmdRoot)
		NppXml::deleteChild(root, pluginCmdRoot);

	pluginCmdRoot = NppXml::createChildElement(root, "PluginCommands");

	for (size_t i = 0, len = _pluginCustomizedCmds.size(); i < len ; ++i)
	{
		insertPluginCmd(pluginCmdRoot, _pluginCommands[_pluginCustomizedCmds[i]]);
	}

	NppXml::Element scitillaKeyRoot = NppXml::firstChildElement(root, "ScintillaKeys");
	if (scitillaKeyRoot)
		NppXml::deleteChild(root, scitillaKeyRoot);

	scitillaKeyRoot = NppXml::createChildElement(root, "ScintillaKeys");

	for (size_t i = 0, len = _scintillaModifiedKeyIndices.size(); i < len ; ++i)
	{
		insertScintKey(scitillaKeyRoot, _scintillaKeyCommands[_scintillaModifiedKeyIndices[i]]);
	}

	bool isSaveShortcutOK = NppXml::saveFileShortcut(_pXmlShortcutDoc, _shortcutsPath.c_str());

	// Recalculate the hash of shortcuts file after saving it successfully, and write it into config.xml, to be used for next time shortcut file integrity check
	if (isSaveShortcutOK)
	{
		// Read back the file content as bytes
		std::string fileContent = getFileContent(_shortcutsPath.c_str());

		// Compute HMAC
		std::string machineGUID = getMachineGUID();
		std::string hmac = computeHMAC(machineGUID, fileContent);

		// Store in config.xml
		_nppGUI._shortcutsXmlHmacInConfig = hmac;
	}
}


int NppParameters::addUserLangToEnd(const UserLangContainer* userLang, const wchar_t *newName)
{
	if (isExistingUserLangName(newName))
		return -1;
	unsigned char iBegin = _nbUserLang;
	_userLangArray[_nbUserLang] = std::make_unique<UserLangContainer>(*userLang);
	_userLangArray[_nbUserLang]->_name = newName;
	++_nbUserLang;
	unsigned char iEnd = _nbUserLang;

	_pXmlUserLangsDoc.emplace_back(nullptr, L"", true, true, std::pair(iBegin, iEnd));

	// imported UDL from xml file will be added into default udl, so we should make default udl dirty
	setUdlXmlDirtyFromXmlDoc(_pXmlUserLangDoc._doc);

	return _nbUserLang-1;
}


void NppParameters::removeUserLang(size_t index)
{
	if (index >= _nbUserLang)
		return;
	_userLangArray[index].reset();

	for (size_t i = index; i < (size_t{ _nbUserLang } - 1); ++i)
		_userLangArray[i] = std::move(_userLangArray[i + 1]);
	_userLangArray[_nbUserLang--].reset();

	removeIndexFromXmlUdls(index);
}


void NppParameters::feedUserSettings(const NppXml::Element& settingsRoot)
{
	NppXml::Element globalSettingNode = NppXml::firstChildElement(settingsRoot, "Global");
	if (globalSettingNode)
	{
		_userLangArray[_nbUserLang - 1]->_isCaseIgnored = getBoolAttribute(globalSettingNode, "caseIgnored");
		_userLangArray[_nbUserLang - 1]->_allowFoldOfComments = getBoolAttribute(globalSettingNode, "allowFoldOfComments");

		_userLangArray[_nbUserLang - 1]->_forcePureLC = NppXml::intAttribute(globalSettingNode, "forcePureLC", 0);
		_userLangArray[_nbUserLang - 1]->_decimalSeparator = NppXml::intAttribute(globalSettingNode, "decimalSeparator", 0);

		_userLangArray[_nbUserLang - 1]->_foldCompact = getBoolAttribute(globalSettingNode, "foldCompact");
	}

	NppXml::Element prefixNode = NppXml::firstChildElement(settingsRoot, "Prefix");
	if (prefixNode)
	{
		const char* udlVersion = _userLangArray[_nbUserLang - 1]->getUdlVersion();
		if (std::strcmp(udlVersion, "2.1") == 0 || std::strcmp(udlVersion, "2.0") == 0)
		{
			for (int i = 0 ; i < SCE_USER_TOTAL_KEYWORD_GROUPS ; ++i)
			{
				_userLangArray[_nbUserLang - 1]->_isPrefix[i] = getBoolAttribute(prefixNode, globalMappper().keywordNameMapper[i + SCE_USER_KWLIST_KEYWORDS1].c_str());
			}
		}
		else	// support for old style (pre 2.0)
		{
			static constexpr const char names[SCE_USER_TOTAL_KEYWORD_GROUPS][7] = { "words1", "words2", "words3", "words4" };
			for (int i = 0 ; i < 4 ; ++i)
			{
				_userLangArray[_nbUserLang - 1]->_isPrefix[i] = getBoolAttribute(prefixNode, names[i]);
			}
		}
	}
}


void NppParameters::feedUserKeywordList(const NppXml::Element& element)
{
	const char* udlVersion = _userLangArray[_nbUserLang - 1]->getUdlVersion();

	for (NppXml::Element childNode = NppXml::firstChildElement(element, "Keywords");
		childNode;
		childNode = NppXml::nextSiblingElement(childNode, "Keywords"))
	{
		const char* keywordsName = NppXml::attribute(childNode, "name", "");
		NppXml::Node valueNode = NppXml::firstChild(childNode);
		if (valueNode)
		{
			const char* kwl = nullptr;
			if (!udlVersion[0] && std::strcmp(keywordsName, "Delimiters") == 0) // support for old style (pre 2.0)
			{
				std::string temp;
				kwl = NppXml::getValue(valueNode);

				temp += "00";  if (kwl[0] != '0') temp += kwl[0]; temp += " 01";
				temp += " 02"; if (kwl[3] != '0') temp += kwl[3];
				temp += " 03"; if (kwl[1] != '0') temp += kwl[1]; temp += " 04";
				temp += " 05"; if (kwl[4] != '0') temp += kwl[4];
				temp += " 06"; if (kwl[2] != '0') temp += kwl[2]; temp += " 07";
				temp += " 08"; if (kwl[5] != '0') temp += kwl[5];

				temp += " 09 10 11 12 13 14 15 16 17 18 19 20 21 22 23";
				_userLangArray[_nbUserLang - 1]->_keywordLists[SCE_USER_KWLIST_DELIMITERS] = temp;
			}
			else if (std::strcmp(keywordsName, "Comment") == 0)
			{
				kwl = NppXml::getValue(valueNode);
				std::string temp{" "};

				temp += kwl;
				size_t pos = 0;

				pos = temp.find(" 0");
				while (pos != std::string::npos)
				{
					temp.replace(pos, 2, " 00");
					pos = temp.find(" 0", pos + 1);
				}
				pos = temp.find(" 1");
				while (pos != std::string::npos)
				{
					temp.replace(pos, 2, " 03");
					pos = temp.find(" 1");
				}
				pos = temp.find(" 2");
				while (pos != std::string::npos)
				{
					temp.replace(pos, 2, " 04");
					pos = temp.find(" 2");
				}

				temp += " 01 02";
				if (temp[0] == ' ')
					temp.erase(0, 1);
				_userLangArray[_nbUserLang - 1]->_keywordLists[SCE_USER_KWLIST_COMMENTS] = temp;
			}
			else
			{
				kwl = NppXml::getValue(valueNode);
				if (globalMappper().keywordIdMapper.find(keywordsName) != globalMappper().keywordIdMapper.end())
				{
					int id = globalMappper().keywordIdMapper[keywordsName];
					if (std::strlen(kwl) < max_char)
					{
						_userLangArray[_nbUserLang - 1]->_keywordLists[id] = kwl;
					}
					else
					{
						_userLangArray[_nbUserLang - 1]->_keywordLists[id] = "imported string too long, needs to be < max_char(30720)";
					}
				}
			}
		}
	}
}

void NppParameters::feedUserStyles(const NppXml::Element& element)
{
	for (NppXml::Element childNode = NppXml::firstChildElement(element, "WordsStyle");
		childNode;
		childNode = NppXml::nextSiblingElement(childNode, "WordsStyle"))
	{
		const std::string styleName = NppXml::attribute(childNode, "name", "");
		if (!styleName.empty())
		{
			if (globalMappper().styleIdMapper.find(styleName) != globalMappper().styleIdMapper.end())
			{
				int id = globalMappper().styleIdMapper[styleName];
				_userLangArray[_nbUserLang - 1]->_styles.addStyler((id | L_USER << 16), childNode);
			}
		}
	}
}

bool NppParameters::feedStylerArray(const NppXml::Element& element)
{
	NppXml::Element styleRoot = NppXml::firstChildElement(element, "LexerStyles");
	if (!styleRoot) return false;

	// For each lexer
	for (NppXml::Element childNode = NppXml::firstChildElement(styleRoot, "LexerType");
		childNode;
		childNode = NppXml::nextSiblingElement(childNode, "LexerType") )
	{
		const char* lexerName = NppXml::attribute(childNode, "name");
		const char* lexerDesc = NppXml::attribute(childNode, "desc");
		const char* lexerUserExt = NppXml::attribute(childNode, "ext");
		if (lexerName)
		{
			_lexerStylerVect.addLexerStyler(lexerName, lexerDesc, lexerUserExt, childNode);
			if (getBoolAttribute(childNode, "excluded"))
			{
				int index = getExternalLangIndexFromName(string2wstring(lexerName).c_str());
				if (index != -1)
					_nppGUI._excludedLangList.emplace_back(static_cast<LangType>(index + L_EXTERNAL));
			}
		}
	}

	_lexerStylerVect.sort();

	// The global styles for all lexers
	NppXml::Element globalStyleRoot = NppXml::firstChildElement(element, "GlobalStyles");
	if (!globalStyleRoot) return false;

	for (NppXml::Element childNode = NppXml::firstChildElement(globalStyleRoot, "WidgetStyle");
		childNode;
		childNode = NppXml::nextSiblingElement(childNode, "WidgetStyle") )
	{
		const char* name = NppXml::attribute(childNode, "name");
		if (name && _widgetStyleArray.findByName(string2wstring(name)))
			continue;

		const int styleID = NppXml::intAttribute(childNode, "styleID", -1);
		if (styleID != -1)
		{
			_widgetStyleArray.addStyler(styleID, childNode);
		}
	}

	return true;
}


int NppParameters::addStyleDefaultColors(
	NppXml::Element& globalStyleRoot,
	const std::wstring& name,
	const std::string& fgColor,
	const std::string& bgColor,
	const std::wstring& fromStyle,
	const std::string& styleID
)
{
	int result = 0;
	const Style* pStyle = _widgetStyleArray.findByName(name);
	if (!pStyle)
	{
		NppXml::Element newStyle = NppXml::createChildElement(globalStyleRoot, "WidgetStyle");
		NppXml::setAttribute(newStyle, "name", wstring2string(name));
		NppXml::setAttribute(newStyle, "styleID", styleID);

		const Style* pStyleFrom = fromStyle.empty() ? nullptr : _widgetStyleArray.findByName(fromStyle);
		if (pStyleFrom)
		{
			static constexpr size_t bufSize = 7;
			if (!fgColor.empty())
			{
				char strColor[bufSize] = { '\0' };
				std::snprintf(strColor, bufSize, "%.6lX", RGBHEX(pStyleFrom->_fgColor));
				NppXml::setAttribute(newStyle, "fgColor", strColor);
			}

			if (!bgColor.empty())
			{
				char strColor[bufSize] = { '\0' };
				std::snprintf(strColor, bufSize, "%.6lX", RGBHEX(pStyleFrom->_bgColor));
				NppXml::setAttribute(newStyle, "bgColor", strColor);
			}

			result = 2;
		}
		else
		{
			if (!fgColor.empty())
			{
				NppXml::setAttribute(newStyle, "fgColor", fgColor);
			}

			if (!bgColor.empty())
			{
				NppXml::setAttribute(newStyle, "bgColor", bgColor);
			}

			result = 1;
		}


		if (!fgColor.empty() || !bgColor.empty())
		{
			_widgetStyleArray.addStyler(0, newStyle);
			return result;
		}
		return -1;
	}
	return result;
}

void NppParameters::addDefaultStyles(const NppXml::Element& element)
{
	// check void ScintillaEditView::performGlobalStyles() for default colors

	NppXml::Element globalStyleRoot = NppXml::firstChildElement(element, "GlobalStyles");
	if (!globalStyleRoot) return;

	for (NppXml::Element childNode = NppXml::firstChildElement(globalStyleRoot, "WidgetStyle");
		childNode;
		childNode = NppXml::nextSiblingElement(childNode, "WidgetStyle"))
	{
		const int styleID = NppXml::intAttribute(childNode, "styleID", -1);
		if (styleID != -1)
		{
			_widgetStyleArray.addStyler(styleID, childNode);
		}
	}

	addStyleDefaultColors(globalStyleRoot, L"Multi-selected text color", "", "C0C0C0", L"Selected text colour"); // liteGrey
	addStyleDefaultColors(globalStyleRoot, L"Multi-edit carets color", "404040", "", L"Caret colour"); // darkGrey

	addStyleDefaultColors(globalStyleRoot, L"Bookmark margin", "", "C0C0C0", L"Line number margin");
	addStyleDefaultColors(globalStyleRoot, L"Change History margin", "", "C0C0C0", L"Line number margin");

	addStyleDefaultColors(globalStyleRoot, L"Change History modified", "FF8000", "FF8000");
	addStyleDefaultColors(globalStyleRoot, L"Change History revert modified", "A0C000", "A0C000");
	addStyleDefaultColors(globalStyleRoot, L"Change History revert origin", "40A0BF", "40A0BF");
	addStyleDefaultColors(globalStyleRoot, L"Change History saved", "00A000", "00A000");

	addStyleDefaultColors(globalStyleRoot, FINDDLG_STAUSNOTFOUND_COLOR, "FF0000", "");
	addStyleDefaultColors(globalStyleRoot, FINDDLG_STAUSMESSAGE_COLOR, "0000FF", "");
	addStyleDefaultColors(globalStyleRoot, FINDDLG_STAUSREACHED_COLOR, "008000", "");

	addStyleDefaultColors(globalStyleRoot, TABBAR_INDIVIDUALCOLOR_1, "", "F3F0CB");
	addStyleDefaultColors(globalStyleRoot, TABBAR_INDIVIDUALCOLOR_2, "", "DBF3CB");
	addStyleDefaultColors(globalStyleRoot, TABBAR_INDIVIDUALCOLOR_3, "", "CBDBF3");
	addStyleDefaultColors(globalStyleRoot, TABBAR_INDIVIDUALCOLOR_4, "", "F3DBCB");
	addStyleDefaultColors(globalStyleRoot, TABBAR_INDIVIDUALCOLOR_5, "", "F3CBEE");
	addStyleDefaultColors(globalStyleRoot, TABBAR_INDIVIDUALCOLOR_DM_1, "", "807848");
	addStyleDefaultColors(globalStyleRoot, TABBAR_INDIVIDUALCOLOR_DM_2, "", "568048");
	addStyleDefaultColors(globalStyleRoot, TABBAR_INDIVIDUALCOLOR_DM_3, "", "507094");
	addStyleDefaultColors(globalStyleRoot, TABBAR_INDIVIDUALCOLOR_DM_4, "", "804849");
	addStyleDefaultColors(globalStyleRoot, TABBAR_INDIVIDUALCOLOR_DM_5, "", "754880");

	addStyleDefaultColors(globalStyleRoot, L"EOL custom color", "DADADA");
	addStyleDefaultColors(globalStyleRoot, g_npcStyleName, "DADADA", "", L"White space symbol");
}

void LexerStylerArray::addLexerStyler(const char* lexerName, const char* lexerDesc, const char* lexerUserExt, const NppXml::Element& lexerNode)
{
	_lexerStylerVect.emplace_back();
	LexerStyler& ls = _lexerStylerVect.back();

	if (lexerName)
		ls.setLexerName(string2wstring(lexerName).c_str());

	if (lexerDesc)
		ls.setLexerDesc(string2wstring(lexerDesc).c_str());

	if (lexerUserExt)
		ls.setLexerUserExt(string2wstring(lexerUserExt).c_str());

	for (NppXml::Element childNode = NppXml::firstChildElement(lexerNode, "WordsStyle");
		childNode;
		childNode = NppXml::nextSiblingElement(childNode, "WordsStyle"))
	{
		const int styleID = NppXml::intAttribute(childNode, "styleID", -1);
		if (styleID != -1)
		{
			ls.addStyler(styleID, childNode);
		}
	}
}

void StyleArray::addStyler(int styleID, const NppXml::Element& styleNode)
{
	bool isUser = styleID >> 16 == L_USER;
	if (isUser)
	{
		styleID = (styleID & 0xFFFF);
		if (styleID >= SCE_USER_STYLE_TOTAL_STYLES || findByID(styleID))
			return;
	}

	_styleVect.emplace_back();
	Style& s = _styleVect.back();
	s._styleID = styleID;

	if (styleNode)
	{
		// For _fgColor & _bgColor :
		// RGB() | (result & 0xFF000000): it's for the case of -1 (0xFFFFFFFF) returned by "hexStrVal(str)"
		const char* str = NppXml::attribute(styleNode, "name");
		if (str)
		{
			if (isUser)
				s._styleDesc = string2wstring(globalMappper().styleNameMapper[styleID]);
			else
				s._styleDesc = string2wstring(str);
		}

		str = NppXml::attribute(styleNode, "fgColor");
		if (str)
		{
			unsigned long result = hexStrVal(str);
			s._fgColor = (RGB((result >> 16) & 0xFF, (result >> 8) & 0xFF, result & 0xFF)) | (result & 0xFF000000);
		}

		str = NppXml::attribute(styleNode, "bgColor");
		if (str)
		{
			unsigned long result = hexStrVal(str);
			s._bgColor = (RGB((result >> 16) & 0xFF, (result >> 8) & 0xFF, result & 0xFF)) | (result & 0xFF000000);
		}

		s._colorStyle = NppXml::intAttribute(styleNode, "colorStyle", COLORSTYLE_ALL);

		str = NppXml::attribute(styleNode, "fontName");
		if (str)
		{
			s._fontName = string2wstring(str);
			s._isFontEnabled = true;
		}

		s._fontStyle = NppXml::intAttribute(styleNode, "fontStyle", STYLE_NOT_USED);
		s._fontSize = NppXml::intAttribute(styleNode, "fontSize", STYLE_NOT_USED);

		s._nesting = NppXml::intAttribute(styleNode, "nesting", static_cast<int>(FontStyle::FONTSTYLE_NONE));

		str = NppXml::attribute(styleNode, "keywordClass");
		if (str)
		{
			s._keywordClass = getKwClassFromName(str);
		}

		NppXml::Node v = NppXml::firstChild(styleNode);
		if (v)
		{
			s._keywords = NppXml::getValue(v);
		}
	}
}

bool NppParameters::writeRecentFileHistorySettings(int nbMaxFile)
{
	if (!_xmlUserDoc._doc) return false;

	NppXml::Element nppRoot = NppXml::firstChildElement(_xmlUserDoc._doc, "NotepadPlus");
	if (!nppRoot)
	{
		nppRoot = NppXml::createChildElement(_xmlUserDoc._doc, "NotepadPlus");
	}

	NppXml::Element historyNode = NppXml::firstChildElement(nppRoot, "History");
	if (!historyNode)
	{
		historyNode = NppXml::createChildElement(nppRoot, "History");
	}

	NppXml::setAttribute(historyNode, "nbMaxFile", nbMaxFile != -1 ? nbMaxFile : _nbMaxRecentFile);
	setBoolAttribute(historyNode, "inSubMenu", _putRecentFileInSubMenu);
	NppXml::setAttribute(historyNode, "customLength", _recentFileCustomLength);
	return true;
}

bool NppParameters::writeColumnEditorSettings()
{
	if (!_xmlUserDoc._doc) return false;

	NppXml::Element nppRoot = NppXml::firstChildElement(_xmlUserDoc._doc, "NotepadPlus");
	if (!nppRoot)
	{
		nppRoot = NppXml::createChildElement(_xmlUserDoc._doc, "NotepadPlus");
	}

	NppXml::Element oldColumnEditorNode = NppXml::firstChildElement(nppRoot, "ColumnEditor");
	if (oldColumnEditorNode)
	{
		// Erase the Project Panel root
		NppXml::deleteChild(nppRoot, oldColumnEditorNode);
	}

	// Create the new ColumnEditor root
	NppXml::Element columnEditorRootNode = NppXml::createChildElement(nppRoot, "ColumnEditor");
	NppXml::setAttribute(columnEditorRootNode, "choice", _columnEditParam._mainChoice == activeNumeric ? "number" : "text");

	NppXml::Element textNode = NppXml::createChildElement(columnEditorRootNode, "text");
	NppXml::setAttribute(textNode, "content", wstring2string(_columnEditParam._insertedTextContent));

	NppXml::Element numberNode = NppXml::createChildElement(columnEditorRootNode, "number");
	NppXml::setAttribute(numberNode, "initial", _columnEditParam._initialNum);
	NppXml::setAttribute(numberNode, "increase", _columnEditParam._increaseNum);
	NppXml::setAttribute(numberNode, "repeat", _columnEditParam._repeatNum);

	std::string format;
	switch (_columnEditParam._formatChoice)
	{
		using enum NumBase;
		case BASE_10:
		{
			format = "dec";
			break;
		}

		case BASE_16:
		{
			format = "hex";
			break;
		}

		case BASE_08:
		{
			format = "oct";
			break;
		}

		case BASE_02:
		{
			format = "bin";
			break;
		}

		case BASE_16_UPPERCASE:
		{
			format = "hexuc";
			break;
		}
	}
	NppXml::setAttribute(numberNode, "formatChoice", format);

	std::string leading;
	switch (_columnEditParam._leadingChoice)
	{
		using enum ColumnEditorParam::leadingChoice;
		case noneLeading:
		{
			leading = "none";
			break;
		}

		case zeroLeading:
		{
			leading = "zeros";
			break;
		}

		case spaceLeading:
		{
			leading = "spaces";
			break;
		}
	}
	NppXml::setAttribute(numberNode, "leadingChoice", leading);

	return true;
}

bool NppParameters::writeProjectPanelsSettings()
{
	if (!_xmlUserDoc._doc) return false;

	NppXml::Element nppRoot = NppXml::firstChildElement(_xmlUserDoc._doc, "NotepadPlus");
	if (!nppRoot)
	{
		nppRoot = NppXml::createChildElement(_xmlUserDoc._doc, "NotepadPlus");
	}

	NppXml::Element oldProjPanelRootNode = NppXml::firstChildElement(nppRoot, "ProjectPanels");
	if (oldProjPanelRootNode)
	{
		// Erase the Project Panel root
		NppXml::deleteChild(nppRoot, oldProjPanelRootNode);
	}

	// Create the Project Panel root
	NppXml::Element projPanelRootNode = NppXml::createChildElement(nppRoot, "ProjectPanels");

	// Add 3 Project Panel parameters
	for (int i = 0; i < 3; ++i)
	{
		NppXml::Element projPanelNode = NppXml::createChildElement(projPanelRootNode, "ProjectPanel");
		NppXml::setAttribute(projPanelNode, "id", i);
		NppXml::setAttribute(projPanelNode, "workSpaceFile", wstring2string(_workSpaceFilePaths[i]));
	}

	return true;
}

bool NppParameters::writeFileBrowserSettings(const std::vector<std::wstring>& rootPaths, const std::wstring& latestSelectedItemPath, const std::unordered_set<std::wstring>& expandedPaths)
{
	if (!_xmlUserDoc._doc) return false;

	NppXml::Element nppRoot = NppXml::firstChildElement(_xmlUserDoc._doc, "NotepadPlus");
	if (!nppRoot)
	{
		nppRoot = NppXml::createChildElement(_xmlUserDoc._doc, "NotepadPlus");
	}

	NppXml::Element oldFileBrowserRootNode = NppXml::firstChildElement(nppRoot, "FileBrowser");
	if (oldFileBrowserRootNode)
	{
		// Erase the file browser root
		NppXml::deleteChild(nppRoot, oldFileBrowserRootNode);
	}

	// Create the file browser root
	NppXml::Element fileBrowserRootNode = NppXml::createChildElement(nppRoot, "FileBrowser");

	if (!rootPaths.empty())
	{
		NppXml::setAttribute(fileBrowserRootNode, "latestSelectedItem", wstring2string(latestSelectedItemPath));

		// add roots
		for (const auto& rootPath : rootPaths)
		{
			NppXml::Element fbRootNode = NppXml::createChildElement(fileBrowserRootNode, "root");
			NppXml::setAttribute(fbRootNode, "foldername", wstring2string(rootPath));

			std::vector<std::wstring> sortedExpanded;
			for (const auto& ep : expandedPaths)
			{
				std::wstring lowerEp = stringToLower(ep);
				std::wstring lowerRoot = stringToLower(rootPath);
				if (lowerEp.rfind(lowerRoot, 0) == 0)
				{
					sortedExpanded.push_back(ep);
				}
			}
			std::sort(sortedExpanded.begin(), sortedExpanded.end());
			for (const auto& ep : sortedExpanded)
			{
				NppXml::Element expNode = NppXml::createChildElement(fbRootNode, "expanded");
				NppXml::setAttribute(expNode, "path", wstring2string(ep));
			}
		}
	}

	return true;
}

bool NppParameters::writeHistory(const wchar_t* fullpath)
{
	NppXml::Element nppRoot = NppXml::firstChildElement(_xmlUserDoc._doc, "NotepadPlus");
	if (!nppRoot)
	{
		nppRoot = NppXml::createChildElement(_xmlUserDoc._doc, "NotepadPlus");
	}

	NppXml::Element historyNode = NppXml::firstChildElement(nppRoot, "History");
	if (!historyNode)
	{
		historyNode = NppXml::createChildElement(nppRoot, "History");
	}

	NppXml::Element recentFileNode = NppXml::createChildElement(historyNode, "File");
	NppXml::setAttribute(recentFileNode, "filename", wstring2string(fullpath));

	return true;
}

NppXml::Element NppParameters::getChildElementByAttribute(const NppXml::Element& element, const char* childName,
	const char* attributeName, const char* attributeVal)
{
	for (NppXml::Element childNode = NppXml::firstChildElement(element, childName);
		childNode;
		childNode = NppXml::nextSiblingElement(childNode, childName))
	{
		if (std::strcmp(NppXml::attribute(childNode, attributeName, ""), attributeVal) == 0)
		{
			return childNode;
		}
	}
	return NppXml::Element{};
}

// 2 restes : L_H, L_USER
LangType NppParameters::getLangIDFromStr(const wchar_t *langName)
{
	int lang = static_cast<int>(L_TEXT);
	for (; lang < static_cast<int>(L_EXTERNAL); ++lang)
	{
		const wchar_t* name = ScintillaEditView::_langNameInfoArray[lang]._langName;
		if (std::wcscmp(name, langName) == 0) //found lang?
		{
			return static_cast<LangType>(lang);
		}
	}

	//Cannot find language, check if its an external one

	auto l = static_cast<LangType>(lang);
	if (l == L_EXTERNAL) //try find external lexer
	{
		int id = NppParameters::getInstance().getExternalLangIndexFromName(langName);
		if (id != -1) return static_cast<LangType>(id + static_cast<int>(L_EXTERNAL));
	}

	return L_TEXT;
}

std::wstring NppParameters::getLocPathFromStr(const std::wstring & localizationCode)
{
	if (localizationCode == L"en" || localizationCode == L"en-au" || localizationCode == L"en-bz" || localizationCode == L"en-ca" || localizationCode == L"en-cb" || localizationCode == L"en-gb" || localizationCode == L"en-ie" || localizationCode == L"en-jm" || localizationCode == L"en-nz" || localizationCode == L"en-ph" || localizationCode == L"en-tt" || localizationCode == L"en-us" || localizationCode == L"en-za" || localizationCode == L"en-zw")
		return L"english.xml";
	if (localizationCode == L"af")
		return L"afrikaans.xml";
	if (localizationCode == L"sq")
		return L"albanian.xml";
	if (localizationCode == L"ar" || localizationCode == L"ar-dz" || localizationCode == L"ar-bh" || localizationCode == L"ar-eg" ||localizationCode == L"ar-iq" || localizationCode == L"ar-jo" || localizationCode == L"ar-kw" || localizationCode == L"ar-lb" || localizationCode == L"ar-ly" || localizationCode == L"ar-ma" || localizationCode == L"ar-om" || localizationCode == L"ar-qa" || localizationCode == L"ar-sa" || localizationCode == L"ar-sy" || localizationCode == L"ar-tn" || localizationCode == L"ar-ae" || localizationCode == L"ar-ye")
		return L"arabic.xml";
	if (localizationCode == L"an")
		return L"aragonese.xml";
	if (localizationCode == L"az")
		return L"azerbaijani.xml";
	if (localizationCode == L"eu")
		return L"basque.xml";
	if (localizationCode == L"be")
		return L"belarusian.xml";
	if (localizationCode == L"bn")
		return L"bengali.xml";
	if (localizationCode == L"bs")
		return L"bosnian.xml";
	if (localizationCode == L"pt-br")
		return L"brazilian_portuguese.xml";
	if (localizationCode == L"br-fr")
		return L"breton.xml";
	if (localizationCode == L"bg")
		return L"bulgarian.xml";
	if (localizationCode == L"ca")
		return L"catalan.xml";
	if (localizationCode == L"zh-tw" || localizationCode == L"zh-hk" || localizationCode == L"zh-sg")
		return L"taiwaneseMandarin.xml";
	if (localizationCode == L"zh" || localizationCode == L"zh-cn")
		return L"chineseSimplified.xml";
	if (localizationCode == L"co" || localizationCode == L"co-fr")
		return L"corsican.xml";
	if (localizationCode == L"hr")
		return L"croatian.xml";
	if (localizationCode == L"cs")
		return L"czech.xml";
	if (localizationCode == L"da")
		return L"danish.xml";
	if (localizationCode == L"nl" || localizationCode == L"nl-be")
		return L"dutch.xml";
	if (localizationCode == L"eo")
		return L"esperanto.xml";
	if (localizationCode == L"et")
		return L"estonian.xml";
	if (localizationCode == L"fa")
		return L"farsi.xml";
	if (localizationCode == L"fi")
		return L"finnish.xml";
	if (localizationCode == L"fr" || localizationCode == L"fr-be" || localizationCode == L"fr-ca" || localizationCode == L"fr-fr" || localizationCode == L"fr-lu" || localizationCode == L"fr-mc" || localizationCode == L"fr-ch")
		return L"french.xml";
	if (localizationCode == L"fur")
		return L"friulian.xml";
	if (localizationCode == L"gl")
		return L"galician.xml";
	if (localizationCode == L"ka")
		return L"georgian.xml";
	if (localizationCode == L"de" || localizationCode == L"de-at" || localizationCode == L"de-de" || localizationCode == L"de-li" || localizationCode == L"de-lu" || localizationCode == L"de-ch")
		return L"german.xml";
	if (localizationCode == L"el")
		return L"greek.xml";
	if (localizationCode == L"gu")
		return L"gujarati.xml";
	if (localizationCode == L"he")
		return L"hebrew.xml";
	if (localizationCode == L"hi")
		return L"hindi.xml";
	if (localizationCode == L"hu")
		return L"hungarian.xml";
	if (localizationCode == L"id")
		return L"indonesian.xml";
	if (localizationCode == L"it" || localizationCode == L"it-ch")
		return L"italian.xml";
	if (localizationCode == L"ja")
		return L"japanese.xml";
	if (localizationCode == L"kn")
		return L"kannada.xml";
	if (localizationCode == L"kk")
		return L"kazakh.xml";
	if (localizationCode == L"ko" || localizationCode == L"ko-kp" || localizationCode == L"ko-kr")
		return L"korean.xml";
	if (localizationCode == L"ku")
		return L"kurdish.xml";
	if (localizationCode == L"ky")
		return L"kyrgyz.xml";
	if (localizationCode == L"lv")
		return L"latvian.xml";
	if (localizationCode == L"lt")
		return L"lithuanian.xml";
	if (localizationCode == L"lb")
		return L"luxembourgish.xml";
	if (localizationCode == L"mk")
		return L"macedonian.xml";
	if (localizationCode == L"ms")
		return L"malay.xml";
	if (localizationCode == L"mr")
		return L"marathi.xml";
	if (localizationCode == L"mn")
		return L"mongolian.xml";
	if (localizationCode == L"no" || localizationCode == L"nb")
		return L"norwegian.xml";
	if (localizationCode == L"nn")
		return L"nynorsk.xml";
	if (localizationCode == L"oc")
		return L"occitan.xml";
	if (localizationCode == L"pl")
		return L"polish.xml";
	if (localizationCode == L"pt" || localizationCode == L"pt-pt")
		return L"portuguese.xml";
	if (localizationCode == L"pa" || localizationCode == L"pa-in")
		return L"punjabi.xml";
	if (localizationCode == L"ro" || localizationCode == L"ro-mo")
		return L"romanian.xml";
	if (localizationCode == L"ru" || localizationCode == L"ru-mo")
		return L"russian.xml";
	if (localizationCode == L"sc")
		return L"sardinian.xml";
	if (localizationCode == L"sr")
		return L"serbian.xml";
	if (localizationCode == L"sr-cyrl-ba" || localizationCode == L"sr-cyrl-sp")
		return L"serbianCyrillic.xml";
	if (localizationCode == L"si")
		return L"sinhala.xml";
	if (localizationCode == L"sk")
		return L"slovak.xml";
	if (localizationCode == L"sl")
		return L"slovenian.xml";
	if (localizationCode == L"es" || localizationCode == L"es-bo" || localizationCode == L"es-cl" || localizationCode == L"es-co" || localizationCode == L"es-cr" || localizationCode == L"es-do" || localizationCode == L"es-ec" || localizationCode == L"es-sv" || localizationCode == L"es-gt" || localizationCode == L"es-hn" || localizationCode == L"es-mx" || localizationCode == L"es-ni" || localizationCode == L"es-pa" || localizationCode == L"es-py" || localizationCode == L"es-pe" || localizationCode == L"es-pr" || localizationCode == L"es-es" || localizationCode == L"es-uy" || localizationCode == L"es-ve")
		return L"spanish.xml";
	if (localizationCode == L"es-ar")
		return L"spanish_ar.xml";
	if (localizationCode == L"sv")
		return L"swedish.xml";
	if (localizationCode == L"tl")
		return L"tagalog.xml";
	if (localizationCode == L"tg-cyrl-tj")
		return L"tajikCyrillic.xml";
	if (localizationCode == L"ta")
		return L"tamil.xml";
	if (localizationCode == L"tt")
		return L"tatar.xml";
	if (localizationCode == L"te")
		return L"telugu.xml";
	if (localizationCode == L"th")
		return L"thai.xml";
	if (localizationCode == L"tr")
		return L"turkish.xml";
	if (localizationCode == L"uk")
		return L"ukrainian.xml";
	if (localizationCode == L"ur" || localizationCode == L"ur-pk")
		return L"urdu.xml";
	if (localizationCode == L"ug-cn")
		return L"uyghur.xml";
	if (localizationCode == L"uz")
		return L"uzbek.xml";
	if (localizationCode == L"uz-cyrl-uz")
		return L"uzbekCyrillic.xml";
	if (localizationCode == L"vec")
		return L"venetian.xml";
	if (localizationCode == L"vi" || localizationCode == L"vi-vn")
		return L"vietnamese.xml";
	if (localizationCode == L"cy-gb")
		return L"welsh.xml";
	if (localizationCode == L"zu" || localizationCode == L"zu-za")
		return L"zulu.xml";
	if (localizationCode == L"ne" || localizationCode == L"nep")
		return L"nepali.xml";
	if (localizationCode == L"oc-aranes")
		return L"aranese.xml";
	if (localizationCode == L"exy")
		return L"extremaduran.xml";
	if (localizationCode == L"kab")
		return L"kabyle.xml";
	if (localizationCode == L"lij")
		return L"ligurian.xml";
	if (localizationCode == L"ga")
		return L"irish.xml";
	if (localizationCode == L"sgs")
		return L"samogitian.xml";
	if (localizationCode == L"yue")
		return L"hongKongCantonese.xml";
	if (localizationCode == L"ab" || localizationCode == L"abk")
		return L"abkhazian.xml";

	return std::wstring();
}


void NppParameters::feedKeyWordsParameters(const NppXml::Element& element)
{
	NppXml::Element langRoot = NppXml::firstChildElement(element, "Languages");
	if (!langRoot)
		return;

	for (NppXml::Element langNode = NppXml::firstChildElement(langRoot, "Language");
		langNode;
		langNode = NppXml::nextSiblingElement(langNode, "Language"))
	{
		if (_nbLang < NB_LANG)
		{
			const char* name = NppXml::attribute(langNode, "name");
			if (name)
			{
				const std::wstring wsName = string2wstring(name);
				const std::wstring wsExt = string2wstring(NppXml::attribute(langNode, "ext", ""));

				const int tabSettings = NppXml::intAttribute(langNode, "tabSettings", -1);
				const bool isBackspaceUnindent = getBoolAttribute(langNode, "backspaceUnindent");

				_langList[_nbLang] = std::make_unique<Lang>(
					getLangIDFromStr(wsName.c_str()),
					wsName.c_str(),
					wsExt.c_str(),
					NppXml::attribute(langNode, "commentLine", ""),
					NppXml::attribute(langNode, "commentStart", ""),
					NppXml::attribute(langNode, "commentEnd", ""),
					tabSettings,
					isBackspaceUnindent);

				for (NppXml::Element kwNode = NppXml::firstChildElement(langNode, "Keywords");
					kwNode;
					kwNode = NppXml::nextSiblingElement(kwNode, "Keywords"))
				{
					const char* indexName = NppXml::attribute(kwNode, "name");
					NppXml::Node kwVal = NppXml::firstChild(kwNode);
					std::string keyWords;
					if (indexName && kwVal)
						keyWords = NppXml::getValue(kwVal);

					const int i = getKwClassFromName(indexName);

					if (!keyWords.empty() && i >= 0 && i <= KEYWORDSET_MAX)
					{
						_langList[_nbLang]->setWords(keyWords.c_str(), i);
					}
				}
				++_nbLang;
			}
		}
	}
}

void NppParameters::feedGUIParameters(const NppXml::Element& element)
{
	NppXml::Element GUIRoot = NppXml::firstChildElement(element, "GUIConfigs");
	if (!GUIRoot)
		return;

	for (NppXml::Element childNode = NppXml::firstChildElement(GUIRoot, "GUIConfig");
		childNode;
		childNode = NppXml::nextSiblingElement(childNode, "GUIConfig"))
	{
		const char* nm = NppXml::attribute(childNode, "name");
		if (!nm)
			continue;

		// <GUIConfig name="ColorPickerCustomColors" color0="..." ... color15="..." />
		if (std::strcmp(nm, "ColorPickerCustomColors") == 0)
		{
			size_t i = 0;
			for (auto &cc : _nppGUI._colorPickerCustomColors)
			{
				const std::string attrName = "color" + std::to_string(i++);
				cc = static_cast<COLORREF>(NppXml::intAttribute(childNode, attrName.c_str(), static_cast<int>(cc)));
			}
		}
		// <GUIConfig name="ToolBar" visible="yes" fluentColor="0" fluentCustomColor="0" fluentMono="no">standard</GUIConfig>
		else if (std::strcmp(nm, "ToolBar") == 0)
		{
			_nppGUI._toolbarShow = getBoolAttribute(childNode, "visible", _nppGUI._toolbarShow);

			{
				using enum FluentColor;
				_nppGUI._tbIconInfo._tbColor = getRangeDefaultAttribute(childNode, "fluentColor", defaultColor, custom, _nppGUI._tbIconInfo._tbColor);
			}

			_nppGUI._tbIconInfo._tbCustomColor = NppXml::intAttribute(childNode, "fluentCustomColor", _nppGUI._tbIconInfo._tbCustomColor);

			_nppGUI._tbIconInfo._tbUseMono = getBoolAttribute(childNode, "fluentMono", _nppGUI._tbIconInfo._tbUseMono);

			NppXml::Node n = NppXml::firstChild(childNode);
			if (n)
			{
				const char* val = NppXml::getValue(n);
				if (val)
				{
					using enum toolBarStatusType;
					auto& tbIconSet = _nppGUI._tbIconInfo._tbIconSet;
					if (std::strcmp(val, "small") == 0)
						tbIconSet = TB_SMALL;
					else if (std::strcmp(val, "large") == 0)
						tbIconSet = TB_LARGE;
					else if (std::strcmp(val, "small2") == 0)
						tbIconSet = TB_SMALL2;
					else if (std::strcmp(val, "large2") == 0)
						tbIconSet = TB_LARGE2;
					else //if (std::strcmp(val, "standard") == 0)
						tbIconSet = TB_STANDARD;
				}

			}
		}
		// <GUIConfig name="StatusBar">show</GUIConfig>
		else if (std::strcmp(nm, "StatusBar") == 0)
		{
			_nppGUI._statusBarShow = getBoolChildTextNode(childNode, _nppGUI._statusBarShow, STR_BOOL_SHOWHIDE);
		}
		// <GUIConfig name="MenuBar">show</GUIConfig>
		else if (std::strcmp(nm, "MenuBar") == 0)
		{
			_nppGUI._menuBarShow = getBoolChildTextNode(childNode, _nppGUI._menuBarShow, STR_BOOL_SHOWHIDE);
		}
		// <GUIConfig name="DialogFont" size="8"/>
		else if (std::strcmp(nm, "DialogFont") == 0)
		{
			_nppGUI._fontDlgSize = static_cast<WORD>(NppXml::uintAttribute(childNode, "size", _nppGUI._fontDlgSize));
		}
		// <GUIConfig name="TabBar" dragAndDrop="yes" drawTopBar="yes" drawInactiveTab="yes" reduce="yes" closeButton="yes"
		// pinButton="yes" showOnlyPinnedButton="no" buttonsOninactiveTabs="no" doubleClick2Close="no"
		// vertical="no" multiLine="no" hide="no" quitOnEmpty="no" tabCompactLabelLen="0" />
		else if (std::strcmp(nm, "TabBar") == 0)
		{
			bool isFailed = false;
			const int oldValue = _nppGUI._tabStatus;
			_nppGUI._tabStatus = 0;

			using enum XmlAttrResult;

			auto setTabStatus = [&childNode, &isFailed, this](const char* name, int flag)
			{
				if (isFailed)
					return;

				const XmlAttrResult val = getResultAttribute(childNode, name);
				switch (val)
				{
					case isTrue:
					{
						_nppGUI._tabStatus |= flag;
						break;
					}

					case isFalse:
					{
						break;
					}

					case failed:
					{
						isFailed = true;
						break;
					}
				}
			};

			setTabStatus("dragAndDrop", TAB_DRAGNDROP);
			setTabStatus("drawTopBar", TAB_DRAWTOPBAR);
			setTabStatus("drawInactiveTab", TAB_DRAWINACTIVETAB);
			setTabStatus("reduce", TAB_REDUCE);
			setTabStatus("closeButton", TAB_CLOSEBUTTON);
			setTabStatus("pinButton", TAB_PINBUTTON);
			setTabStatus("buttonsOninactiveTabs", TAB_INACTIVETABSHOWBUTTON);
			setTabStatus("showOnlyPinnedButton", TAB_SHOWONLYPINNEDBUTTON);
			setTabStatus("doubleClick2Close", TAB_DBCLK2CLOSE);
			setTabStatus("vertical", TAB_VERTICAL);
			setTabStatus("multiLine", TAB_MULTILINE);
			setTabStatus("hide", TAB_HIDE);
			setTabStatus("quitOnEmpty", TAB_QUITONEMPTY);

			if (isFailed)
				_nppGUI._tabStatus = oldValue;

			_nppGUI._tabCompactLabelLen = getRangeClampAttribute<UINT>(childNode, "tabCompactLabelLen", 0U, static_cast<UINT>(NB_MAX_TAB_COMPACT_LABEL_LEN), _nppGUI._tabCompactLabelLen);
		}
		// <GUIConfig name="Auto-detection">yes</GUIConfig>
		else if (std::strcmp(nm, "Auto-detection") == 0)
		{
			NppXml::Node n = NppXml::firstChild(childNode);
			if (n)
			{
				const char* val = NppXml::getValue(n);
				if (val)
				{
					if (std::strcmp(val, "yesOld") == 0)
						_nppGUI._fileAutoDetection = cdEnabledOld;
					else if (std::strcmp(val, "autoOld") == 0)
						_nppGUI._fileAutoDetection = (cdEnabledOld | cdAutoUpdate);
					else if (std::strcmp(val, "Update2EndOld") == 0)
						_nppGUI._fileAutoDetection = (cdEnabledOld | cdGo2end);
					else if (std::strcmp(val, "autoUpdate2EndOld") == 0)
						_nppGUI._fileAutoDetection = (cdEnabledOld | cdAutoUpdate | cdGo2end);
					else if (std::strcmp(val, "yes") == 0)
						_nppGUI._fileAutoDetection = cdEnabledNew;
					else if (std::strcmp(val, "auto") == 0)
						_nppGUI._fileAutoDetection = (cdEnabledNew | cdAutoUpdate);
					else if (std::strcmp(val, "Update2End") == 0)
						_nppGUI._fileAutoDetection = (cdEnabledNew | cdGo2end);
					else if (std::strcmp(val, "autoUpdate2End") == 0)
						_nppGUI._fileAutoDetection = (cdEnabledNew | cdAutoUpdate | cdGo2end);
					else //(std::strcmp(val, "no") == 0)
						_nppGUI._fileAutoDetection = cdDisabled;
				}
			}
		}
		// <GUIConfig name="TrayIcon">0</GUIConfig>
		else if (std::strcmp(nm, "TrayIcon") == 0)
		{
			NppXml::Node n = NppXml::firstChild(childNode);
			if (n)
			{
				const char* val = NppXml::getValue(n);
				if (val)
				{
					if (std::strcmp(val, "no") == 0 || std::strcmp(val, "0") == 0)
						_nppGUI._isMinimizedToTray = sta_none;
					else if (std::strcmp(val, "yes") == 0 || std::strcmp(val, "1") == 0)
						_nppGUI._isMinimizedToTray = sta_minimize;
					else if (std::strcmp(val, "2") == 0)
						_nppGUI._isMinimizedToTray = sta_close;
					else if (std::strcmp(val, "3") == 0)
						_nppGUI._isMinimizedToTray = sta_minimize_close;
					else
						_nppGUI._isMinimizedToTray = sta_none;
				}
			}
		}
		// <GUIConfig name="RememberLastSession">yes</GUIConfig>
		else if (std::strcmp(nm, "RememberLastSession") == 0)
		{
			_nppGUI._rememberLastSession = getBoolChildTextNode(childNode, _nppGUI._rememberLastSession);
		}
		// <GUIConfig name="KeepSessionAbsentFileEntries">no</GUIConfig>
		else if (std::strcmp(nm, "KeepSessionAbsentFileEntries") == 0)
		{
			_nppGUI._keepSessionAbsentFileEntries = getBoolChildTextNode(childNode);
		}
		// <GUIConfig name="DetectEncoding">yes</GUIConfig>
		else if (std::strcmp(nm, "DetectEncoding") == 0)
		{
			_nppGUI._detectEncoding = getBoolChildTextNode(childNode, _nppGUI._detectEncoding);
		}
		// <GUIConfig name="SaveAllConfirm">yes</GUIConfig>
		else if (std::strcmp(nm, "SaveAllConfirm") == 0)
		{
			_nppGUI._saveAllConfirm = getBoolChildTextNode(childNode, _nppGUI._saveAllConfirm);
		}
		// <GUIConfig name="MaintainIndent">1</GUIConfig>
		else if (std::strcmp(nm, "MaintainIndent") == 0 ||
			std::strcmp(nm, "MaitainIndent") == 0) // typo - kept for the compatibility reason
		{
			NppXml::Node n = NppXml::firstChild(childNode);
			if (n)
			{
				const char* val = NppXml::getValue(n);
				if (val)
				{
					// the retro-compatibility with the old values
					if (std::strcmp(val, "yes") == 0)
						_nppGUI._maintainIndent = autoIndent_advanced;
					else if (std::strcmp(val, "no") == 0)
						_nppGUI._maintainIndent = autoIndent_none;

					// the treatment of the new values
					else if (std::strcmp(val, "0") == 0)
						_nppGUI._maintainIndent = autoIndent_none;
					else if (std::strcmp(val, "1") == 0)
						_nppGUI._maintainIndent = autoIndent_advanced;
					else if (std::strcmp(val, "2") == 0)
						_nppGUI._maintainIndent = autoIndent_basic;
					else // other values will be ignored - use the default value
						_nppGUI._maintainIndent = autoIndent_advanced;
				}
			}
		}
		// <GUIConfig name="MarkAll" matchCase="no" wholeWordOnly="yes" />
		else if (std::strcmp(nm, "MarkAll") == 0)
		{
			_nppGUI._markAllCaseSensitive = getBoolAttribute(childNode, "matchCase");
			_nppGUI._markAllWordOnly = getBoolAttribute(childNode, "wholeWordOnly", _nppGUI._markAllWordOnly);
		}
		// <GUIConfig name="SmartHighLight" matchCase="no" wholeWordOnly="yes" useFindSettings="no" onAnotherView="no">yes</GUIConfig>
		else if (std::strcmp(nm, "SmartHighLight") == 0)
		{
			NppXml::Node n = NppXml::firstChild(childNode);
			if (n)
			{
				_nppGUI._enableSmartHilite = getBoolChildTextNode(childNode, _nppGUI._enableSmartHilite);

				_nppGUI._smartHiliteCaseSensitive = getBoolAttribute(childNode, "matchCase");
				_nppGUI._smartHiliteWordOnly = getBoolAttribute(childNode, "wholeWordOnly", _nppGUI._smartHiliteWordOnly);
				_nppGUI._smartHiliteUseFindSettings = getBoolAttribute(childNode, "useFindSettings");
				_nppGUI._smartHiliteOnAnotherView = getBoolAttribute(childNode, "onAnotherView");
			}
		}
		// <GUIConfig name="TagsMatchHighLight" TagAttrHighLight="yes" HighLightNonHtmlZone="no">yes</GUIConfig>
		else if (std::strcmp(nm, "TagsMatchHighLight") == 0)
		{
			NppXml::Node n = NppXml::firstChild(childNode);
			if (n)
			{
				_nppGUI._enableTagsMatchHilite = getBoolChildTextNode(childNode, _nppGUI._enableTagsMatchHilite);
				_nppGUI._enableTagAttrsHilite = getBoolAttribute(childNode, "TagAttrHighLight", _nppGUI._enableTagAttrsHilite);
				_nppGUI._enableHiliteNonHTMLZone = getBoolAttribute(childNode, "HighLightNonHtmlZone");
			}
		}
		// <GUIConfig name="TaskList">yes</GUIConfig>
		else if (std::strcmp(nm, "TaskList") == 0)
		{
			_nppGUI._doTaskList = getBoolChildTextNode(childNode, _nppGUI._doTaskList);
		}
		// <GUIConfig name="MRU">yes</GUIConfig>
		else if (std::strcmp(nm, "MRU") == 0)
		{
			_nppGUI._styleMRU = getBoolChildTextNode(childNode, _nppGUI._styleMRU);
		}
		// <GUIConfig name="URL">2</GUIConfig>
		else if (std::strcmp(nm, "URL") == 0)
		{
			NppXml::Node n = NppXml::firstChild(childNode);
			if (n)
			{
				const char* val = NppXml::getValue(n);
				if (val)
				{
					using enum urlMode;
					try {
						const int i = std::stoi(val);
						if ((i >= static_cast<int>(urlMin)) && (i <= static_cast<int>(urlMax)))
							_nppGUI._styleURL = static_cast<urlMode>(i);
					}
					catch (const std::invalid_argument&)
					{
						_nppGUI._styleURL = urlUnderLineFg;
					}
					catch (const std::out_of_range&)
					{
						_nppGUI._styleURL = urlUnderLineFg;
					}
				}
			}
		}
		// <GUIConfig name="uriCustomizedSchemes">svn:// cvs:// git:// imap:// irc:// irc6:// ircs:// ldap:// ldaps:// news: telnet://
		// gopher:// ssh:// sftp:// smb:// skype: snmp:// spotify: steam:// sms: slack:// chrome:// bitcoin:</GUIConfig>
		else if (std::strcmp(nm, "uriCustomizedSchemes") == 0)
		{
			NppXml::Node n = NppXml::firstChild(childNode);
			if (n)
			{
				const char* val = NppXml::getValue(n);
				if (val)
					_nppGUI._uriSchemes = string2wstring(val);
			}
		}
		// <GUIConfig name="CheckHistoryFiles">no</GUIConfig>
		else if (std::strcmp(nm, "CheckHistoryFiles") == 0)
		{
			_nppGUI._checkHistoryFiles = getBoolChildTextNode(childNode);
		}
		// <GUIConfig name="ScintillaViewsSplitter">vertical</GUIConfig>
		else if (std::strcmp(nm, "ScintillaViewsSplitter") == 0)
		{
			NppXml::Node n = NppXml::firstChild(childNode);
			if (n)
			{
				const char* val = NppXml::getValue(n);
				if (val)
				{
					if (std::strcmp(val, "vertical") == 0)
						_nppGUI._splitterPos = POS_VERTICAL;
					else if (std::strcmp(val, "horizontal") == 0)
						_nppGUI._splitterPos = POS_HORIZONTAL;
				}
			}
		}
		// <GUIConfig name="UserDefineDlg" position="undocked">hide</GUIConfig>
		else if (std::strcmp(nm, "UserDefineDlg") == 0)
		{
			bool isFailed = false;
			const int oldValue = _nppGUI._userDefineDlgStatus;

			using enum XmlAttrResult;
			XmlAttrResult val = getResultChildTextNode(childNode, STR_BOOL_SHOWHIDE);
			switch (val)
			{
				case isTrue:
				{
					_nppGUI._userDefineDlgStatus = UDD_SHOW;
					break;
				}

				case isFalse:
				{
					_nppGUI._userDefineDlgStatus = 0;
					break;
				}

				case failed:
				{
					isFailed = true;
					break;
				}
			}

			if (!isFailed)
			{
				val = getResultAttribute(childNode, "position", { "docked", "undocked" });
				switch (val)
				{
					case isTrue:
					{
						_nppGUI._userDefineDlgStatus |= UDD_DOCKED;
						break;
					}

					case isFalse:
					{
						break;
					}

					case failed:
					{
						isFailed = true;
						break;
					}
				}
			}

			if (isFailed)
				_nppGUI._userDefineDlgStatus = oldValue;
		}
		// <GUIConfig name="TabSetting" replaceBySpace="no" size="4" backspaceUnindent="no" />
		else if (std::strcmp(nm, "TabSetting") == 0)
		{
			_nppGUI._tabSize = NppXml::intAttribute(childNode, "size", _nppGUI._tabSize);
			if ((_nppGUI._tabSize == -1) || (_nppGUI._tabSize == 0))
				_nppGUI._tabSize = 4;

			_nppGUI._tabReplacedBySpace = getBoolAttribute(childNode, "replaceBySpace");
			_nppGUI._backspaceUnindent = getBoolAttribute(childNode, "backspaceUnindent");
		}
		// <GUIConfig name="Caret" width="1" blinkRate="600" />
		else if (std::strcmp(nm, "Caret") == 0)
		{
			_nppGUI._caretWidth = NppXml::intAttribute(childNode, "width", _nppGUI._caretWidth);
			_nppGUI._caretBlinkRate = NppXml::intAttribute(childNode, "blinkRate", _nppGUI._caretBlinkRate);
		}
		// <GUIConfig name="AppPosition" x="0" y="0" width="1100" height="700" isMaximized="no" />
		else if (std::strcmp(nm, "AppPosition") == 0)
		{
			RECT oldRect = _nppGUI._appPos;
			bool fuckUp = true;

			if (const char* val = NppXml::attribute(childNode, "x"); val)
			{
				_nppGUI._appPos.left = std::stoi(val);

				if (val = NppXml::attribute(childNode, "y"); val)
				{
					_nppGUI._appPos.top = std::stoi(val);

					if (val = NppXml::attribute(childNode, "width"); val)
					{
						_nppGUI._appPos.right = std::stoi(val);

						if (val = NppXml::attribute(childNode, "height"); val)
						{
							_nppGUI._appPos.bottom = std::stoi(val);
							fuckUp = false;
						}
					}
				}
			}
			if (fuckUp)
				_nppGUI._appPos = oldRect;

			_nppGUI._isMaximized = getBoolAttribute(childNode, "isMaximized");
		}
		// <GUIConfig name="FindWindowPosition" left="0" top="0" right="0" bottom="0" isLessModeOn="no" />
		else if (std::strcmp(nm, "FindWindowPosition") == 0)
		{
			RECT oldRect = _nppGUI._findWindowPos;
			bool incomplete = true;

			if (const char* val = NppXml::attribute(childNode, "left"); val)
			{
				_nppGUI._findWindowPos.left = std::stoi(val);

				if (val = NppXml::attribute(childNode, "top"); val)
				{
					_nppGUI._findWindowPos.top = std::stoi(val);

					if (val = NppXml::attribute(childNode, "right"); val)
					{
						_nppGUI._findWindowPos.right = std::stoi(val);

						if (val = NppXml::attribute(childNode, "bottom"); val)
						{
							_nppGUI._findWindowPos.bottom = std::stoi(val);
							incomplete = false;
						}
					}
				}
			}
			if (incomplete)
			{
				_nppGUI._findWindowPos = oldRect;
			}

			_nppGUI._findWindowLessMode = getBoolAttribute(childNode, "isLessModeOn");
		}
		// <GUIConfig name="FinderConfig" wrappedLines="no" purgeBeforeEverySearch="no" showOnlyOneEntryPerFoundLine="yes" FiF_ignoreunsavedChangesInOpenedFiles="no" />
		else if (std::strcmp(nm, "FinderConfig") == 0)
		{
			_nppGUI._finderLinesAreCurrentlyWrapped = getBoolAttribute(childNode, "wrappedLines");
			_nppGUI._finderPurgeBeforeEverySearch = getBoolAttribute(childNode, "purgeBeforeEverySearch");
			_nppGUI._finderShowOnlyOneEntryPerFoundLine = getBoolAttribute(childNode, "showOnlyOneEntryPerFoundLine", _nppGUI._finderShowOnlyOneEntryPerFoundLine);
			_nppGUI._fif_ignoreunsavedChangesInOpenedFiles = getBoolAttribute(childNode, "FiF_ignoreunsavedChangesInOpenedFiles", _nppGUI._fif_ignoreunsavedChangesInOpenedFiles);
		}
		// <GUIConfig name="NewDocDefaultSettings" format="0" encoding="4" lang="0" codepage="-1" openAnsiAsUTF8="yes"
		// addNewDocumentOnStartup="no" useContentAsTabName="no" />
		else if (std::strcmp(nm, "NewDocDefaultSettings") == 0)
		{
			{
				using enum EolType;
				const int i = NppXml::intAttribute(childNode, "format", static_cast<int>(osdefault));
				EolType newFormat = osdefault;
				switch (i)
				{
					case static_cast<int>(windows):
					{
						newFormat = windows;
						break;
					}

					case static_cast<int>(macos):
					{
						newFormat = macos;
						break;
					}

					case static_cast<int>(unix):
					{
						newFormat = unix;
						break;
					}

					default:
					{
						assert(false && "invalid buffer format - fallback to default");
						break;
					}
				}
				_nppGUI._newDocDefaultSettings._format = newFormat;
			}

			{
				using enum UniMode;
				int i = NppXml::intAttribute(childNode, "encoding", static_cast<int>(uniUTF8_NoBOM));
				if (isCurrentSystemCodepageUTF8() // "Beta: Use Unicode UTF-8 for worldwide language support" option is checked in Windows
					&& static_cast<UniMode>(i) == uni8Bit) // Notepad++ default new document setting is ANSI
				{
					// Force Notepad++ default new document setting from ANSI to UTF-8
					i = static_cast<int>(uniUTF8);
				}
				_nppGUI._newDocDefaultSettings._unicodeMode = static_cast<UniMode>(i);
			}

			{
				using enum LangType;
				_nppGUI._newDocDefaultSettings._lang = static_cast<LangType>(NppXml::intAttribute(childNode, "lang", static_cast<int>(L_TEXT)));
				_nppGUI._newDocDefaultSettings._codepage = NppXml::intAttribute(childNode, "codepage", _nppGUI._newDocDefaultSettings._codepage);
			}

			const bool isOpenAnsiAsUTF8 = !isCurrentSystemCodepageUTF8()
				&& getBoolAttribute(childNode, "openAnsiAsUTF8", _nppGUI._newDocDefaultSettings._openAnsiAsUtf8);
			_nppGUI._newDocDefaultSettings._openAnsiAsUtf8 = isOpenAnsiAsUTF8;
			_nppGUI._newDocDefaultSettings._addNewDocumentOnStartup = getBoolAttribute(childNode, "addNewDocumentOnStartup");
			_nppGUI._newDocDefaultSettings._useContentAsTabName = getBoolAttribute(childNode, "useContentAsTabName");
		}
		// <GUIConfig name="langsExcluded" gr0="0" gr1="0" gr2="0" gr3="0" gr4="0" gr5="0" gr6="0" gr7="0" gr8="0" gr9="0" gr10="0" gr11="0" gr12="0"
		// langMenuCompact="yes" />
		else if (std::strcmp(nm, "langsExcluded") == 0)
		{
			int g[13]{}; // Make all elements of array to hold g0 to g12 to zero
			static constexpr const char* attributeNames[]{
				"gr0", "gr1", "gr2", "gr3", "gr4", "gr5", "gr6",
				"gr7", "gr8", "gr9", "gr10", "gr11", "gr12"
			};

			for (int j = 0; j < 13; ++j)
			{
				const int i = NppXml::intAttribute(childNode, attributeNames[j], -1);
				if (i != -1 && i <= 255)
				{
					g[j] = i;
				}
			}

			int g0 = g[0];  // up to 8
			int g1 = g[1];  // up to 16
			int g2 = g[2];  // up to 24
			int g3 = g[3];  // up to 32
			int g4 = g[4];  // up to 40
			int g5 = g[5];  // up to 48
			int g6 = g[6];  // up to 56
			int g7 = g[7];  // up to 64
			int g8 = g[8];  // up to 72
			int g9 = g[9];  // up to 80
			int g10 = g[10]; // up to 88
			int g11 = g[11]; // up to 96
			int g12 = g[12]; // up to 104

			UCHAR mask = 1;
			for (int i = 0; i < 8; ++i)
			{
				if (mask & g0)
					_nppGUI._excludedLangList.emplace_back(static_cast<LangType>(i));
				mask <<= 1;
			}

			mask = 1;
			for (int i = 8; i < 16; ++i)
			{
				if (mask & g1)
					_nppGUI._excludedLangList.emplace_back(static_cast<LangType>(i));
				mask <<= 1;
			}

			mask = 1;
			for (int i = 16; i < 24; ++i)
			{
				if (mask & g2)
					_nppGUI._excludedLangList.emplace_back(static_cast<LangType>(i));
				mask <<= 1;
			}

			mask = 1;
			for (int i = 24; i < 32; ++i)
			{
				if (mask & g3)
					_nppGUI._excludedLangList.emplace_back(static_cast<LangType>(i));
				mask <<= 1;
			}

			mask = 1;
			for (int i = 32; i < 40; ++i)
			{
				if (mask & g4)
					_nppGUI._excludedLangList.emplace_back(static_cast<LangType>(i));
				mask <<= 1;
			}

			mask = 1;
			for (int i = 40; i < 48; ++i)
			{
				if (mask & g5)
					_nppGUI._excludedLangList.emplace_back(static_cast<LangType>(i));
				mask <<= 1;
			}

			mask = 1;
			for (int i = 48; i < 56; ++i)
			{
				if (mask & g6)
					_nppGUI._excludedLangList.emplace_back(static_cast<LangType>(i));
				mask <<= 1;
			}

			mask = 1;
			for (int i = 56; i < 64; ++i)
			{
				if (mask & g7)
					_nppGUI._excludedLangList.emplace_back(static_cast<LangType>(i));
				mask <<= 1;
			}

			mask = 1;
			for (int i = 64; i < 72; ++i)
			{
				if (mask & g8)
					_nppGUI._excludedLangList.emplace_back(static_cast<LangType>(i));
				mask <<= 1;
			}

			mask = 1;
			for (int i = 72; i < 80; ++i)
			{
				if (mask & g9)
					_nppGUI._excludedLangList.emplace_back(static_cast<LangType>(i));
				mask <<= 1;
			}

			mask = 1;
			for (int i = 80; i < 88; ++i)
			{
				if (mask & g10)
					_nppGUI._excludedLangList.emplace_back(static_cast<LangType>(i));
				mask <<= 1;
			}

			mask = 1;
			for (int i = 88; i < 96; ++i)
			{
				if (mask & g11)
					_nppGUI._excludedLangList.emplace_back(static_cast<LangType>(i));
				mask <<= 1;
			}

			mask = 1;
			for (int i = 96; i < 104; ++i)
			{
				if (mask & g12)
					_nppGUI._excludedLangList.emplace_back(static_cast<LangType>(i));
				mask <<= 1;
			}

			_nppGUI._isLangMenuCompact = getBoolAttribute(childNode, "langMenuCompact", _nppGUI._isLangMenuCompact);
		}
		// <GUIConfig name="Print" lineNumber="yes" formFeedPageBreak="no" printOption="3" headerLeft="" headerMiddle="" headerRight="" footerLeft=""
		// footerMiddle="" footerRight="" headerFontName="" headerFontStyle="0" headerFontSize="0" footerFontName="" footerFontStyle="0"
		// footerFontSize="0" margeLeft="0" margeRight="0" margeTop="0" margeBottom="0" />
		else if (std::strcmp(nm, "Print") == 0)
		{
			_nppGUI._printSettings._printLineNumber = getBoolAttribute(childNode, "lineNumber", _nppGUI._printSettings._printLineNumber);
			_nppGUI._printSettings._printFormFeedPageBreak = getBoolAttribute(childNode, "formFeedPageBreak", _nppGUI._printSettings._printFormFeedPageBreak);

			_nppGUI._printSettings._printOption = getRangeDefaultAttribute<int>(childNode, "printOption", SC_PRINT_NORMAL, SC_PRINT_COLOURONWHITE, _nppGUI._printSettings._printOption);

			_nppGUI._printSettings._headerLeft = string2wstring(NppXml::attribute(childNode, "headerLeft", ""));
			_nppGUI._printSettings._headerMiddle = string2wstring(NppXml::attribute(childNode, "headerMiddle", ""));
			_nppGUI._printSettings._headerRight = string2wstring(NppXml::attribute(childNode, "headerRight", ""));

			_nppGUI._printSettings._footerLeft = string2wstring(NppXml::attribute(childNode, "footerLeft", ""));
			_nppGUI._printSettings._footerMiddle = string2wstring(NppXml::attribute(childNode, "footerMiddle", ""));
			_nppGUI._printSettings._footerRight = string2wstring(NppXml::attribute(childNode, "footerRight", ""));

			_nppGUI._printSettings._headerFontName = string2wstring(NppXml::attribute(childNode, "headerFontName", ""));
			_nppGUI._printSettings._footerFontName = string2wstring(NppXml::attribute(childNode, "footerFontName", ""));

			_nppGUI._printSettings._headerFontStyle = NppXml::intAttribute(childNode, "headerFontStyle", 0);
			_nppGUI._printSettings._footerFontStyle = NppXml::intAttribute(childNode, "footerFontStyle", 0);
			_nppGUI._printSettings._headerFontSize = NppXml::intAttribute(childNode, "headerFontSize", 0);
			_nppGUI._printSettings._footerFontSize = NppXml::intAttribute(childNode, "footerFontSize", 0);

			_nppGUI._printSettings._marge.left = NppXml::intAttribute(childNode, "margeLeft", 0);
			_nppGUI._printSettings._marge.top = NppXml::intAttribute(childNode, "margeTop", 0);
			_nppGUI._printSettings._marge.right = NppXml::intAttribute(childNode, "margeRight", 0);
			_nppGUI._printSettings._marge.bottom = NppXml::intAttribute(childNode, "margeBottom", 0);
		}
		
		else if (std::strcmp(nm, "ScintillaPrimaryView") == 0)
		{
			feedScintillaParam(childNode);
		}
		// <GUIConfig name="Backup" action="0" useCustumDir="no" dir="" isSnapshotMode="yes" snapshotBackupTiming="7000" />
		else if (std::strcmp(nm, "Backup") == 0)
		{
			{
				using enum BackupFeature;
				_nppGUI._backup = getRangeDefaultAttribute(childNode, "action", bak_none, bak_verbose, _nppGUI._backup);
			}

			_nppGUI._useDir = getBoolAttribute(childNode, "useCustumDir");
			_nppGUI._backupDir = string2wstring(NppXml::attribute(childNode, "dir", ""));

			_nppGUI._isSnapshotMode = getBoolAttribute(childNode, "isSnapshotMode", _nppGUI._isSnapshotMode);
			_nppGUI._snapshotBackupTiming = static_cast<size_t>(NppXml::uint64Attribute(childNode, "snapshotBackupTiming", _nppGUI._snapshotBackupTiming));

		}
		
		else if (std::strcmp(nm, "DockingManager") == 0)
		{
			feedDockingManager(childNode);
		}
		// <GUIConfig name="globalOverride" fg="no" bg="no" font="no" fontSize="no" bold="no" italic="no" underline="no" />
		else if (std::strcmp(nm, "globalOverride") == 0)
		{
			_nppGUI._globalOverride.enableFg = getBoolAttribute(childNode, "fg");
			_nppGUI._globalOverride.enableBg = getBoolAttribute(childNode, "bg");
			_nppGUI._globalOverride.enableFont = getBoolAttribute(childNode, "font");
			_nppGUI._globalOverride.enableFontSize = getBoolAttribute(childNode, "fontSize");
			_nppGUI._globalOverride.enableBold = getBoolAttribute(childNode, "bold");
			_nppGUI._globalOverride.enableItalic = getBoolAttribute(childNode, "italic");
			_nppGUI._globalOverride.enableUnderLine = getBoolAttribute(childNode, "underline");
		}
		// <GUIConfig name="auto-completion" autoCAction="3" triggerFromNbChar="1" autoCIgnoreNumbers="yes" insertSelectedItemUseENTER="yes"
		// insertSelectedItemUseTAB="yes" autoCBrief="no" funcParams="yes" />
		else if (std::strcmp(nm, "auto-completion") == 0)
		{
			{
				using enum NppGUI::AutocStatus;
				_nppGUI._autocStatus = getRangeDefaultAttribute(childNode, "autoCAction", autoc_none, autoc_both, _nppGUI._autocStatus);
			}

			// from preferenceDlg.cpp
			// static constexpr int AUTOCOMPLETEFROMCHAR_SMALLEST = 1;
			// static constexpr int AUTOCOMPLETEFROMCHAR_LARGEST = 9;
			_nppGUI._autocFromLen = getRangeClampAttribute<UINT>(childNode, "triggerFromNbChar", 1U, 9U, _nppGUI._autocFromLen);

			_nppGUI._autocIgnoreNumbers = getBoolAttribute(childNode, "autoCIgnoreNumbers", _nppGUI._autocIgnoreNumbers);
			_nppGUI._autocInsertSelectedUseENTER = getBoolAttribute(childNode, "insertSelectedItemUseENTER", _nppGUI._autocInsertSelectedUseENTER);
			_nppGUI._autocInsertSelectedUseTAB = getBoolAttribute(childNode, "insertSelectedItemUseTAB", _nppGUI._autocInsertSelectedUseTAB);
			_nppGUI._autocBrief = getBoolAttribute(childNode, "autoCBrief");
			_nppGUI._funcParams = getBoolAttribute(childNode, "funcParams", _nppGUI._funcParams);
		}
		// <GUIConfig name="auto-insert" parentheses="no" brackets="no" curlyBrackets="no" quotes="no" doubleQuotes="no" htmlXmlTag="no" />
		else if (std::strcmp(nm, "auto-insert") == 0)
		{
			_nppGUI._matchedPairConf._doHtmlXmlTag = getBoolAttribute(childNode, "htmlXmlTag");
			_nppGUI._matchedPairConf._doParentheses = getBoolAttribute(childNode, "parentheses");
			_nppGUI._matchedPairConf._doBrackets = getBoolAttribute(childNode, "brackets");
			_nppGUI._matchedPairConf._doCurlyBrackets = getBoolAttribute(childNode, "curlyBrackets");
			_nppGUI._matchedPairConf._doQuotes = getBoolAttribute(childNode, "quotes");
			_nppGUI._matchedPairConf._doDoubleQuotes = getBoolAttribute(childNode, "doubleQuotes");

			for (NppXml::Element subChildNode = NppXml::firstChildElement(childNode, "UserDefinePair");
				subChildNode;
				subChildNode = NppXml::nextSiblingElement(subChildNode, "UserDefinePair"))
			{
				const int open = getRangeDefaultAttribute(subChildNode, "open", 0, 127, -1);
				const int close = getRangeDefaultAttribute(subChildNode, "close", 0, 127, -1);

				if (open != -1 && close != -1)
					_nppGUI._matchedPairConf._matchedPairs.emplace_back(static_cast<char>(open), static_cast<char>(close));
			}
		}
		// <GUIConfig name="sessionExt"></GUIConfig>
		else if (std::strcmp(nm, "sessionExt") == 0)
		{
			NppXml::Node n = NppXml::firstChild(childNode);
			if (n)
			{
				const char* val = NppXml::getValue(n);
				if (val)
					_nppGUI._definedSessionExt = string2wstring(val);
			}
		}
		// <GUIConfig name="workspaceExt"></GUIConfig>
		else if (std::strcmp(nm, "workspaceExt") == 0)
		{
			NppXml::Node n = NppXml::firstChild(childNode);
			if (n)
			{
				const char* val = NppXml::getValue(n);
				if (val)
					_nppGUI._definedWorkspaceExt = string2wstring(val);
			}
		}
		// <GUIConfig name="noUpdate" intervalDays="15" nextUpdateDate="20080426" autoUpdateMode="1">no</GUIConfig>
		else if (std::strcmp(nm, "noUpdate") == 0)
		{
			NppXml::Node n = NppXml::firstChild(childNode);
			if (n)
			{
				using enum NppGUI::AutoUpdateMode;
				const char* val = NppXml::getValue(n);
				if (val)
				{
					// for backward compatibility with older configs
					_nppGUI._autoUpdateOpt._doAutoUpdate = (std::strcmp(val, "yes") == 0) ? autoupdate_disabled : autoupdate_on_startup;
				}

				_nppGUI._autoUpdateOpt._intervalDays = NppXml::intAttribute(childNode, "intervalDays", _nppGUI._autoUpdateOpt._intervalDays);

				const char* attrVal = NppXml::attribute(childNode, "nextUpdateDate");
				if (attrVal)
					_nppGUI._autoUpdateOpt._nextUpdateDate = Date(attrVal);

				const int iVal = NppXml::intAttribute(childNode, "autoUpdateMode", -1);
				if (iVal != -1)
					_nppGUI._autoUpdateOpt._doAutoUpdate = static_cast<NppGUI::AutoUpdateMode>(
						std::max(static_cast<int>(autoupdate_disabled), std::min(iVal, static_cast<int>(autoupdate_on_exit)))); // newer config, so overwrite
			}
		}
		// <GUIConfig name="openSaveDir" value="0" defaultDirPath="" lastUsedDirPath="" />
		else if (std::strcmp(nm, "openSaveDir") == 0)
		{
			using enum OpenSaveDirSetting;
			_nppGUI._openSaveDir = getRangeDefaultAttribute(childNode, "value", dir_followCurrent, dir_userDef, _nppGUI._openSaveDir);

			const std::wstring path = string2wstring(NppXml::attribute(childNode, "defaultDirPath", ""));
			if (!path.empty())
			{
				std::wcsncpy(_nppGUI._defaultDir, path.c_str(), MAX_PATH);
				::ExpandEnvironmentStrings(_nppGUI._defaultDir, _nppGUI._defaultDirExp, MAX_PATH);
			}

			const std::wstring lastPath = string2wstring(NppXml::attribute(childNode, "lastUsedDirPath", ""));
			if (!lastPath.empty())
			{
				std::wcsncpy(_nppGUI._lastUsedDir, lastPath.c_str(), MAX_PATH);
			}
		}
		// <GUIConfig name="titleBar" short="no" />
		else if (std::strcmp(nm, "titleBar") == 0)
		{
			_nppGUI._shortTitlebar = getBoolAttribute(childNode, "short");
		}
		// <GUIConfig name="insertDateTime" customizedFormat="yyyy-MM-dd HH:mm:ss" reverseDefaultOrder="no" />
		else if (std::strcmp(nm, "insertDateTime") == 0)
		{
			_nppGUI._dateTimeFormat = string2wstring(NppXml::attribute(childNode, "customizedFormat", ""));
			_nppGUI._dateTimeReverseDefaultOrder = getBoolAttribute(childNode, "reverseDefaultOrder");
		}
		// <GUIConfig name="wordCharList" useDefault="yes" charsAdded="" />
		else if (std::strcmp(nm, "wordCharList") == 0)
		{
			_nppGUI._isWordCharDefault = getBoolAttribute(childNode, "useDefault", _nppGUI._isWordCharDefault);
			_nppGUI._customWordChars = NppXml::attribute(childNode, "charsAdded", "");
		}
		// <GUIConfig name="delimiterSelection" leftmostDelimiter="40" rightmostDelimiter="41" delimiterSelectionOnEntireDocument="no" />
		else if (std::strcmp(nm, "delimiterSelection") == 0)
		{
			const int leftmost = getRangeDefaultAttribute(childNode, "leftmostDelimiter", 1, 255, -1);
			if (leftmost != -1)
				_nppGUI._leftmostDelimiter = static_cast<char>(leftmost);

			const int rightmost = getRangeDefaultAttribute(childNode, "rightmostDelimiter", 1, 255, -1);
			if (rightmost != -1)
				_nppGUI._rightmostDelimiter = static_cast<char>(rightmost);

			_nppGUI._delimiterSelectionOnEntireDocument = getBoolAttribute(childNode, "delimiterSelectionOnEntireDocument");
		}
		// <GUIConfig name="largeFileRestriction" fileSizeMB="200" isEnabled="yes" allowAutoCompletion="no" allowBraceMatch="no" allowSmartHilite="no"
		// allowClickableLink="no" deactivateWordWrap="yes" suppress2GBWarning="no" />
		else if (std::strcmp(nm, "largeFileRestriction") == 0)
		{
			const auto fileSizeLimit4StylingMB = getRangeDefaultAttribute(childNode, "fileSizeMB", 1LL, 4096LL, -1LL);
			if (fileSizeLimit4StylingMB != -1LL)
				_nppGUI._largeFileRestriction._largeFileSizeDefInByte = (fileSizeLimit4StylingMB * 1024 * 1024);

			_nppGUI._largeFileRestriction._isEnabled = getBoolAttribute(childNode, "isEnabled", _nppGUI._largeFileRestriction._isEnabled);
			_nppGUI._largeFileRestriction._allowAutoCompletion = getBoolAttribute(childNode, "allowAutoCompletion");
			_nppGUI._largeFileRestriction._allowBraceMatch = getBoolAttribute(childNode, "allowBraceMatch");
			_nppGUI._largeFileRestriction._allowSmartHilite = getBoolAttribute(childNode, "allowSmartHilite");
			_nppGUI._largeFileRestriction._allowClickableLink = getBoolAttribute(childNode, "allowClickableLink");
			_nppGUI._largeFileRestriction._deactivateWordWrap = getBoolAttribute(childNode, "deactivateWordWrap", _nppGUI._largeFileRestriction._deactivateWordWrap);
			_nppGUI._largeFileRestriction._suppress2GBWarning = getBoolAttribute(childNode, "suppress2GBWarning");
		}


		else if (std::strcmp(nm, "shortcutsXmlHMAC") == 0)
		{
			const char* shortcutsXmlHmacValue = NppXml::attribute(childNode, "value");
			if (shortcutsXmlHmacValue && shortcutsXmlHmacValue[0])
			{
				_nppGUI._shortcutsXmlHmacInConfig = shortcutsXmlHmacValue;
			}
		}

		// <GUIConfig name="multiInst" setting="0" clipboardHistory="no" documentList="no" characterPanel="no" folderAsWorkspace="no" projectPanels="no"
		// documentMap="no" fuctionList="no" pluginPanels="no" />
		else if (std::strcmp(nm, "multiInst") == 0)
		{
			using enum MultiInstSetting;
			_nppGUI._multiInstSetting = getRangeDefaultAttribute(childNode, "setting", monoInst, multiInst, _nppGUI._multiInstSetting);

			_nppGUI._clipboardHistoryPanelKeepState = getBoolAttribute(childNode, "clipboardHistory");
			_nppGUI._docListKeepState = getBoolAttribute(childNode, "documentList");
			_nppGUI._charPanelKeepState = getBoolAttribute(childNode, "characterPanel");
			_nppGUI._fileBrowserKeepState = getBoolAttribute(childNode, "folderAsWorkspace");
			_nppGUI._projectPanelKeepState = getBoolAttribute(childNode, "projectPanels");
			_nppGUI._docMapKeepState = getBoolAttribute(childNode, "documentMap");
			_nppGUI._funcListKeepState = getBoolAttribute(childNode, "fuctionList");
			_nppGUI._pluginPanelKeepState = getBoolAttribute(childNode, "pluginPanels");
		}
		// <GUIConfig name="searchEngine" searchEngineChoice="2" searchEngineCustom="" />
		else if (std::strcmp(nm, "searchEngine") == 0)
		{
			using enum NppGUI::SearchEngineChoice;
			_nppGUI._searchEngineChoice = getRangeDefaultAttribute(childNode, "searchEngineChoice", se_custom, se_stackoverflow, _nppGUI._searchEngineChoice);

			const char* searchEngineCustom = NppXml::attribute(childNode, "searchEngineCustom");
			if (searchEngineCustom && searchEngineCustom[0])
				_nppGUI._searchEngineCustom = string2wstring(searchEngineCustom);
		}
		// <GUIConfig name="Searching" monospacedFontFindDlg="no" fillFindFieldWithSelected="yes" fillFindFieldSelectCaret="yes"
		// findDlgAlwaysVisible="no" confirmReplaceInAllOpenDocs="yes" replaceStopsWithoutFindingNext="no" inSelectionAutocheckThreshold="1024"
		// fillFindWhatThreshold="1024" fillDirFieldFromActiveDoc="no" />
		else if (std::strcmp(nm, "Searching") == 0)
		{
			_nppGUI._monospacedFontFindDlg = getBoolAttribute(childNode, "monospacedFontFindDlg");

			//This is an option from previous versions of notepad++. It is handled for compatibility with older settings.
			const char* optStopFillingFindField = NppXml::attribute(childNode, "stopFillingFindField");
			if (optStopFillingFindField)
			{
				_nppGUI._fillFindFieldWithSelected = (std::strcmp(optStopFillingFindField, "no") == 0);
				_nppGUI._fillFindFieldSelectCaret = _nppGUI._fillFindFieldWithSelected;
			}

			_nppGUI._fillFindFieldWithSelected = getBoolAttribute(childNode, "fillFindFieldWithSelected", _nppGUI._fillFindFieldWithSelected);
			_nppGUI._fillFindFieldSelectCaret = getBoolAttribute(childNode, "fillFindFieldSelectCaret", _nppGUI._fillFindFieldSelectCaret);
			_nppGUI._findDlgAlwaysVisible = getBoolAttribute(childNode, "findDlgAlwaysVisible");
			_nppGUI._confirmReplaceInAllOpenDocs = getBoolAttribute(childNode, "confirmReplaceInAllOpenDocs", _nppGUI._confirmReplaceInAllOpenDocs);
			_nppGUI._replaceStopsWithoutFindingNext = getBoolAttribute(childNode, "replaceStopsWithoutFindingNext");

			_nppGUI._inSelectionAutocheckThreshold = getRangeDefaultAttribute(childNode, "inSelectionAutocheckThreshold", 0, FINDREPLACE_INSELECTION_THRESHOLD_DEFAULT, _nppGUI._inSelectionAutocheckThreshold);
			_nppGUI._fillFindWhatThreshold = getRangeDefaultAttribute(childNode, "fillFindWhatThreshold", 1, FINDREPLACE_MAXLENGTH - 1, _nppGUI._fillFindWhatThreshold);

			_nppGUI._fillDirFieldFromActiveDoc = getBoolAttribute(childNode, "fillDirFieldFromActiveDoc");
		}
		// <GUIConfig name="MISC" fileSwitcherWithoutExtColumn="no" fileSwitcherExtWidth="50" fileSwitcherWithoutPathColumn="no" fileSwitcherPathWidth="50"
		// fileSwitcherNoGroups="no" backSlashIsEscapeCharacterForSql="yes" writeTechnologyEngine="1" isFolderDroppedOpenFiles="no" docPeekOnTab="no"
		// docPeekOnMap="no" sortFunctionList="no" saveDlgExtFilterToAllTypes="no" muteSounds="no" enableFoldCmdToggable="no" hideMenuRightShortcuts="no"  networkPathWarningMethod=0/>
		else if (std::strcmp(nm, "MISC") == 0)
		{
			_nppGUI._fileSwitcherWithoutExtColumn = getBoolAttribute(childNode, "fileSwitcherWithoutExtColumn");
			_nppGUI._fileSwitcherExtWidth = NppXml::intAttribute(childNode, "fileSwitcherExtWidth", _nppGUI._fileSwitcherExtWidth);

			_nppGUI._fileSwitcherWithoutPathColumn = getBoolAttribute(childNode, "fileSwitcherWithoutPathColumn");
			_nppGUI._fileSwitcherPathWidth = NppXml::intAttribute(childNode, "fileSwitcherPathWidth", _nppGUI._fileSwitcherPathWidth);

			_nppGUI._fileSwitcherDisableListViewGroups = getBoolAttribute(childNode, "fileSwitcherNoGroups");

			_nppGUI._backSlashIsEscapeCharacterForSql = getBoolAttribute(childNode, "backSlashIsEscapeCharacterForSql", _nppGUI._backSlashIsEscapeCharacterForSql);

			{
				using enum writeTechnologyEngine;
				_nppGUI._writeTechnologyEngine = getRangeDefaultAttribute(childNode, "writeTechnologyEngine", defaultTechnology, directWriteTechnologyUnavailable, _nppGUI._writeTechnologyEngine);
			}

			_nppGUI._isFolderDroppedOpenFiles = getBoolAttribute(childNode, "isFolderDroppedOpenFiles");
			_nppGUI._isDocPeekOnTab = getBoolAttribute(childNode, "docPeekOnTab");
			_nppGUI._isDocPeekOnMap = getBoolAttribute(childNode, "docPeekOnMap");
			_nppGUI._shouldSortFunctionList = getBoolAttribute(childNode, "sortFunctionList");
			_nppGUI._setSaveDlgExtFiltToAllTypes = getBoolAttribute(childNode, "saveDlgExtFilterToAllTypes");
			_nppGUI._muteSounds = getBoolAttribute(childNode, "muteSounds");
			_nppGUI._enableFoldCmdToggable = getBoolAttribute(childNode, "enableFoldCmdToggable");
			_nppGUI._hideMenuRightShortcuts = getBoolAttribute(childNode, "hideMenuRightShortcuts");

			// ex _nppGUI member, for the compatibility reason
			/*_nppGUI.*/_networkPathAlwaysAction = static_cast<NetworkPathAlwaysAction>(NppXml::intAttribute(childNode, "networkPathWarningMethod", _networkPathAlwaysAction));
			// the value of _networkPathAlwaysAction will be overrided if the value exists in serverWhiteList

			_nppGUI._isFawSymlinkAllowed = getBoolAttribute(childNode, "isFawSymlinkAllowed", _nppGUI._isFawSymlinkAllowed);
		}
		// <GUIConfig name="DarkMode" enable="no" colorTone="0" customColorTop="2105376" customColorMenuHotTrack="4539717" customColorActive="3684408"
		// customColorMain="2105376" customColorError="176" customColorText="14737632" customColorDarkText="12632256" customColorDisabledText="8421504"
		// customColorLinkText="65535" customColorEdge="6579300" customColorHotEdge="10197915" customColorDisabledEdge="4737096" enableWindowsMode="no"
		// darkThemeName="DarkModeDefault.xml" darkToolBarIconSet="0" darkTbFluentColor="0" darkTbFluentCustomColor="0" darkTbFluentMono="no" darkTabIconSet="2"
		// darkTabUseTheme="no" lightThemeName="" lightToolBarIconSet="4" lightTbFluentColor="0" lightTbFluentCustomColor="33024" lightTbFluentMono="no"
		// lightTabIconSet="0" lightTabUseTheme="yes" />
		else if (std::strcmp(nm, "DarkMode") == 0)
		{
			_nppGUI._darkmode._isEnabled = getBoolAttribute(childNode, "enable");

			using enum NppDarkMode::ColorTone;
			const int clrTone = NppXml::intAttribute(childNode, "colorTone", 0);
			if (clrTone == static_cast<int>(customizedTone)
				|| (clrTone >= static_cast<int>(blackTone)
					&& clrTone <= static_cast<int>(oliveTone)))
			{
				_nppGUI._darkmode._colorTone = static_cast<NppDarkMode::ColorTone>(clrTone);
			}
			else
			{
				_nppGUI._darkmode._colorTone = blackTone;
			}
			_nppGUI._darkmode._customColors.pureBackground = NppXml::intAttribute(childNode, "customColorTop", 0x202020);
			_nppGUI._darkmode._customColors.hotBackground = NppXml::intAttribute(childNode, "customColorMenuHotTrack", 0x454545);
			_nppGUI._darkmode._customColors.softerBackground = NppXml::intAttribute(childNode, "customColorActive", 0x383838);
			_nppGUI._darkmode._customColors.background = NppXml::intAttribute(childNode, "customColorMain", 0x202020);
			_nppGUI._darkmode._customColors.errorBackground = NppXml::intAttribute(childNode, "customColorError", 0x0000B0);

			_nppGUI._darkmode._customColors.text = NppXml::intAttribute(childNode, "customColorText", 0xE0E0E0);
			_nppGUI._darkmode._customColors.darkerText = NppXml::intAttribute(childNode, "customColorDarkText", 0xC0C0C0);
			_nppGUI._darkmode._customColors.disabledText = NppXml::intAttribute(childNode, "customColorDisabledText", 0x808080);
			_nppGUI._darkmode._customColors.linkText = NppXml::intAttribute(childNode, "customColorLinkText", 0x00FFFF);

			_nppGUI._darkmode._customColors.edge = NppXml::intAttribute(childNode, "customColorEdge", 0x646464);
			_nppGUI._darkmode._customColors.hotEdge = NppXml::intAttribute(childNode, "customColorHotEdge", 0x9B9B9B);
			_nppGUI._darkmode._customColors.disabledEdge = NppXml::intAttribute(childNode, "customColorDisabledEdge", 0x484848);

			// advanced options section

			using enum toolBarStatusType;
			using enum FluentColor;

			auto& windowsMode = _nppGUI._darkmode._advOptions._enableWindowsMode;
			windowsMode = getBoolAttribute(childNode, "enableWindowsMode");

			auto& darkDefaults = _nppGUI._darkmode._advOptions._darkDefaults;
			auto& darkThemeName = darkDefaults._xmlFileName;
			auto& darkTbInfo = darkDefaults._tbIconInfo;
			darkThemeName = string2wstring(NppXml::attribute(childNode, "darkThemeName", "DarkModeDefault.xml"));
			if (darkThemeName.empty())
				darkThemeName = L"DarkModeDefault.xml";
			darkTbInfo._tbIconSet = getRangeDefaultAttribute(childNode, "darkToolBarIconSet", TB_SMALL, TB_STANDARD, darkTbInfo._tbIconSet);
			darkTbInfo._tbColor = getRangeDefaultAttribute(childNode, "darkTbFluentColor", defaultColor, custom, darkTbInfo._tbColor);
			darkTbInfo._tbCustomColor = NppXml::intAttribute(childNode, "darkTbFluentCustomColor", darkTbInfo._tbCustomColor);
			darkTbInfo._tbUseMono = getBoolAttribute(childNode, "darkTbFluentMono");
			darkDefaults._tabIconSet = getRangeDefaultAttribute(childNode, "darkTabIconSet", 0, 2, darkDefaults._tabIconSet);
			darkDefaults._tabUseTheme = getBoolAttribute(childNode, "darkTabUseTheme");

			auto& lightDefaults = _nppGUI._darkmode._advOptions._lightDefaults;
			auto& lightThemeName = lightDefaults._xmlFileName;
			auto& lightTbInfo = lightDefaults._tbIconInfo;
			lightThemeName = string2wstring(NppXml::attribute(childNode, "lightThemeName", ""));
			lightTbInfo._tbIconSet = getRangeDefaultAttribute(childNode, "lightToolBarIconSet", TB_SMALL, TB_STANDARD, lightTbInfo._tbIconSet);
			lightTbInfo._tbColor = getRangeDefaultAttribute(childNode, "lightTbFluentColor", defaultColor, custom, lightTbInfo._tbColor);
			lightTbInfo._tbCustomColor = NppXml::intAttribute(childNode, "lightTbFluentCustomColor", lightTbInfo._tbCustomColor);
			lightTbInfo._tbUseMono = getBoolAttribute(childNode, "lightTbFluentMono");
			lightDefaults._tabIconSet = getRangeDefaultAttribute(childNode, "lightTabIconSet", 0, 2, lightDefaults._tabIconSet);
			lightDefaults._tabUseTheme = getBoolAttribute(childNode, "lightTabUseTheme", lightDefaults._tabUseTheme);

			// Windows mode is handled later in Notepad_plus_Window::init from Notepad_plus_Window.cpp
			if (!windowsMode)
			{
				std::wstring themePath;
				std::wstring xmlFileName = _nppGUI._darkmode._isEnabled ? darkThemeName : lightThemeName;
				const bool isLocalOnly = _isLocal && !_isCloud;

				if (!xmlFileName.empty() && std::wcscmp(xmlFileName.c_str(), L"stylers.xml") != 0)
				{
					themePath = isLocalOnly ? _nppPath : _userPath;
					pathAppend(themePath, L"themes\\");
					pathAppend(themePath, xmlFileName);

					if (!isLocalOnly && !doesFileExist(themePath.c_str()))
					{
						themePath = _nppPath;
						pathAppend(themePath, L"themes\\");
						pathAppend(themePath, xmlFileName);
					}
				}
				else
				{
					themePath = isLocalOnly ? _nppPath : _userPath;
					pathAppend(themePath, L"stylers.xml");

					if (!isLocalOnly && !doesFileExist(themePath.c_str()))
					{
						themePath = _nppPath;
						pathAppend(themePath, L"stylers.xml");
					}
				}

				if (doesFileExist(themePath.c_str()))
				{
					_nppGUI._themeName.assign(themePath);
				}
			}
		}
	}
}

// <GUIConfig name="ScintillaPrimaryView" lineNumberMargin="show" lineNumberDynamicWidth="yes" bookMarkMargin="show" indentGuideLine="show"
// folderMarkStyle="box" isChangeHistoryEnabled="1" lineWrapMethod="aligned" currentLineIndicator="1" currentLineFrameWidth="1"
// virtualSpace="no" scrollBeyondLastLine="yes" rightClickKeepsSelection="no" selectedTextForegroundSingleColor="no" disableAdvancedScrolling="no"
// wrapSymbolShow="hide" Wrap="no" borderEdge="yes" isEdgeBgMode="no" edgeMultiColumnPos="" zoom="0" zoom2="0" whiteSpaceShow="hide"
// eolShow="hide" eolMode="1" npcShow="hide" npcMode="1" npcCustomColor="no" npcIncludeCcUniEOL="no" npcNoInputC0="yes" ccShow="yes"
// borderWidth="2" smoothFont="no" paddingLeft="0" paddingRight="0" distractionFreeDivPart="4" lineCopyCutWithoutSelection="yes"
// multiSelection="yes" columnSel2MultiEdit="yes" disableSelectedTextDragDrop="no" />
void NppParameters::feedScintillaParam(const NppXml::Element& element)
{
	// Line Number Margin
	_svp._lineNumberMarginShow = getBoolAttribute(element, "lineNumberMargin", _svp._lineNumberMarginShow, STR_BOOL_SHOWHIDE);
	// Line Number Margin dynamic width
	_svp._lineNumberMarginDynamicWidth = getBoolAttribute(element, "lineNumberDynamicWidth", _svp._lineNumberMarginDynamicWidth);
	// Bookmark Margin
	_svp._bookMarkMarginShow = getBoolAttribute(element, "bookMarkMargin", _svp._bookMarkMarginShow, STR_BOOL_SHOWHIDE);

	// Change History Margin
	{
		using enum changeHistoryState;
		if (const char* nm = NppXml::attribute(element, "isChangeHistoryEnabled");
			nm && std::strcmp(nm, "yes") == 0) // for the retro-compatibility
		{
			_svp._isChangeHistoryEnabled4NextSession = margin;
		}
		else
		{
			_svp._isChangeHistoryEnabled4NextSession = getRangeDefaultAttribute(element, "isChangeHistoryEnabled", disable, marginIndicator, _svp._isChangeHistoryEnabled4NextSession);
		}

		switch (_svp._isChangeHistoryEnabled4NextSession)
		{
			case disable:
			{
				_svp._isChangeHistoryMarginEnabled = false;
				_svp._isChangeHistoryIndicatorEnabled = false;
				break;
			}

			case margin:
			{
				_svp._isChangeHistoryMarginEnabled = true;
				_svp._isChangeHistoryIndicatorEnabled = false;
				break;
			}

			case indicator:
			{
				_svp._isChangeHistoryMarginEnabled = false;
				_svp._isChangeHistoryIndicatorEnabled = true;
				break;
			}

			case marginIndicator:
			{
				_svp._isChangeHistoryMarginEnabled = true;
				_svp._isChangeHistoryIndicatorEnabled = true;
				break;
			}

			default: // should not happen
			{
				_svp._isChangeHistoryMarginEnabled = true;
				_svp._isChangeHistoryIndicatorEnabled = false;
				_svp._isChangeHistoryEnabled4NextSession = margin;
				break;
			}
		}
	}

	// Indent GuideLine
	_svp._indentGuideLineShow = getBoolAttribute(element, "indentGuideLine", _svp._indentGuideLineShow, STR_BOOL_SHOWHIDE);

	// Folder Mark Style
	const char* nm = NppXml::attribute(element, "folderMarkStyle");
	if (nm)
	{
		using enum folderStyle;
		if (std::strcmp(nm, "box") == 0)
			_svp._folderStyle = FOLDER_STYLE_BOX;
		else if (std::strcmp(nm, "circle") == 0)
			_svp._folderStyle = FOLDER_STYLE_CIRCLE;
		else if (std::strcmp(nm, "arrow") == 0)
			_svp._folderStyle = FOLDER_STYLE_ARROW;
		else if (std::strcmp(nm, "simple") == 0)
			_svp._folderStyle = FOLDER_STYLE_SIMPLE;
		else if (std::strcmp(nm, "none") == 0)
			_svp._folderStyle = FOLDER_STYLE_NONE;
		else
			_svp._folderStyle = FOLDER_STYLE_BOX;
	}

	// Line Wrap method
	nm = NppXml::attribute(element, "lineWrapMethod");
	if (nm)
	{
		using enum lineWrapMethod;
		if (std::strcmp(nm, "default") == 0)
			_svp._lineWrapMethod = LINEWRAP_DEFAULT;
		else if (std::strcmp(nm, "aligned") == 0)
			_svp._lineWrapMethod = LINEWRAP_ALIGNED;
		else if (std::strcmp(nm, "indent") == 0)
			_svp._lineWrapMethod = LINEWRAP_INDENT;
		else
			_svp._lineWrapMethod = LINEWRAP_ALIGNED;
	}

	// Current Line Highlighting State
	{
		nm = NppXml::attribute(element, "currentLineHilitingShow");
		using enum lineHiliteMode;
		if (nm)
		{
			if (std::strcmp(nm, "show") == 0)
				_svp._currentLineHiliteMode = LINEHILITE_HILITE;
			else
				_svp._currentLineHiliteMode = LINEHILITE_NONE;
		}
		else
		{
			_svp._currentLineHiliteMode = getRangeDefaultAttribute(element, "currentLineIndicator", LINEHILITE_NONE, LINEHILITE_FRAME, _svp._currentLineHiliteMode);
		}
	}

	// Current Line Frame Width
	{
		_svp._currentLineFrameWidth = getRangeClampAttribute<unsigned char>(element, "currentLineFrameWidth", 1U, 6U, _svp._currentLineFrameWidth);
	}

	// Virtual Space
	_svp._virtualSpace = getBoolAttribute(element, "virtualSpace");

	// Scrolling Beyond Last Line State
	_svp._scrollBeyondLastLine = getBoolAttribute(element, "scrollBeyondLastLine", _svp._scrollBeyondLastLine);

	// Do not change selection or caret position when right-clicking with mouse
	_svp._rightClickKeepsSelection = getBoolAttribute(element, "rightClickKeepsSelection");

	// Make selected text foreground single color
	_svp._selectedTextForegroundSingleColor = getBoolAttribute(element, "selectedTextForegroundSingleColor");

	// Disable Advanced Scrolling
	_svp._disableAdvancedScrolling = getBoolAttribute(element, "disableAdvancedScrolling");

	// Current wrap symbol visibility State
	_svp._wrapSymbolShow = getBoolAttribute(element, "wrapSymbolShow", _svp._wrapSymbolShow, STR_BOOL_SHOWHIDE);

	// Do Wrap
	_svp._doWrap = getBoolAttribute(element, "Wrap");

	// Do Edge
	_svp._isEdgeBgMode = getBoolAttribute(element, "isEdgeBgMode");

	// Do Scintilla border edge
	_svp._showBorderEdge = getBoolAttribute(element, "borderEdge", _svp._showBorderEdge);

	nm = NppXml::attribute(element, "edgeMultiColumnPos");
	if (nm)
	{
		str2numberVector(string2wstring(nm), _svp._edgeMultiColumnPos);
	}

	_svp._zoom = static_cast<intptr_t>(NppXml::int64Attribute(element, "zoom", _svp._zoom));
	_svp._zoom2 = static_cast<intptr_t>(NppXml::int64Attribute(element, "zoom2", _svp._zoom2));
	_svp._zoomSync = getBoolAttribute(element, "zoomSync", _svp._zoomSync);

	// White Space visibility State
	_svp._whiteSpaceShow = getBoolAttribute(element, "whiteSpaceShow", _svp._whiteSpaceShow, STR_BOOL_SHOWHIDE);

	// EOL visibility State
	_svp._eolShow = getBoolAttribute(element, "eolShow", _svp._eolShow, STR_BOOL_SHOWHIDE);

	{
		using enum ScintillaViewParams::crlfMode;
		_svp._eolMode = getRangeDefaultAttribute(element, "eolMode", plainText, roundedRectangleTextCustomColor, _svp._eolMode);
	}

	// Unicode control and ws characters visibility state
	_svp._npcShow = getBoolAttribute(element, "npcShow", _svp._npcShow, STR_BOOL_SHOWHIDE);

	{
		using enum ScintillaViewParams::npcMode;
		_svp._npcMode = getRangeDefaultAttribute(element, "npcMode", identity, codepoint, _svp._npcMode);
	}

	_svp._npcCustomColor = getBoolAttribute(element, "npcCustomColor");
	_svp._npcIncludeCcUniEol = getBoolAttribute(element, "npcIncludeCcUniEOL");
	_svp._npcNoInputC0 = getBoolAttribute(element, "npcNoInputC0", _svp._npcNoInputC0);

	// C0, C1 control and Unicode EOL visibility state
	_svp._ccUniEolShow = getBoolAttribute(element, "ccShow", _svp._ccUniEolShow);

	_svp._borderWidth = getRangeClampAttribute(element, "borderWidth", 0, 30, _svp._borderWidth);

	// Do antialiased font
	_svp._doSmoothFont = getBoolAttribute(element, "smoothFont");

	_svp._paddingLeft = getRangeClampAttribute<unsigned char>(element, "paddingLeft", 0U, 30U, _svp._paddingLeft);
	_svp._paddingRight = getRangeClampAttribute<unsigned char>(element, "paddingRight", 0U, 30U, _svp._paddingRight);

	_svp._distractionFreeDivPart = getRangeClampAttribute<unsigned char>(element, "distractionFreeDivPart", 3U, 9U, _svp._distractionFreeDivPart);

	_svp._lineCopyCutWithoutSelection = getBoolAttribute(element, "lineCopyCutWithoutSelection", _svp._lineCopyCutWithoutSelection);
	_svp._disableSelectedTextDragDrop = getBoolAttribute(element, "disableSelectedTextDragDrop", _svp._disableSelectedTextDragDrop);
	_svp._multiSelection = getBoolAttribute(element, "multiSelection", _svp._multiSelection);
	_svp._columnSel2MultiEdit = getBoolAttribute(element, "columnSel2MultiEdit", _svp._columnSel2MultiEdit);
}

// <GUIConfig name="DockingManager" leftWidth="200" rightWidth="200" topHeight="200" bottomHeight="200">
//     <ActiveTabs cont="0" activeTab="-1" />
//     <ActiveTabs cont="1" activeTab="-1" />
//     <ActiveTabs cont="2" activeTab="-1" />
//     <ActiveTabs cont="3" activeTab="-1" />
// </GUIConfig>
void NppParameters::feedDockingManager(const NppXml::Element& element)
{
	SIZE maxMonitorSize{ ::GetSystemMetrics(SM_CXSCREEN), ::GetSystemMetrics(SM_CYSCREEN) }; // use primary monitor as the default
	SIZE nppSize = maxMonitorSize;
	HWND hwndNpp = ::FindWindow(Notepad_plus_Window::getClassName(), NULL);
	if (hwndNpp)
	{
		// this code-branch is currently reached only if the Notepad++ multi-instance mode is ON and it is not the 1st Notepad++ instance
		// (the feedDockingManager() is called at the Notepad++ init via the wWinMain nppParameters.load()))

		HMONITOR hCurMon = ::MonitorFromWindow(hwndNpp, MONITOR_DEFAULTTONEAREST);
		if (hCurMon)
		{
			MONITORINFO mi{};
			mi.cbSize = sizeof(MONITORINFO);
			if (::GetMonitorInfo(hCurMon, &mi))
			{
				maxMonitorSize.cx = mi.rcMonitor.right - mi.rcMonitor.left;
				maxMonitorSize.cy = mi.rcMonitor.bottom - mi.rcMonitor.top;
				nppSize = maxMonitorSize;
			}
		}

		RECT rcNpp{};
		if (::GetClientRect(hwndNpp, &rcNpp))
		{
			// rcNpp RECT could have zero size here! (if the 1st instance of Notepad++ is minimized to the task-bar (systray is ok))
			if ((rcNpp.right > _nppGUI._dockingData._minDockedPanelVisibility) && (rcNpp.bottom > _nppGUI._dockingData._minDockedPanelVisibility))
			{
				// adjust according to the current Notepad++ client-wnd area
				nppSize.cx = rcNpp.right;
				nppSize.cy = rcNpp.bottom;
			}
		}
	}
	else
	{
		// no real Notepad++ wnd available, so try to use the previously saved config.xml data instead
		if (!_nppGUI._isMaximized)
		{
			if (((_nppGUI._appPos.right > DMD_PANEL_WH_DEFAULT) && (_nppGUI._appPos.right < maxMonitorSize.cx))
				&& ((_nppGUI._appPos.bottom > DMD_PANEL_WH_DEFAULT) && (_nppGUI._appPos.bottom < maxMonitorSize.cy)))
			{
				nppSize.cx = _nppGUI._appPos.right;
				nppSize.cy = _nppGUI._appPos.bottom;
			}
		}
	}

	auto setPanelSize = [&element, &nppSize, this](int& size2set, const char* attrName)
	{
		const int panelSize = NppXml::intAttribute(element, attrName, DMD_PANEL_WH_DEFAULT);
		if (panelSize > _nppGUI._dockingData._minDockedPanelVisibility)
		{
			if (panelSize < (nppSize.cx - _nppGUI._dockingData._minDockedPanelVisibility))
				size2set = panelSize;
			else
				size2set = nppSize.cx - _nppGUI._dockingData._minDockedPanelVisibility; // invalid, reset
		}
		else
		{
			// invalid, reset
			size2set = _nppGUI._dockingData._minDockedPanelVisibility;
		}
	};

	setPanelSize(_nppGUI._dockingData._leftWidth, "leftWidth");
	setPanelSize(_nppGUI._dockingData._rightWidth, "rightWidth");
	setPanelSize(_nppGUI._dockingData._topHeight, "topHeight");
	setPanelSize(_nppGUI._dockingData._bottomHeight, "bottomHeight");

	for (NppXml::Element childNode = NppXml::firstChildElement(element, "FloatingWindow");
		childNode;
		childNode = NppXml::nextSiblingElement(childNode, "FloatingWindow"))
	{
		const int cont = NppXml::intAttribute(childNode, "cont", -1);
		if (cont > -1)
		{
			int x = NppXml::intAttribute(childNode, "x", 0);
			int y = NppXml::intAttribute(childNode, "y", 0);
			int w = NppXml::intAttribute(childNode, "width", FWI_PANEL_WH_DEFAULT);
			int h = NppXml::intAttribute(childNode, "height", FWI_PANEL_WH_DEFAULT);

			if (!isWindowVisibleOnAnyMonitor(RECT{ x,y,w,h }))
			{
				// reset to adjusted factory defaults
				// (and the panel will automatically be on the current primary monitor due to the x,y == 0,0)
				x = 0;
				y = 0;
				w = _nppGUI._dockingData._minFloatingPanelSize.cx;
				h = _nppGUI._dockingData._minFloatingPanelSize.cy + FWI_PANEL_WH_DEFAULT;
			}

			_nppGUI._dockingData._floatingWindowInfo.emplace_back(cont, x, y, w, h);
		}
	}

	for (NppXml::Element childNode = NppXml::firstChildElement(element, "PluginDlg");
		childNode;
		childNode = NppXml::nextSiblingElement(childNode, "PluginDlg"))
	{
		const char* name = NppXml::attribute(childNode, "pluginName");

		const int id = NppXml::intAttribute(childNode, "id", -1);
		if (name && id > -1)
		{
			const int current = NppXml::intAttribute(childNode, "curr", 0); // on left
			const int prev = NppXml::intAttribute(childNode, "prev", 0); // on left
			const bool isVisible = getBoolAttribute(childNode, "isVisible");

			_nppGUI._dockingData._pluginDockInfo.emplace_back(string2wstring(name).c_str(), id, current, prev, isVisible);
		}
	}

	for (NppXml::Element childNode = NppXml::firstChildElement(element, "ActiveTabs");
		childNode;
		childNode = NppXml::nextSiblingElement(childNode, "ActiveTabs"))
	{
		const int cont = NppXml::intAttribute(childNode, "cont", -1);
		if (cont > -1)
		{
			const int activeTab = NppXml::intAttribute(childNode, "activeTab", 0);
			_nppGUI._dockingData._containerTabInfo.emplace_back(cont, activeTab);
		}
	}
}

bool NppParameters::writeScintillaParams()
{
	if (!_xmlUserDoc._doc) return false;

	const char* pViewName = "ScintillaPrimaryView";
	NppXml::Element nppRoot = NppXml::firstChildElement(_xmlUserDoc._doc, "NotepadPlus");
	if (!nppRoot)
	{
		nppRoot = NppXml::createChildElement(_xmlUserDoc._doc, "NotepadPlus");
	}

	NppXml::Element configsRoot = NppXml::firstChildElement(nppRoot, "GUIConfigs");
	if (!configsRoot)
	{
		configsRoot = NppXml::createChildElement(nppRoot, "GUIConfigs");
	}

	NppXml::Element scintNode = getChildElementByAttribute(configsRoot, "GUIConfig", "name", pViewName);
	if (!scintNode)
	{
		scintNode = NppXml::createChildElement(configsRoot, "GUIConfig");
		NppXml::setAttribute(scintNode, "name", pViewName);
	}

	setBoolAttribute(scintNode, "lineNumberMargin", _svp._lineNumberMarginShow, STR_BOOL_SHOWHIDE);
	setBoolAttribute(scintNode, "lineNumberDynamicWidth", _svp._lineNumberMarginDynamicWidth);
	setBoolAttribute(scintNode, "bookMarkMargin", _svp._bookMarkMarginShow, STR_BOOL_SHOWHIDE);
	setBoolAttribute(scintNode, "indentGuideLine", _svp._indentGuideLineShow, STR_BOOL_SHOWHIDE);

	const char* pFolderStyleStr = nullptr;
	switch (_svp._folderStyle)
	{
		using enum folderStyle;
		case FOLDER_TYPE:
		case FOLDER_STYLE_BOX:
		{
			pFolderStyleStr = "box";
			break;
		}

		case FOLDER_STYLE_SIMPLE:
		{
			pFolderStyleStr = "simple";
			break;
		}

		case FOLDER_STYLE_ARROW:
		{
			pFolderStyleStr = "arrow";
			break;
		}

		case FOLDER_STYLE_CIRCLE:
		{
			pFolderStyleStr = "circle";
			break;
		}

		case FOLDER_STYLE_NONE:
		{
			pFolderStyleStr = "none";
			break;
		}
	}

	NppXml::setAttribute(scintNode, "folderMarkStyle", pFolderStyleStr);
	NppXml::setAttribute(scintNode, "isChangeHistoryEnabled", _svp._isChangeHistoryEnabled4NextSession); // no -> 0 (disable), yes -> 1 (margin), yes -> 2 (indicator), yes-> 3 (margin + indicator)

	const char* pWrapMethodStr = nullptr;
	switch (_svp._lineWrapMethod)
	{
		using enum lineWrapMethod;
		case LINEWRAP_DEFAULT:
		{
			pWrapMethodStr = "default";
			break;
		}

		case LINEWRAP_ALIGNED:
		{
			pWrapMethodStr = "aligned";
			break;
		}

		case LINEWRAP_INDENT:
		{
			pWrapMethodStr = "indent";
			break;
		}
	}

	NppXml::setAttribute(scintNode, "lineWrapMethod", pWrapMethodStr);

	NppXml::setAttribute(scintNode, "currentLineIndicator", _svp._currentLineHiliteMode);
	NppXml::setAttribute(scintNode, "currentLineFrameWidth", _svp._currentLineFrameWidth);

	setBoolAttribute(scintNode, "virtualSpace", _svp._virtualSpace);
	setBoolAttribute(scintNode, "scrollBeyondLastLine", _svp._scrollBeyondLastLine);
	setBoolAttribute(scintNode, "rightClickKeepsSelection", _svp._rightClickKeepsSelection);
	setBoolAttribute(scintNode, "selectedTextForegroundSingleColor", _svp._selectedTextForegroundSingleColor);
	setBoolAttribute(scintNode, "disableAdvancedScrolling", _svp._disableAdvancedScrolling);
	setBoolAttribute(scintNode, "wrapSymbolShow", _svp._wrapSymbolShow, STR_BOOL_SHOWHIDE);
	setBoolAttribute(scintNode, "Wrap", _svp._doWrap);
	setBoolAttribute(scintNode, "borderEdge", _svp._showBorderEdge);

	std::string edgeColumnPosStr;
	for (const auto& i : _svp._edgeMultiColumnPos)
	{
		edgeColumnPosStr += std::to_string(i);
		edgeColumnPosStr += " ";
	}
	setBoolAttribute(scintNode, "isEdgeBgMode", _svp._isEdgeBgMode);
	NppXml::setAttribute(scintNode, "edgeMultiColumnPos", edgeColumnPosStr);
	NppXml::setAttribute(scintNode, "zoom", _svp._zoom);
	NppXml::setAttribute(scintNode, "zoom2", _svp._zoom2);
	setBoolAttribute(scintNode, "zoomSync", _svp._zoomSync);
	setBoolAttribute(scintNode, "whiteSpaceShow", _svp._whiteSpaceShow, STR_BOOL_SHOWHIDE);
	setBoolAttribute(scintNode, "eolShow", _svp._eolShow, STR_BOOL_SHOWHIDE);
	NppXml::setAttribute(scintNode, "eolMode", _svp._eolMode);
	setBoolAttribute(scintNode, "npcShow", _svp._npcShow, STR_BOOL_SHOWHIDE);
	NppXml::setAttribute(scintNode, "npcMode", _svp._npcMode);
	setBoolAttribute(scintNode, "npcCustomColor", _svp._npcCustomColor);
	setBoolAttribute(scintNode, "npcIncludeCcUniEOL", _svp._npcIncludeCcUniEol);
	setBoolAttribute(scintNode, "npcNoInputC0", _svp._npcNoInputC0);
	setBoolAttribute(scintNode, "ccShow", _svp._ccUniEolShow);
	NppXml::setAttribute(scintNode, "borderWidth", _svp._borderWidth);
	setBoolAttribute(scintNode, "smoothFont", _svp._doSmoothFont);
	NppXml::setAttribute(scintNode, "paddingLeft", _svp._paddingLeft);
	NppXml::setAttribute(scintNode, "paddingRight", _svp._paddingRight);
	NppXml::setAttribute(scintNode, "distractionFreeDivPart", _svp._distractionFreeDivPart);
	setBoolAttribute(scintNode, "lineCopyCutWithoutSelection", _svp._lineCopyCutWithoutSelection);
	setBoolAttribute(scintNode, "disableSelectedTextDragDrop", _svp._disableSelectedTextDragDrop);

	setBoolAttribute(scintNode, "multiSelection", _svp._multiSelection);
	const bool canEnableColumnSel2MultiEdit = _svp._multiSelection && _svp._columnSel2MultiEdit;
	setBoolAttribute(scintNode, "columnSel2MultiEdit", canEnableColumnSel2MultiEdit);

	return true;
}

void NppParameters::createXmlTreeFromGUIParams()
{
	NppXml::Element nppRoot = NppXml::firstChildElement(_xmlUserDoc._doc, "NotepadPlus");
	if (!nppRoot)
	{
		nppRoot = NppXml::createChildElement(_xmlUserDoc._doc, "NotepadPlus");
	}

	NppXml::Element oldGUIRoot = NppXml::firstChildElement(nppRoot, "GUIConfigs");
	NppXml::Document tempDoc = nullptr;
	NppXml::Element dockMngNodeDup;
	NppXml::Element dockMngNodeOriginal;
	if (oldGUIRoot && _nppGUI._isCmdlineNosessionActivated)
	{
		for (NppXml::Element childNode = NppXml::firstChildElement(oldGUIRoot, "GUIConfig");
			childNode;
			childNode = NppXml::nextSiblingElement(childNode, "GUIConfig"))
		{
			const char* nm = NppXml::attribute(childNode, "name");
			if (!nm)
				continue;

			if (std::strcmp(nm, "DockingManager") == 0)
			{
				dockMngNodeOriginal = childNode;
				break;
			}
		}

		// Copy DockingParamNode
		if (dockMngNodeOriginal)
		{
			tempDoc = new NppXml::NewDocument;
			NppXml::Element tempElem = NppXml::createChildElement(tempDoc, "GUIConfigs");
			dockMngNodeDup = NppXml::insertEndChild(tempElem, dockMngNodeOriginal);
		}
	}

	// Remove the old root node if it exist
	if (oldGUIRoot)
	{
		NppXml::deleteChild(nppRoot, oldGUIRoot);
	}

	NppXml::Element newGUIRoot = NppXml::createChildElement(nppRoot, "GUIConfigs");

	// <GUIConfig name="ToolBar" visible="yes" fluentColor="0" fluentCustomColor="0" fluentMono="no">standard</GUIConfig>
	{
		NppXml::Element GUIConfigElement = NppXml::createChildElement(newGUIRoot, "GUIConfig");
		const auto& nppGUITbInfo = _nppGUI._tbIconInfo;
		NppXml::setAttribute(GUIConfigElement, "name", "ToolBar");
		setBoolAttribute(GUIConfigElement, "visible", _nppGUI._toolbarShow);
		NppXml::setAttribute(GUIConfigElement, "fluentColor", static_cast<int>(nppGUITbInfo._tbColor));
		NppXml::setAttribute(GUIConfigElement, "fluentCustomColor", nppGUITbInfo._tbCustomColor);
		setBoolAttribute(GUIConfigElement, "fluentMono", nppGUITbInfo._tbUseMono);

		const char* pStr = nullptr;
		switch (nppGUITbInfo._tbIconSet)
		{
			using enum toolBarStatusType;
			case TB_SMALL:
			{
				pStr = "small";
				break;
			}

			case TB_LARGE:
			{
				pStr = "large";
				break;
			}

			case TB_SMALL2:
			{
				pStr = "small2";
				break;
			}

			case TB_LARGE2:
			{
				pStr = "large2";
				break;
			}

			case TB_STANDARD:
			{
				pStr = "standard";
				break;
			}
		}
		NppXml::createChildText(GUIConfigElement, pStr);
	}

	// <GUIConfig name="StatusBar">show</GUIConfig>
	{
		NppXml::Element GUIConfigElement = NppXml::createChildElement(newGUIRoot, "GUIConfig");
		NppXml::setAttribute(GUIConfigElement, "name", "StatusBar");
		NppXml::createChildText(GUIConfigElement, _nppGUI._statusBarShow ? "show" : "hide");
	}

	// <GUIConfig name="TabBar" dragAndDrop="yes" drawTopBar="yes" drawInactiveTab="yes" reduce="yes" closeButton="yes"
	// pinButton="yes" showOnlyPinnedButton="no" buttonsOninactiveTabs="no" doubleClick2Close="no"
	// vertical="no" multiLine="no" hide="no" quitOnEmpty="no" tabCompactLabelLen="0" />
	{
		NppXml::Element GUIConfigElement = NppXml::createChildElement(newGUIRoot, "GUIConfig");
		NppXml::setAttribute(GUIConfigElement, "name", "TabBar");

		setBoolAttribute(GUIConfigElement, "dragAndDrop", (_nppGUI._tabStatus & TAB_DRAGNDROP) != 0);
		setBoolAttribute(GUIConfigElement, "drawTopBar", (_nppGUI._tabStatus & TAB_DRAWTOPBAR) != 0);
		setBoolAttribute(GUIConfigElement, "drawInactiveTab", (_nppGUI._tabStatus & TAB_DRAWINACTIVETAB) != 0);
		setBoolAttribute(GUIConfigElement, "reduce", (_nppGUI._tabStatus & TAB_REDUCE) != 0);
		setBoolAttribute(GUIConfigElement, "closeButton", (_nppGUI._tabStatus & TAB_CLOSEBUTTON) != 0);
		setBoolAttribute(GUIConfigElement, "pinButton", (_nppGUI._tabStatus & TAB_PINBUTTON) != 0);
		setBoolAttribute(GUIConfigElement, "showOnlyPinnedButton", (_nppGUI._tabStatus & TAB_SHOWONLYPINNEDBUTTON) != 0);
		setBoolAttribute(GUIConfigElement, "buttonsOninactiveTabs", (_nppGUI._tabStatus & TAB_INACTIVETABSHOWBUTTON) != 0);
		setBoolAttribute(GUIConfigElement, "doubleClick2Close", (_nppGUI._tabStatus & TAB_DBCLK2CLOSE) != 0);
		setBoolAttribute(GUIConfigElement, "vertical", (_nppGUI._tabStatus & TAB_VERTICAL) != 0);
		setBoolAttribute(GUIConfigElement, "multiLine", (_nppGUI._tabStatus & TAB_MULTILINE) != 0);
		setBoolAttribute(GUIConfigElement, "hide", (_nppGUI._tabStatus & TAB_HIDE) != 0 && !_nppGUI._forceTabbarVisible);
		setBoolAttribute(GUIConfigElement, "quitOnEmpty", (_nppGUI._tabStatus & TAB_QUITONEMPTY) != 0);

		NppXml::setAttribute(GUIConfigElement, "tabCompactLabelLen", _nppGUI._tabCompactLabelLen);
	}

	// <GUIConfig name="ScintillaViewsSplitter">vertical</GUIConfig>
	{
		NppXml::Element GUIConfigElement = NppXml::createChildElement(newGUIRoot, "GUIConfig");
		NppXml::setAttribute(GUIConfigElement, "name", "ScintillaViewsSplitter");
		NppXml::createChildText(GUIConfigElement, _nppGUI._splitterPos ? "vertical" : "horizontal"); // POS_VERTICAL == true
	}

	// <GUIConfig name="UserDefineDlg" position="undocked">hide</GUIConfig>
	{
		NppXml::Element GUIConfigElement = NppXml::createChildElement(newGUIRoot, "GUIConfig");
		NppXml::setAttribute(GUIConfigElement, "name", "UserDefineDlg");
		NppXml::setAttribute(GUIConfigElement, "position", (_nppGUI._userDefineDlgStatus & UDD_DOCKED) != 0 ? "docked" : "undocked");
		NppXml::createChildText(GUIConfigElement, (_nppGUI._userDefineDlgStatus & UDD_SHOW) != 0 ? "show" : "hide");
	}

	// <GUIConfig name="TabSetting" replaceBySpace="no" size="4" backspaceUnindent="no" />
	{
		NppXml::Element GUIConfigElement = NppXml::createChildElement(newGUIRoot, "GUIConfig");
		NppXml::setAttribute(GUIConfigElement, "name", "TabSetting");
		setBoolAttribute(GUIConfigElement, "replaceBySpace", _nppGUI._tabReplacedBySpace);
		NppXml::setAttribute(GUIConfigElement, "size", _nppGUI._tabSize);
		setBoolAttribute(GUIConfigElement, "backspaceUnindent", _nppGUI._backspaceUnindent);
	}

	// <GUIConfig name="AppPosition" x="0" y="0" width="1100" height="700" isMaximized="no" />
	{
		NppXml::Element GUIConfigElement = NppXml::createChildElement(newGUIRoot, "GUIConfig");
		NppXml::setAttribute(GUIConfigElement, "name", "AppPosition");
		NppXml::setAttribute(GUIConfigElement, "x", _nppGUI._appPos.left);
		NppXml::setAttribute(GUIConfigElement, "y", _nppGUI._appPos.top);
		NppXml::setAttribute(GUIConfigElement, "width", _nppGUI._appPos.right);
		NppXml::setAttribute(GUIConfigElement, "height", _nppGUI._appPos.bottom);
		setBoolAttribute(GUIConfigElement, "isMaximized", _nppGUI._isMaximized);
	}

	// <GUIConfig name="FindWindowPosition" left="134" top="320" right="723" bottom="684" />
	{
		NppXml::Element GUIConfigElement = NppXml::createChildElement(newGUIRoot, "GUIConfig");
		NppXml::setAttribute(GUIConfigElement, "name", "FindWindowPosition");
		NppXml::setAttribute(GUIConfigElement, "left", _nppGUI._findWindowPos.left);
		NppXml::setAttribute(GUIConfigElement, "top", _nppGUI._findWindowPos.top);
		NppXml::setAttribute(GUIConfigElement, "right", _nppGUI._findWindowPos.right);
		NppXml::setAttribute(GUIConfigElement, "bottom", _nppGUI._findWindowPos.bottom);
		setBoolAttribute(GUIConfigElement, "isLessModeOn", _nppGUI._findWindowLessMode);
	}

	// <GUIConfig name="FinderConfig" wrappedLines="no" purgeBeforeEverySearch="no" showOnlyOneEntryPerFoundLine="yes" FiF_ignoreunsavedChangesInOpenedFiles="no" />
	{
		NppXml::Element GUIConfigElement = NppXml::createChildElement(newGUIRoot, "GUIConfig");
		NppXml::setAttribute(GUIConfigElement, "name", "FinderConfig");
		setBoolAttribute(GUIConfigElement, "wrappedLines", _nppGUI._finderLinesAreCurrentlyWrapped);
		setBoolAttribute(GUIConfigElement, "purgeBeforeEverySearch", _nppGUI._finderPurgeBeforeEverySearch);
		setBoolAttribute(GUIConfigElement, "showOnlyOneEntryPerFoundLine", _nppGUI._finderShowOnlyOneEntryPerFoundLine);
		setBoolAttribute(GUIConfigElement, "FiF_ignoreunsavedChangesInOpenedFiles", _nppGUI._fif_ignoreunsavedChangesInOpenedFiles);
	}

	// <GUIConfig name="noUpdate" intervalDays="15" nextUpdateDate="20161022" autoUpdateMode="1">no</GUIConfig>
	{
		NppXml::Element GUIConfigElement = insertGUIConfigBoolNode(newGUIRoot, "noUpdate", _nppGUI._autoUpdateOpt._doAutoUpdate == NppGUI::AutoUpdateMode::autoupdate_disabled);
		NppXml::setAttribute(GUIConfigElement, "intervalDays", _nppGUI._autoUpdateOpt._intervalDays);
		NppXml::setAttribute(GUIConfigElement, "nextUpdateDate", _nppGUI._autoUpdateOpt._nextUpdateDate.toString());
		NppXml::setAttribute(GUIConfigElement, "autoUpdateMode", _nppGUI._autoUpdateOpt._doAutoUpdate);
	}

	// <GUIConfig name="Auto-detection">yes</GUIConfig>
	{
		const char* pStr = nullptr;

		if (_nppGUI._fileAutoDetection & cdEnabledOld)
		{
			if ((_nppGUI._fileAutoDetection & cdAutoUpdate) && (_nppGUI._fileAutoDetection & cdGo2end))
			{
				pStr = "autoUpdate2EndOld";
			}
			else if (_nppGUI._fileAutoDetection & cdAutoUpdate)
			{
				pStr = "autoOld";
			}
			else if (_nppGUI._fileAutoDetection & cdGo2end)
			{
				pStr = "Update2EndOld";
			}
			else
			{
				pStr = "yesOld";
			}
		}
		else if (_nppGUI._fileAutoDetection & cdEnabledNew)
		{
			if ((_nppGUI._fileAutoDetection & cdAutoUpdate) && (_nppGUI._fileAutoDetection & cdGo2end))
			{
				pStr = "autoUpdate2End";
			}
			else if (_nppGUI._fileAutoDetection & cdAutoUpdate)
			{
				pStr = "auto";
			}
			else if (_nppGUI._fileAutoDetection & cdGo2end)
			{
				pStr = "Update2End";
			}
			else
			{
				pStr = "yes";
			}
		}
		else
		{
			pStr = "no";
		}

		NppXml::Element GUIConfigElement = NppXml::createChildElement(newGUIRoot, "GUIConfig");
		NppXml::setAttribute(GUIConfigElement, "name", "Auto-detection");
		NppXml::createChildText(GUIConfigElement, pStr);
	}

	// <GUIConfig name="CheckHistoryFiles">no</GUIConfig>
	{
		insertGUIConfigBoolNode(newGUIRoot, "CheckHistoryFiles", _nppGUI._checkHistoryFiles);
	}

	// <GUIConfig name="TrayIcon">0</GUIConfig>
	{
		NppXml::Element GUIConfigElement = NppXml::createChildElement(newGUIRoot, "GUIConfig");
		NppXml::setAttribute(GUIConfigElement, "name", "TrayIcon");
		NppXml::createChildText(GUIConfigElement, std::to_string(_nppGUI._isMinimizedToTray));
	}

	// <GUIConfig name="MaintainIndent">1</GUIConfig>
	{
		//insertGUIConfigBoolNode(newGUIRoot, L"MaintainIndent", _nppGUI._maintainIndent);
		NppXml::Element GUIConfigElement = NppXml::createChildElement(newGUIRoot, "GUIConfig");
		NppXml::setAttribute(GUIConfigElement, "name", "MaintainIndent");
		NppXml::createChildText(GUIConfigElement, std::to_string(_nppGUI._maintainIndent));
	}

	// <GUIConfig name="TagsMatchHighLight" TagAttrHighLight="yes" HighLightNonHtmlZone="no">yes</GUIConfig>
	{
		NppXml::Element GUIConfigElement = insertGUIConfigBoolNode(newGUIRoot, "TagsMatchHighLight", _nppGUI._enableTagsMatchHilite);
		setBoolAttribute(GUIConfigElement, "TagAttrHighLight", _nppGUI._enableTagAttrsHilite);
		setBoolAttribute(GUIConfigElement, "HighLightNonHtmlZone", _nppGUI._enableHiliteNonHTMLZone);
	}

	// <GUIConfig name="RememberLastSession">yes</GUIConfig>
	{
		insertGUIConfigBoolNode(newGUIRoot, "RememberLastSession", _nppGUI._rememberLastSession);
	}

	// <GUIConfig name="KeepSessionAbsentFileEntries">no</GUIConfig>
	{
		insertGUIConfigBoolNode(newGUIRoot, "KeepSessionAbsentFileEntries", _nppGUI._keepSessionAbsentFileEntries);
	}

	// <GUIConfig name="DetectEncoding">yes</GUIConfig>
	{
		insertGUIConfigBoolNode(newGUIRoot, "DetectEncoding", _nppGUI._detectEncoding);
	}

	// <GUIConfig name="SaveAllConfirm">yes</GUIConfig>
	{
		insertGUIConfigBoolNode(newGUIRoot, "SaveAllConfirm", _nppGUI._saveAllConfirm);
	}

	// <GUIConfig name="NewDocDefaultSettings" format="0" encoding="4" lang="0" codepage="-1" openAnsiAsUTF8="yes" addNewDocumentOnStartup="no" useContentAsTabName="no" />
	{
		NppXml::Element GUIConfigElement = NppXml::createChildElement(newGUIRoot, "GUIConfig");
		NppXml::setAttribute(GUIConfigElement, "name", "NewDocDefaultSettings");
		NppXml::setAttribute(GUIConfigElement, "format", static_cast<int>(_nppGUI._newDocDefaultSettings._format));
		NppXml::setAttribute(GUIConfigElement, "encoding", _nppGUI._newDocDefaultSettings._unicodeMode);
		NppXml::setAttribute(GUIConfigElement, "lang", _nppGUI._newDocDefaultSettings._lang);
		NppXml::setAttribute(GUIConfigElement, "codepage", _nppGUI._newDocDefaultSettings._codepage);
		setBoolAttribute(GUIConfigElement, "openAnsiAsUTF8", _nppGUI._newDocDefaultSettings._openAnsiAsUtf8);
		setBoolAttribute(GUIConfigElement, "addNewDocumentOnStartup", _nppGUI._newDocDefaultSettings._addNewDocumentOnStartup);
		setBoolAttribute(GUIConfigElement, "useContentAsTabName", _nppGUI._newDocDefaultSettings._useContentAsTabName);
	}

	// <GUIConfig name="langsExcluded" gr0="0" gr1="0" gr2="0" gr3="0" gr4="0" gr5="0" gr6="0" gr7="0" gr8="0" gr9="0" gr10="0" gr11="0" gr12="0" langMenuCompact="yes" />
	{
		NppXml::Element GUIConfigElement = NppXml::createChildElement(newGUIRoot, "GUIConfig");
		NppXml::setAttribute(GUIConfigElement, "name", "langsExcluded");
		writeExcludedLangList(GUIConfigElement);
		setBoolAttribute(GUIConfigElement, "langMenuCompact", _nppGUI._isLangMenuCompact);
	}

	// <GUIConfig name="Print" lineNumber="no" printOption="0" headerLeft="$(FULL_CURRENT_PATH)" headerMiddle="" headerRight="$(LONG_DATE) $(TIME)" headerFontName="IBMPC"
	// headerFontStyle="1" headerFontSize="8" footerLeft="" footerMiddle="-$(CURRENT_PRINTING_PAGE)-" footerRight="" footerFontName="" footerFontStyle="0" footerFontSize="9"
	// margeLeft="0" margeTop="0" margeRight="0" margeBottom="0" />
	{
		NppXml::Element GUIConfigElement = NppXml::createChildElement(newGUIRoot, "GUIConfig");
		NppXml::setAttribute(GUIConfigElement, "name", "Print");
		writePrintSetting(GUIConfigElement);
	}

	// <GUIConfig name="Backup" action="0" useCustumDir="no" dir="" isSnapshotMode="yes" snapshotBackupTiming="7000" />
	{
		NppXml::Element GUIConfigElement = NppXml::createChildElement(newGUIRoot, "GUIConfig");
		NppXml::setAttribute(GUIConfigElement, "name", "Backup");
		NppXml::setAttribute(GUIConfigElement, "action", _nppGUI._backup);
		setBoolAttribute(GUIConfigElement, "useCustumDir", _nppGUI._useDir);
		NppXml::setAttribute(GUIConfigElement, "dir", wstring2string(_nppGUI._backupDir));

		setBoolAttribute(GUIConfigElement, "isSnapshotMode", _nppGUI._isSnapshotMode);
		NppXml::setAttribute(GUIConfigElement, "snapshotBackupTiming", _nppGUI._snapshotBackupTiming);
	}

	// <GUIConfig name="TaskList">yes</GUIConfig>
	{
		insertGUIConfigBoolNode(newGUIRoot, "TaskList", _nppGUI._doTaskList);
	}

	// <GUIConfig name="MRU">yes</GUIConfig>
	{
		insertGUIConfigBoolNode(newGUIRoot, "MRU", _nppGUI._styleMRU);
	}

	// <GUIConfig name="URL">2</GUIConfig>
	{
		NppXml::Element GUIConfigElement = NppXml::createChildElement(newGUIRoot, "GUIConfig");
		NppXml::setAttribute(GUIConfigElement, "name", "URL");
		NppXml::createChildText(GUIConfigElement, std::to_string(_nppGUI._styleURL));
	}

	// <GUIConfig name="uriCustomizedSchemes">svn:// cvs:// git:// imap:// irc:// irc6:// ircs:// ldap:// ldaps:// news: telnet://
	// gopher:// ssh:// sftp:// smb:// skype: snmp:// spotify: steam:// sms: slack:// chrome:// bitcoin:</GUIConfig>
	{
		NppXml::Element GUIConfigElement = NppXml::createChildElement(newGUIRoot, "GUIConfig");
		NppXml::setAttribute(GUIConfigElement, "name", "uriCustomizedSchemes");
		NppXml::createChildText(GUIConfigElement, wstring2string(_nppGUI._uriSchemes));
	}

	// <GUIConfig name="globalOverride" fg="no" bg="no" font="no" fontSize="no" bold="no" italic="no" underline="no" />
	{
		NppXml::Element GUIConfigElement = NppXml::createChildElement(newGUIRoot, "GUIConfig");
		NppXml::setAttribute(GUIConfigElement, "name", "globalOverride");
		setBoolAttribute(GUIConfigElement, "fg", _nppGUI._globalOverride.enableFg);
		setBoolAttribute(GUIConfigElement, "bg", _nppGUI._globalOverride.enableBg);
		setBoolAttribute(GUIConfigElement, "font", _nppGUI._globalOverride.enableFont);
		setBoolAttribute(GUIConfigElement, "fontSize", _nppGUI._globalOverride.enableFontSize);
		setBoolAttribute(GUIConfigElement, "bold", _nppGUI._globalOverride.enableBold);
		setBoolAttribute(GUIConfigElement, "italic", _nppGUI._globalOverride.enableItalic);
		setBoolAttribute(GUIConfigElement, "underline", _nppGUI._globalOverride.enableUnderLine);
	}

	// <GUIConfig name="auto-completion" autoCAction="3" triggerFromNbChar="1" autoCIgnoreNumbers="yes" insertSelectedItemUseENTER="yes"
	// insertSelectedItemUseTAB="yes" autoCBrief="no" funcParams="yes" />
	{
		NppXml::Element GUIConfigElement = NppXml::createChildElement(newGUIRoot, "GUIConfig");
		NppXml::setAttribute(GUIConfigElement, "name", "auto-completion");
		NppXml::setAttribute(GUIConfigElement, "autoCAction", _nppGUI._autocStatus);
		NppXml::setAttribute(GUIConfigElement, "triggerFromNbChar", _nppGUI._autocFromLen);

		setBoolAttribute(GUIConfigElement, "autoCIgnoreNumbers", _nppGUI._autocIgnoreNumbers);
		setBoolAttribute(GUIConfigElement, "insertSelectedItemUseENTER", _nppGUI._autocInsertSelectedUseENTER);
		setBoolAttribute(GUIConfigElement, "insertSelectedItemUseTAB", _nppGUI._autocInsertSelectedUseTAB);
		setBoolAttribute(GUIConfigElement, "autoCBrief", _nppGUI._autocBrief);
		setBoolAttribute(GUIConfigElement, "funcParams", _nppGUI._funcParams);
	}

	// <GUIConfig name="auto-insert" parentheses="no" brackets="no" curlyBrackets="no" quotes="no" doubleQuotes="no" htmlXmlTag="no" />
	{
		NppXml::Element GUIConfigElement = NppXml::createChildElement(newGUIRoot, "GUIConfig");
		NppXml::setAttribute(GUIConfigElement, "name", "auto-insert");

		setBoolAttribute(GUIConfigElement, "parentheses", _nppGUI._matchedPairConf._doParentheses);
		setBoolAttribute(GUIConfigElement, "brackets", _nppGUI._matchedPairConf._doBrackets);
		setBoolAttribute(GUIConfigElement, "curlyBrackets", _nppGUI._matchedPairConf._doCurlyBrackets);
		setBoolAttribute(GUIConfigElement, "quotes", _nppGUI._matchedPairConf._doQuotes);
		setBoolAttribute(GUIConfigElement, "doubleQuotes", _nppGUI._matchedPairConf._doDoubleQuotes);
		setBoolAttribute(GUIConfigElement, "htmlXmlTag", _nppGUI._matchedPairConf._doHtmlXmlTag);

		for (auto const& pair : _nppGUI._matchedPairConf._matchedPairs)
		{
			NppXml::Element hist_element = NppXml::createChildElement(GUIConfigElement, "UserDefinePair");

			NppXml::setAttribute(hist_element, "open", pair.first);
			NppXml::setAttribute(hist_element, "close", pair.second);
		}
	}

	// <GUIConfig name="sessionExt"></GUIConfig>
	{
		NppXml::Element GUIConfigElement = NppXml::createChildElement(newGUIRoot, "GUIConfig");
		NppXml::setAttribute(GUIConfigElement, "name", "sessionExt");
		NppXml::createChildText(GUIConfigElement, wstring2string(_nppGUI._definedSessionExt));
	}

	// <GUIConfig name="workspaceExt"></GUIConfig>
	{
		NppXml::Element GUIConfigElement = NppXml::createChildElement(newGUIRoot, "GUIConfig");
		NppXml::setAttribute(GUIConfigElement, "name", "workspaceExt");
		NppXml::createChildText(GUIConfigElement, wstring2string(_nppGUI._definedWorkspaceExt));
	}

	// <GUIConfig name="MenuBar">show</GUIConfig>
	{
		NppXml::Element GUIConfigElement = NppXml::createChildElement(newGUIRoot, "GUIConfig");
		NppXml::setAttribute(GUIConfigElement, "name", "MenuBar");
		NppXml::createChildText(GUIConfigElement, _nppGUI._menuBarShow ? "show" : "hide");
	}

	// <GUIConfig name="DialogFont" size="8"/>
	{
		NppXml::Element GUIConfigElement = NppXml::createChildElement(newGUIRoot, "GUIConfig");
		NppXml::setAttribute(GUIConfigElement, "name", "DialogFont");
		NppXml::setAttribute(GUIConfigElement, "size", _nppGUI._fontDlgSize);
	}

	// <GUIConfig name="Caret" width="1" blinkRate="600" />
	{
		NppXml::Element GUIConfigElement = NppXml::createChildElement(newGUIRoot, "GUIConfig");
		NppXml::setAttribute(GUIConfigElement, "name", "Caret");
		NppXml::setAttribute(GUIConfigElement, "width", _nppGUI._caretWidth);
		NppXml::setAttribute(GUIConfigElement, "blinkRate", _nppGUI._caretBlinkRate);
	}

	// <GUIConfig name="openSaveDir" value="0" defaultDirPath="" lastUsedDirPath="" />
	{
		NppXml::Element GUIConfigElement = NppXml::createChildElement(newGUIRoot, "GUIConfig");
		NppXml::setAttribute(GUIConfigElement, "name", "openSaveDir");
		NppXml::setAttribute(GUIConfigElement, "value", _nppGUI._openSaveDir);
		NppXml::setAttribute(GUIConfigElement, "defaultDirPath", wstring2string(_nppGUI._defaultDir));
		NppXml::setAttribute(GUIConfigElement, "lastUsedDirPath", wstring2string(_nppGUI._lastUsedDir));
	}

	// <GUIConfig name="titleBar" short="no" />
	{
		NppXml::Element GUIConfigElement = NppXml::createChildElement(newGUIRoot, "GUIConfig");
		NppXml::setAttribute(GUIConfigElement, "name", "titleBar");
		setBoolAttribute(GUIConfigElement, "short", _nppGUI._shortTitlebar);
	}

	// <GUIConfig name="insertDateTime" customizedFormat="yyyy-MM-dd HH:mm:ss" reverseDefaultOrder="no" />
	{
		NppXml::Element GUIConfigElement = NppXml::createChildElement(newGUIRoot, "GUIConfig");
		NppXml::setAttribute(GUIConfigElement, "name", "insertDateTime");
		NppXml::setAttribute(GUIConfigElement, "customizedFormat", wstring2string(_nppGUI._dateTimeFormat));
		setBoolAttribute(GUIConfigElement, "reverseDefaultOrder", _nppGUI._dateTimeReverseDefaultOrder);
	}

	// <GUIConfig name="wordCharList" useDefault="yes" charsAdded="" />
	{
		NppXml::Element GUIConfigElement = NppXml::createChildElement(newGUIRoot, "GUIConfig");
		NppXml::setAttribute(GUIConfigElement, "name", "wordCharList");
		setBoolAttribute(GUIConfigElement, "useDefault", _nppGUI._isWordCharDefault);
		NppXml::setAttribute(GUIConfigElement, "charsAdded", _nppGUI._customWordChars);
	}

	// <GUIConfig name="delimiterSelection" leftmostDelimiter="40" rightmostDelimiter="41" delimiterSelectionOnEntireDocument="no" />
	{
		NppXml::Element GUIConfigElement = NppXml::createChildElement(newGUIRoot, "GUIConfig");
		NppXml::setAttribute(GUIConfigElement, "name", "delimiterSelection");
		NppXml::setAttribute(GUIConfigElement, "leftmostDelimiter", _nppGUI._leftmostDelimiter);
		NppXml::setAttribute(GUIConfigElement, "rightmostDelimiter", _nppGUI._rightmostDelimiter);
		setBoolAttribute(GUIConfigElement, "delimiterSelectionOnEntireDocument", _nppGUI._delimiterSelectionOnEntireDocument);
	}

	// <GUIConfig name="largeFileRestriction" fileSizeMB="200" isEnabled="yes" allowAutoCompletion="no" allowBraceMatch="no" allowSmartHilite="no"
	// allowClickableLink="no" deactivateWordWrap="yes" suppress2GBWarning="no" />
	{
		NppXml::Element GUIConfigElement = NppXml::createChildElement(newGUIRoot, "GUIConfig");
		NppXml::setAttribute(GUIConfigElement, "name", "largeFileRestriction");
		NppXml::setAttribute(GUIConfigElement, "fileSizeMB", (_nppGUI._largeFileRestriction._largeFileSizeDefInByte / 1024) / 1024);
		setBoolAttribute(GUIConfigElement, "isEnabled", _nppGUI._largeFileRestriction._isEnabled);
		setBoolAttribute(GUIConfigElement, "allowAutoCompletion", _nppGUI._largeFileRestriction._allowAutoCompletion);
		setBoolAttribute(GUIConfigElement, "allowBraceMatch", _nppGUI._largeFileRestriction._allowBraceMatch);
		setBoolAttribute(GUIConfigElement, "allowSmartHilite", _nppGUI._largeFileRestriction._allowSmartHilite);
		setBoolAttribute(GUIConfigElement, "allowClickableLink", _nppGUI._largeFileRestriction._allowClickableLink);
		setBoolAttribute(GUIConfigElement, "deactivateWordWrap", _nppGUI._largeFileRestriction._deactivateWordWrap);
		setBoolAttribute(GUIConfigElement, "suppress2GBWarning", _nppGUI._largeFileRestriction._suppress2GBWarning);
	}

	// <GUIConfig name="multiInst" setting="0" clipboardHistory="no" documentList="no" characterPanel="no" folderAsWorkspace="no" projectPanels="no"
	// documentMap="no" fuctionList="no" pluginPanels="no" />
	{
		NppXml::Element GUIConfigElement = NppXml::createChildElement(newGUIRoot, "GUIConfig");
		NppXml::setAttribute(GUIConfigElement, "name", "multiInst");
		NppXml::setAttribute(GUIConfigElement, "setting", _nppGUI._multiInstSetting);

		setBoolAttribute(GUIConfigElement, "clipboardHistory", _nppGUI._clipboardHistoryPanelKeepState);
		setBoolAttribute(GUIConfigElement, "documentList", _nppGUI._docListKeepState);
		setBoolAttribute(GUIConfigElement, "characterPanel", _nppGUI._charPanelKeepState);
		setBoolAttribute(GUIConfigElement, "folderAsWorkspace", _nppGUI._fileBrowserKeepState);
		setBoolAttribute(GUIConfigElement, "projectPanels", _nppGUI._projectPanelKeepState);
		setBoolAttribute(GUIConfigElement, "documentMap", _nppGUI._docMapKeepState);
		setBoolAttribute(GUIConfigElement, "fuctionList", _nppGUI._funcListKeepState);
		setBoolAttribute(GUIConfigElement, "pluginPanels", _nppGUI._pluginPanelKeepState);
	}

	// <GUIConfig name="MISC" fileSwitcherWithoutExtColumn="no" fileSwitcherExtWidth="50" fileSwitcherWithoutPathColumn="no" fileSwitcherPathWidth="50"
	// fileSwitcherNoGroups="no" backSlashIsEscapeCharacterForSql="yes" writeTechnologyEngine="1" isFolderDroppedOpenFiles="no" docPeekOnTab="no"
	// docPeekOnMap="no" sortFunctionList="no" saveDlgExtFilterToAllTypes="no" muteSounds="no" enableFoldCmdToggable="no" hideMenuRightShortcuts="no" />
	{
		NppXml::Element GUIConfigElement = NppXml::createChildElement(newGUIRoot, "GUIConfig");
		NppXml::setAttribute(GUIConfigElement, "name", "MISC");

		setBoolAttribute(GUIConfigElement, "fileSwitcherWithoutExtColumn", _nppGUI._fileSwitcherWithoutExtColumn);
		NppXml::setAttribute(GUIConfigElement, "fileSwitcherExtWidth", _nppGUI._fileSwitcherExtWidth);
		setBoolAttribute(GUIConfigElement, "fileSwitcherWithoutPathColumn", _nppGUI._fileSwitcherWithoutPathColumn);
		NppXml::setAttribute(GUIConfigElement, "fileSwitcherPathWidth", _nppGUI._fileSwitcherPathWidth);
		setBoolAttribute(GUIConfigElement, "fileSwitcherNoGroups", _nppGUI._fileSwitcherDisableListViewGroups);
		setBoolAttribute(GUIConfigElement, "backSlashIsEscapeCharacterForSql", _nppGUI._backSlashIsEscapeCharacterForSql);
		NppXml::setAttribute(GUIConfigElement, "writeTechnologyEngine", _nppGUI._writeTechnologyEngine);
		setBoolAttribute(GUIConfigElement, "isFolderDroppedOpenFiles", _nppGUI._isFolderDroppedOpenFiles);
		setBoolAttribute(GUIConfigElement, "docPeekOnTab", _nppGUI._isDocPeekOnTab);
		setBoolAttribute(GUIConfigElement, "docPeekOnMap", _nppGUI._isDocPeekOnMap);
		setBoolAttribute(GUIConfigElement, "sortFunctionList", _nppGUI._shouldSortFunctionList);
		setBoolAttribute(GUIConfigElement, "saveDlgExtFilterToAllTypes", _nppGUI._setSaveDlgExtFiltToAllTypes);
		setBoolAttribute(GUIConfigElement, "muteSounds", _nppGUI._muteSounds);
		setBoolAttribute(GUIConfigElement, "enableFoldCmdToggable", _nppGUI._enableFoldCmdToggable);
		setBoolAttribute(GUIConfigElement, "hideMenuRightShortcuts", _nppGUI._hideMenuRightShortcuts);
		setBoolAttribute(GUIConfigElement, "isFawSymlinkAllowed", _nppGUI._isFawSymlinkAllowed);
	}

	// <GUIConfig name="Searching" monospacedFontFindDlg="no" fillFindFieldWithSelected="yes" fillFindFieldSelectCaret="yes"
	// findDlgAlwaysVisible="no" confirmReplaceInAllOpenDocs="yes" replaceStopsWithoutFindingNext="no" inSelectionAutocheckThreshold="1024"
	// fillFindWhatThreshold="1024" fillDirFieldFromActiveDoc="no" />
	{
		NppXml::Element GUIConfigElement = NppXml::createChildElement(newGUIRoot, "GUIConfig");
		NppXml::setAttribute(GUIConfigElement, "name", "Searching");

		setBoolAttribute(GUIConfigElement, "monospacedFontFindDlg", _nppGUI._monospacedFontFindDlg);
		setBoolAttribute(GUIConfigElement, "fillFindFieldWithSelected", _nppGUI._fillFindFieldWithSelected);
		setBoolAttribute(GUIConfigElement, "fillFindFieldSelectCaret", _nppGUI._fillFindFieldSelectCaret);
		setBoolAttribute(GUIConfigElement, "findDlgAlwaysVisible", _nppGUI._findDlgAlwaysVisible);
		setBoolAttribute(GUIConfigElement, "confirmReplaceInAllOpenDocs", _nppGUI._confirmReplaceInAllOpenDocs);
		setBoolAttribute(GUIConfigElement, "replaceStopsWithoutFindingNext", _nppGUI._replaceStopsWithoutFindingNext);
		NppXml::setAttribute(GUIConfigElement, "inSelectionAutocheckThreshold", _nppGUI._inSelectionAutocheckThreshold);
		NppXml::setAttribute(GUIConfigElement, "fillFindWhatThreshold", _nppGUI._fillFindWhatThreshold);
		setBoolAttribute(GUIConfigElement, "fillDirFieldFromActiveDoc", _nppGUI._fillDirFieldFromActiveDoc);
	}

	// <GUIConfig name="searchEngine" searchEngineChoice="2" searchEngineCustom="" />
	{
		NppXml::Element GUIConfigElement = NppXml::createChildElement(newGUIRoot, "GUIConfig");
		NppXml::setAttribute(GUIConfigElement, "name", "searchEngine");
		NppXml::setAttribute(GUIConfigElement, "searchEngineChoice", _nppGUI._searchEngineChoice);
		NppXml::setAttribute(GUIConfigElement, "searchEngineCustom", wstring2string(_nppGUI._searchEngineCustom));
	}

	{
		if (!_nppGUI._shortcutsXmlHmacInConfig.empty())
		{
			NppXml::Element GUIConfigElement = NppXml::createChildElement(newGUIRoot, "GUIConfig");
			NppXml::setAttribute(GUIConfigElement, "name", "shortcutsXmlHMAC");
			NppXml::setAttribute(GUIConfigElement, "value", _nppGUI._shortcutsXmlHmacInConfig);
		}
	}

	// <GUIConfig name="MarkAll" matchCase="no" wholeWordOnly="yes" />
	{
		NppXml::Element GUIConfigElement = NppXml::createChildElement(newGUIRoot, "GUIConfig");
		NppXml::setAttribute(GUIConfigElement, "name", "MarkAll");
		setBoolAttribute(GUIConfigElement, "matchCase", _nppGUI._markAllCaseSensitive);
		setBoolAttribute(GUIConfigElement, "wholeWordOnly", _nppGUI._markAllWordOnly);
	}

	// <GUIConfig name="SmartHighLight" matchCase="no" wholeWordOnly="yes" useFindSettings="no" onAnotherView="no">yes</GUIConfig>
	{
		NppXml::Element GUIConfigElement = insertGUIConfigBoolNode(newGUIRoot, "SmartHighLight", _nppGUI._enableSmartHilite);
		setBoolAttribute(GUIConfigElement, "matchCase", _nppGUI._smartHiliteCaseSensitive);
		setBoolAttribute(GUIConfigElement, "wholeWordOnly", _nppGUI._smartHiliteWordOnly);
		setBoolAttribute(GUIConfigElement, "useFindSettings", _nppGUI._smartHiliteUseFindSettings);
		setBoolAttribute(GUIConfigElement, "onAnotherView", _nppGUI._smartHiliteOnAnotherView);
	}

	// <GUIConfig name="DarkMode" enable="no" colorTone="0" customColorTop="2105376" customColorMenuHotTrack="4539717" customColorActive="3684408"
	// customColorMain="2105376" customColorError="176" customColorText="14737632" customColorDarkText="12632256" customColorDisabledText="8421504"
	// customColorLinkText="65535" customColorEdge="6579300" customColorHotEdge="10197915" customColorDisabledEdge="4737096" enableWindowsMode="no"
	// darkThemeName="DarkModeDefault.xml" darkToolBarIconSet="0" darkTbFluentColor="0" darkTbFluentCustomColor="0" darkTbFluentMono="no" darkTabIconSet="2"
	// darkTabUseTheme="no" lightThemeName="" lightToolBarIconSet="4" lightTbFluentColor="0" lightTbFluentCustomColor="33024" lightTbFluentMono="no"
	// lightTabIconSet="0" lightTabUseTheme="yes" />
	{
		NppXml::Element GUIConfigElement = NppXml::createChildElement(newGUIRoot, "GUIConfig");
		NppXml::setAttribute(GUIConfigElement, "name", "DarkMode");

		NppDarkMode::setAdvancedOptions();

		setBoolAttribute(GUIConfigElement, "enable", _nppGUI._darkmode._isEnabled);
		NppXml::setAttribute(GUIConfigElement, "colorTone", _nppGUI._darkmode._colorTone);

		NppXml::setAttribute(GUIConfigElement, "customColorTop", _nppGUI._darkmode._customColors.pureBackground);
		NppXml::setAttribute(GUIConfigElement, "customColorMenuHotTrack", _nppGUI._darkmode._customColors.hotBackground);
		NppXml::setAttribute(GUIConfigElement, "customColorActive", _nppGUI._darkmode._customColors.softerBackground);
		NppXml::setAttribute(GUIConfigElement, "customColorMain", _nppGUI._darkmode._customColors.background);
		NppXml::setAttribute(GUIConfigElement, "customColorError", _nppGUI._darkmode._customColors.errorBackground);
		NppXml::setAttribute(GUIConfigElement, "customColorText", _nppGUI._darkmode._customColors.text);
		NppXml::setAttribute(GUIConfigElement, "customColorDarkText", _nppGUI._darkmode._customColors.darkerText);
		NppXml::setAttribute(GUIConfigElement, "customColorDisabledText", _nppGUI._darkmode._customColors.disabledText);
		NppXml::setAttribute(GUIConfigElement, "customColorLinkText", _nppGUI._darkmode._customColors.linkText);
		NppXml::setAttribute(GUIConfigElement, "customColorEdge", _nppGUI._darkmode._customColors.edge);
		NppXml::setAttribute(GUIConfigElement, "customColorHotEdge", _nppGUI._darkmode._customColors.hotEdge);
		NppXml::setAttribute(GUIConfigElement, "customColorDisabledEdge", _nppGUI._darkmode._customColors.disabledEdge);

		// advanced options section
		const auto& advOpt = _nppGUI._darkmode._advOptions;
		setBoolAttribute(GUIConfigElement, "enableWindowsMode", advOpt._enableWindowsMode);

		const auto& darkDefaults = advOpt._darkDefaults;
		const auto& darkThemeName = darkDefaults._xmlFileName;
		const auto& darkTbInfo = darkDefaults._tbIconInfo;
		NppXml::setAttribute(GUIConfigElement, "darkThemeName", wstring2string(darkThemeName));
		NppXml::setAttribute(GUIConfigElement, "darkToolBarIconSet", darkTbInfo._tbIconSet);
		NppXml::setAttribute(GUIConfigElement, "darkTbFluentColor", static_cast<int>(darkTbInfo._tbColor));
		NppXml::setAttribute(GUIConfigElement, "darkTbFluentCustomColor", darkTbInfo._tbCustomColor);
		setBoolAttribute(GUIConfigElement, "darkTbFluentMono", darkTbInfo._tbUseMono);
		NppXml::setAttribute(GUIConfigElement, "darkTabIconSet", darkDefaults._tabIconSet);
		setBoolAttribute(GUIConfigElement, "darkTabUseTheme", darkDefaults._tabUseTheme);

		const auto& lightDefaults = advOpt._lightDefaults;
		const auto& lightThemeName = lightDefaults._xmlFileName;
		const auto& lightTbInfo = lightDefaults._tbIconInfo;
		NppXml::setAttribute(GUIConfigElement, "lightThemeName", wstring2string(lightThemeName));
		NppXml::setAttribute(GUIConfigElement, "lightToolBarIconSet", lightTbInfo._tbIconSet);
		NppXml::setAttribute(GUIConfigElement, "lightTbFluentColor", static_cast<int>(lightTbInfo._tbColor));
		NppXml::setAttribute(GUIConfigElement, "lightTbFluentCustomColor", lightTbInfo._tbCustomColor);
		setBoolAttribute(GUIConfigElement, "lightTbFluentMono", lightTbInfo._tbUseMono);
		NppXml::setAttribute(GUIConfigElement, "lightTabIconSet", lightDefaults._tabIconSet);
		setBoolAttribute(GUIConfigElement, "lightTabUseTheme", lightDefaults._tabUseTheme);
	}

	// <GUIConfig name="ColorPickerCustomColors" color0="..." ... color15="..." />
	{
		NppXml::Element GUIConfigElement = NppXml::createChildElement(newGUIRoot, "GUIConfig");
		NppXml::setAttribute(GUIConfigElement, "name", "ColorPickerCustomColors");

		size_t i = 0;
		for (auto & cc : _nppGUI._colorPickerCustomColors)
		{
			const std::string attrName = "color" + std::to_string(i++);
			NppXml::setAttribute(GUIConfigElement, attrName.c_str(), static_cast<int>(cc));
		}
	}

	// <GUIConfig name="ScintillaPrimaryView" lineNumberMargin="show" lineNumberDynamicWidth="yes" bookMarkMargin="show" indentGuideLine="show"
	// folderMarkStyle="box" isChangeHistoryEnabled="1" lineWrapMethod="aligned" currentLineIndicator="1" currentLineFrameWidth="1"
	// virtualSpace="no" scrollBeyondLastLine="yes" rightClickKeepsSelection="no" selectedTextForegroundSingleColor="no" disableAdvancedScrolling="no"
	// wrapSymbolShow="hide" Wrap="no" borderEdge="yes" isEdgeBgMode="no" edgeMultiColumnPos="" zoom="0" zoom2="0" whiteSpaceShow="hide"
	// eolShow="hide" eolMode="1" npcShow="hide" npcMode="1" npcCustomColor="no" npcIncludeCcUniEOL="no" npcNoInputC0="yes" ccShow="yes"
	// borderWidth="2" smoothFont="no" paddingLeft="0" paddingRight="0" distractionFreeDivPart="4" lineCopyCutWithoutSelection="yes"
	// multiSelection="yes" columnSel2MultiEdit="yes" disableSelectedTextDragDrop="no" />
	writeScintillaParams();

	// <GUIConfig name="DockingManager" leftWidth="328" rightWidth="359" topHeight="200" bottomHeight="436">
	// ...
	if (_nppGUI._isCmdlineNosessionActivated && dockMngNodeDup)
	{
		NppXml::insertEndChild(newGUIRoot, dockMngNodeDup);
		delete tempDoc;
	}
	else
	{
		insertDockingParamNode(newGUIRoot);
	}
}

bool NppParameters::writeFindHistory()
{
	if (!_xmlUserDoc._doc) return false;

	NppXml::Element nppRoot = NppXml::firstChildElement(_xmlUserDoc._doc, "NotepadPlus");
	if (!nppRoot)
	{
		nppRoot = NppXml::createChildElement(_xmlUserDoc._doc, "NotepadPlus");
	}

	NppXml::Element findHistoryRoot = NppXml::firstChildElement(nppRoot, "FindHistory");
	if (!findHistoryRoot)
	{
		findHistoryRoot = NppXml::createChildElement(nppRoot, "FindHistory");
	}
	else
	{
		NppXml::clear(findHistoryRoot);
	}

	NppXml::setAttribute(findHistoryRoot, "nbMaxFindHistoryPath", _findHistory._nbMaxFindHistoryPath);
	NppXml::setAttribute(findHistoryRoot, "nbMaxFindHistoryFilter", _findHistory._nbMaxFindHistoryFilter);
	NppXml::setAttribute(findHistoryRoot, "nbMaxFindHistoryFind", _findHistory._nbMaxFindHistoryFind);
	NppXml::setAttribute(findHistoryRoot, "nbMaxFindHistoryReplace", _findHistory._nbMaxFindHistoryReplace);

	setBoolAttribute(findHistoryRoot, "matchWord", _findHistory._isMatchWord);
	setBoolAttribute(findHistoryRoot, "matchCase", _findHistory._isMatchCase);
	setBoolAttribute(findHistoryRoot, "wrap", _findHistory._isWrap);
	setBoolAttribute(findHistoryRoot, "directionDown", _findHistory._isDirectionDown);

	setBoolAttribute(findHistoryRoot, "fifRecuisive", _findHistory._isFifRecursive);
	setBoolAttribute(findHistoryRoot, "fifInHiddenFolder", _findHistory._isFifInHiddenFolder);
	setBoolAttribute(findHistoryRoot, "fifProjectPanel1", _findHistory._isFifProjectPanel_1);
	setBoolAttribute(findHistoryRoot, "fifProjectPanel2", _findHistory._isFifProjectPanel_2);
	setBoolAttribute(findHistoryRoot, "fifProjectPanel3", _findHistory._isFifProjectPanel_3);
	setBoolAttribute(findHistoryRoot, "fifFilterFollowsDoc", _findHistory._isFilterFollowDoc);

	NppXml::setAttribute(findHistoryRoot, "searchMode", _findHistory._searchMode);
	NppXml::setAttribute(findHistoryRoot, "transparencyMode", _findHistory._transparencyMode);
	NppXml::setAttribute(findHistoryRoot, "transparency", _findHistory._transparency);
	setBoolAttribute(findHistoryRoot, "dotMatchesNewline", _findHistory._dotMatchesNewline);
	setBoolAttribute(findHistoryRoot, "isSearch2ButtonsMode", _findHistory._isSearch2ButtonsMode);
	setBoolAttribute(findHistoryRoot, "regexBackward4PowerUser", _findHistory._regexBackward4PowerUser);

	setBoolAttribute(findHistoryRoot, "bookmarkLine", _findHistory._isBookmarkLine);
	setBoolAttribute(findHistoryRoot, "purge", _findHistory._isPurge);

	for (const auto& path : _findHistory._findHistoryPaths)
	{
		NppXml::Element pathElement = NppXml::createChildElement(findHistoryRoot, "Path");
		NppXml::setAttribute(pathElement, "name", wstring2string(path));
	}

	for (const auto& filter : _findHistory._findHistoryFilters)
	{
		NppXml::Element filterElement = NppXml::createChildElement(findHistoryRoot, "Filter");
		NppXml::setAttribute(filterElement, "name", wstring2string(filter));
	}

	for (const auto& find : _findHistory._findHistoryFinds)
	{
		NppXml::Element findElement = NppXml::createChildElement(findHistoryRoot, "Find");
		NppXml::setAttribute(findElement, "name", wstring2string(find));
	}

	for (const auto& replace : _findHistory._findHistoryReplaces)
	{
		NppXml::Element replaceElement = NppXml::createChildElement(findHistoryRoot, "Replace");
		NppXml::setAttribute(replaceElement, "name", wstring2string(replace));
	}

	return true;
}

void NppParameters::insertDockingParamNode(NppXml::Element& GUIRoot) const
{
	NppXml::Element DMNode = NppXml::createChildElement(GUIRoot, "GUIConfig");

	NppXml::setAttribute(DMNode, "name", "DockingManager");
	NppXml::setAttribute(DMNode, "leftWidth", _nppGUI._dockingData._leftWidth);
	NppXml::setAttribute(DMNode, "rightWidth", _nppGUI._dockingData._rightWidth);
	NppXml::setAttribute(DMNode, "topHeight", _nppGUI._dockingData._topHeight);
	NppXml::setAttribute(DMNode, "bottomHeight", _nppGUI._dockingData._bottomHeight);

	for (const auto& fwi : _nppGUI._dockingData._floatingWindowInfo)
	{
		NppXml::Element FWNode = NppXml::createChildElement(DMNode, "FloatingWindow");

		NppXml::setAttribute(FWNode, "cont", fwi._cont);
		NppXml::setAttribute(FWNode, "x", fwi._pos.left);
		NppXml::setAttribute(FWNode, "y", fwi._pos.top);
		NppXml::setAttribute(FWNode, "width", fwi._pos.right);
		NppXml::setAttribute(FWNode, "height", fwi._pos.bottom);
	}

	for (const auto& pdi : _nppGUI._dockingData._pluginDockInfo)
	{
		NppXml::Element PDNode = NppXml::createChildElement(DMNode, "PluginDlg");

		NppXml::setAttribute(PDNode, "pluginName", wstring2string(pdi._name));
		NppXml::setAttribute(PDNode, "id", pdi._internalID);
		NppXml::setAttribute(PDNode, "curr", pdi._currContainer);
		NppXml::setAttribute(PDNode, "prev", pdi._prevContainer);
		setBoolAttribute(PDNode, "isVisible", pdi._isVisible);
	}

	for (const auto& cti : _nppGUI._dockingData._containerTabInfo)
	{
		NppXml::Element CTNode = NppXml::createChildElement(DMNode, "ActiveTabs");

		NppXml::setAttribute(CTNode, "cont", cti._cont);
		NppXml::setAttribute(CTNode, "activeTab", cti._activeTab);
	}
}

void NppParameters::writePrintSetting(NppXml::Element& element) const
{
	const auto& prSet = _nppGUI._printSettings;

	setBoolAttribute(element, "lineNumber", prSet._printLineNumber);
	setBoolAttribute(element, "formFeedPageBreak", prSet._printFormFeedPageBreak);

	NppXml::setAttribute(element, "printOption", prSet._printOption);

	NppXml::setAttribute(element, "headerLeft", wstring2string(prSet._headerLeft));
	NppXml::setAttribute(element, "headerMiddle", wstring2string(prSet._headerMiddle));
	NppXml::setAttribute(element, "headerRight", wstring2string(prSet._headerRight));
	NppXml::setAttribute(element, "footerLeft", wstring2string(prSet._footerLeft));
	NppXml::setAttribute(element, "footerMiddle", wstring2string(prSet._footerMiddle));
	NppXml::setAttribute(element, "footerRight", wstring2string(prSet._footerRight));

	NppXml::setAttribute(element, "headerFontName", wstring2string(prSet._headerFontName));
	NppXml::setAttribute(element, "headerFontStyle", prSet._headerFontStyle);
	NppXml::setAttribute(element, "headerFontSize", prSet._headerFontSize);
	NppXml::setAttribute(element, "footerFontName", wstring2string(prSet._footerFontName));
	NppXml::setAttribute(element, "footerFontStyle", prSet._footerFontStyle);
	NppXml::setAttribute(element, "footerFontSize", prSet._footerFontSize);

	NppXml::setAttribute(element, "margeLeft", prSet._marge.left);
	NppXml::setAttribute(element, "margeRight", prSet._marge.right);
	NppXml::setAttribute(element, "margeTop", prSet._marge.top);
	NppXml::setAttribute(element, "margeBottom", prSet._marge.bottom);
}

void NppParameters::writeExcludedLangList(NppXml::Element& element) const
{
	int g0 = 0; // up to 8
	int g1 = 0; // up to 16
	int g2 = 0; // up to 24
	int g3 = 0; // up to 32
	int g4 = 0; // up to 40
	int g5 = 0; // up to 48
	int g6 = 0; // up to 56
	int g7 = 0; // up to 64
	int g8 = 0; // up to 72
	int g9 = 0; // up to 80
	int g10 = 0; // up to 88
	int g11 = 0; // up to 96
	int g12 = 0; // up to 104

	static constexpr int groupNbMember = 8;

	for (const auto& exclLang : _nppGUI._excludedLangList)
	{
		const LangType langType = exclLang._langType;
		if (langType >= L_EXTERNAL && langType < L_END)
			continue;

		const int nGrp = langType / groupNbMember;
		const int nMask = 1 << langType % groupNbMember;

		switch (nGrp)
		{
			case 0:
				g0 |= nMask;
				break;
			case 1:
				g1 |= nMask;
				break;
			case 2:
				g2 |= nMask;
				break;
			case 3:
				g3 |= nMask;
				break;
			case 4:
				g4 |= nMask;
				break;
			case 5:
				g5 |= nMask;
				break;
			case 6:
				g6 |= nMask;
				break;
			case 7:
				g7 |= nMask;
				break;
			case 8:
				g8 |= nMask;
				break;
			case 9:
				g9 |= nMask;
				break;
			case 10:
				g10 |= nMask;
				break;
			case 11:
				g11 |= nMask;
				break;
			case 12:
				g12 |= nMask;
				break;
		}
	}

	NppXml::setAttribute(element, "gr0", g0);
	NppXml::setAttribute(element, "gr1", g1);
	NppXml::setAttribute(element, "gr2", g2);
	NppXml::setAttribute(element, "gr3", g3);
	NppXml::setAttribute(element, "gr4", g4);
	NppXml::setAttribute(element, "gr5", g5);
	NppXml::setAttribute(element, "gr6", g6);
	NppXml::setAttribute(element, "gr7", g7);
	NppXml::setAttribute(element, "gr8", g8);
	NppXml::setAttribute(element, "gr9", g9);
	NppXml::setAttribute(element, "gr10", g10);
	NppXml::setAttribute(element, "gr11", g11);
	NppXml::setAttribute(element, "gr12", g12);
}

NppXml::Element NppParameters::insertGUIConfigBoolNode(NppXml::Element& r2w, const char* name, bool bVal)
{
	NppXml::Element GUIConfigElement = NppXml::createChildElement(r2w, "GUIConfig");
	NppXml::setAttribute(GUIConfigElement, "name", name);
	NppXml::createChildText(GUIConfigElement, bVal ? "yes" : "no");
	return GUIConfigElement;
}

int NppParameters::langTypeToCommandID(LangType lt) const
{
	int id;
	switch (lt)
	{
		case L_C :
			id = IDM_LANG_C; break;
		case L_CPP :
			id = IDM_LANG_CPP; break;
		case L_JAVA :
			id = IDM_LANG_JAVA;	break;
		case L_CS :
			id = IDM_LANG_CS; break;
		case L_OBJC :
			id = IDM_LANG_OBJC;	break;
		case L_HTML :
			id = IDM_LANG_HTML;	break;
		case L_XML :
			id = IDM_LANG_XML; break;
		case L_JS_EMBEDDED :
		case L_JAVASCRIPT:
			id = IDM_LANG_JS; break;
		case L_JSON:
			id = IDM_LANG_JSON; break;
		case L_JSON5:
			id = IDM_LANG_JSON5; break;
		case L_PHP :
			id = IDM_LANG_PHP; break;
		case L_ASP :
			id = IDM_LANG_ASP; break;
		case L_JSP :
			id = IDM_LANG_JSP; break;
		case L_CSS :
			id = IDM_LANG_CSS; break;
		case L_LUA :
			id = IDM_LANG_LUA; break;
		case L_PERL :
			id = IDM_LANG_PERL; break;
		case L_PYTHON :
			id = IDM_LANG_PYTHON; break;
		case L_BATCH :
			id = IDM_LANG_BATCH; break;
		case L_PASCAL :
			id = IDM_LANG_PASCAL; break;
		case L_MAKEFILE :
			id = IDM_LANG_MAKEFILE;	break;
		case L_INI :
			id = IDM_LANG_INI; break;
		case L_ASCII :
			id = IDM_LANG_ASCII; break;
		case L_RC :
			id = IDM_LANG_RC; break;
		case L_TEX :
			id = IDM_LANG_TEX; break;
		case L_FORTRAN :
			id = IDM_LANG_FORTRAN; break;
		case L_FORTRAN_77 :
			id = IDM_LANG_FORTRAN_77; break;
		case L_BASH :
			id = IDM_LANG_BASH; break;
		case L_FLASH :
			id = IDM_LANG_FLASH; break;
		case L_NSIS :
			id = IDM_LANG_NSIS; break;
		case L_USER :
			id = IDM_LANG_USER; break;
		case L_SQL :
			id = IDM_LANG_SQL; break;
		case L_MSSQL :
			id = IDM_LANG_MSSQL; break;
		case L_VB :
			id = IDM_LANG_VB; break;
		case L_TCL :
			id = IDM_LANG_TCL; break;

		case L_LISP :
			id = IDM_LANG_LISP; break;
		case L_SCHEME :
			id = IDM_LANG_SCHEME; break;
		case L_ASM :
			id = IDM_LANG_ASM; break;
		case L_DIFF :
			id = IDM_LANG_DIFF; break;
		case L_PROPS :
			id = IDM_LANG_PROPS; break;
		case L_PS :
			id = IDM_LANG_PS; break;
		case L_RUBY :
			id = IDM_LANG_RUBY; break;
		case L_SMALLTALK :
			id = IDM_LANG_SMALLTALK; break;
		case L_VHDL :
			id = IDM_LANG_VHDL; break;

		case L_ADA :
			id = IDM_LANG_ADA; break;
		case L_MATLAB :
			id = IDM_LANG_MATLAB; break;

		case L_HASKELL :
			id = IDM_LANG_HASKELL; break;

		case L_KIX :
			id = IDM_LANG_KIX; break;
		case L_AU3 :
			id = IDM_LANG_AU3; break;
		case L_VERILOG :
			id = IDM_LANG_VERILOG; break;
		case L_CAML :
			id = IDM_LANG_CAML; break;

		case L_INNO :
			id = IDM_LANG_INNO; break;

		case L_CMAKE :
			id = IDM_LANG_CMAKE; break;

		case L_YAML :
			id = IDM_LANG_YAML; break;

		case L_COBOL :
			id = IDM_LANG_COBOL; break;

		case L_D :
			id = IDM_LANG_D; break;

		case L_GUI4CLI :
			id = IDM_LANG_GUI4CLI; break;

		case L_POWERSHELL :
			id = IDM_LANG_POWERSHELL; break;

		case L_R :
			id = IDM_LANG_R; break;

		case L_COFFEESCRIPT :
			id = IDM_LANG_COFFEESCRIPT; break;

		case L_BAANC:
			id = IDM_LANG_BAANC; break;

		case L_SREC :
			id = IDM_LANG_SREC; break;

		case L_IHEX :
			id = IDM_LANG_IHEX; break;

		case L_TEHEX :
			id = IDM_LANG_TEHEX; break;

		case L_SWIFT:
			id = IDM_LANG_SWIFT; break;

		case L_ASN1 :
			id = IDM_LANG_ASN1; break;

        case L_AVS :
			id = IDM_LANG_AVS; break;

		case L_BLITZBASIC :
			id = IDM_LANG_BLITZBASIC; break;

		case L_PUREBASIC :
			id = IDM_LANG_PUREBASIC; break;

		case L_FREEBASIC :
			id = IDM_LANG_FREEBASIC; break;

		case L_CSOUND :
			id = IDM_LANG_CSOUND; break;

		case L_ERLANG :
			id = IDM_LANG_ERLANG; break;

		case L_ESCRIPT :
			id = IDM_LANG_ESCRIPT; break;

		case L_FORTH :
			id = IDM_LANG_FORTH; break;

		case L_LATEX :
			id = IDM_LANG_LATEX; break;

		case L_MMIXAL :
			id = IDM_LANG_MMIXAL; break;

		case L_NIM :
			id = IDM_LANG_NIM; break;

		case L_NNCRONTAB :
			id = IDM_LANG_NNCRONTAB; break;

		case L_OSCRIPT :
			id = IDM_LANG_OSCRIPT; break;

		case L_REBOL :
			id = IDM_LANG_REBOL; break;

		case L_REGISTRY :
			id = IDM_LANG_REGISTRY; break;

		case L_RUST :
			id = IDM_LANG_RUST; break;

		case L_SPICE :
			id = IDM_LANG_SPICE; break;

		case L_TXT2TAGS :
			id = IDM_LANG_TXT2TAGS; break;

		case L_VISUALPROLOG:
			id = IDM_LANG_VISUALPROLOG; break;

		case L_TYPESCRIPT:
			id = IDM_LANG_TYPESCRIPT; break;

		case L_GDSCRIPT:
			id = IDM_LANG_GDSCRIPT; break;

		case L_HOLLYWOOD:
			id = IDM_LANG_HOLLYWOOD; break;

		case L_GOLANG:
			id = IDM_LANG_GOLANG; break;

		case L_RAKU:
			id = IDM_LANG_RAKU; break;

		case L_TOML:
			id = IDM_LANG_TOML; break;

		case L_SAS:
			id = IDM_LANG_SAS; break;

		case L_ERRORLIST:
			id = IDM_LANG_ERRORLIST; break;

		case L_ESCSEQ:
			id = IDM_LANG_ESCSEQ; break;

		case L_STTXT:
			id = IDM_LANG_STTXT; break;

		case L_SEARCHRESULT :
			id = -1;	break;

		case L_TEXT :
			id = IDM_LANG_TEXT;	break;


		default :
			if (lt >= L_EXTERNAL && lt < L_END)
				id = lt - L_EXTERNAL + IDM_LANG_EXTERNAL;
			else
				id = IDM_LANG_TEXT;
	}
	return id;
}

std::wstring NppParameters:: getWinVersionStr() const
{
	switch (_winVersion)
	{
		case WV_WIN32S: return L"Windows 3.1";
		case WV_95: return L"Windows 95";
		case WV_98: return L"Windows 98";
		case WV_ME: return L"Windows Millennium Edition";
		case WV_NT: return L"Windows NT";
		case WV_W2K: return L"Windows 2000";
		case WV_XP: return L"Windows XP";
		case WV_S2003: return L"Windows Server 2003";
		case WV_XPX64: return L"Windows XP 64 bits";
		case WV_VISTA: return L"Windows Vista";
		case WV_WIN7: return L"Windows 7";
		case WV_WIN8: return L"Windows 8";
		case WV_WIN81: return L"Windows 8.1";
		case WV_WIN10: return L"Windows 10";
		case WV_WIN11: return L"Windows 11";
		default: /*case WV_UNKNOWN:*/ return L"Windows unknown version";
	}
}

std::wstring NppParameters::getWinVerBitStr() const
{
	switch (_platForm)
	{
	case PF_X86:
		return L"32-bit";

	case PF_X64:
	case PF_IA64:
	case PF_ARM64:
		return L"64-bit";

	default:
		return L"Unknown-bit";
	}
}

std::wstring NppParameters::writeStyles(LexerStylerArray& lexersStylers, StyleArray& globalStylers)
{
	NppXml::Element root = NppXml::firstChildElement(_pXmlUserStylerDoc._doc, "NotepadPlus");
	NppXml::Element lexersRoot = NppXml::firstChildElement(root, "LexerStyles");
	for (NppXml::Element childNode = NppXml::firstChildElement(lexersRoot, "LexerType");
		childNode;
		childNode = NppXml::nextSiblingElement(childNode, "LexerType"))
	{
		const std::wstring nm = string2wstring(NppXml::attribute(childNode, "name", ""));
		if (nm.empty())
			continue;

		LexerStyler* pLs = _lexerStylerVect.getLexerStylerByName(nm.c_str());
		LexerStyler* pLs2 = lexersStylers.getLexerStylerByName(nm.c_str());

		if (pLs)
		{
			NppXml::setAttribute(childNode, "ext", wstring2string(pLs->getLexerUserExt()));

			for (NppXml::Element grChildNode = NppXml::firstChildElement(childNode, "WordsStyle");
				grChildNode;
				grChildNode = NppXml::nextSiblingElement(grChildNode, "WordsStyle"))
			{
				const std::wstring styleName = string2wstring(NppXml::attribute(grChildNode, "name", ""));
				const Style* pStyle = pLs->findByName(styleName);
				Style* pStyle2Sync = pLs2 ? pLs2->findByName(styleName) : nullptr;
				if (pStyle && pStyle2Sync)
				{
					writeStyle2Element(*pStyle, *pStyle2Sync, grChildNode);
				}
			}
		}
	}

	for (auto& extLexDoc : _pXmlExternalLexerDoc)
	{
		NppXml::Element root2 = NppXml::firstChildElement(extLexDoc._doc, "NotepadPlus");
		NppXml::Element lexersRoot2 = NppXml::firstChildElement(root2, "LexerStyles");
		for (NppXml::Element childNode = NppXml::firstChildElement(lexersRoot2, "LexerType");
			childNode;
			childNode = NppXml::nextSiblingElement(childNode, "LexerType"))
		{
			const std::wstring nm = string2wstring(NppXml::attribute(childNode, "name", ""));
			if (nm.empty())
				continue;

			LexerStyler* pLs = _lexerStylerVect.getLexerStylerByName(nm.c_str());
			LexerStyler* pLs2 = lexersStylers.getLexerStylerByName(nm.c_str());

			if (pLs)
			{
				NppXml::setAttribute(childNode, "ext", wstring2string(pLs->getLexerUserExt()));

				for (NppXml::Element grChildNode = NppXml::firstChildElement(childNode, "WordsStyle");
					grChildNode;
					grChildNode = NppXml::nextSiblingElement(grChildNode, "WordsStyle"))
				{
					const std::wstring styleName = string2wstring(NppXml::attribute(grChildNode, "name", ""));
					const Style* pStyle = pLs->findByName(styleName);
					Style* pStyle2Sync = pLs2 ? pLs2->findByName(styleName) : nullptr;
					if (pStyle && pStyle2Sync)
					{
						writeStyle2Element(*pStyle, *pStyle2Sync, grChildNode);
					}
				}
			}
		}
		static_cast<void>(NppXml::saveFile(extLexDoc._doc, extLexDoc._path.c_str()));
	}

	NppXml::Element globalStylesRoot = NppXml::firstChildElement(root, "GlobalStyles");

	for (NppXml::Element childNode = NppXml::firstChildElement(globalStylesRoot, "WidgetStyle");
		childNode;
		childNode = NppXml::nextSiblingElement(childNode, "WidgetStyle"))
	{
		const std::wstring styleName = string2wstring(NppXml::attribute(childNode, "name", ""));
		const Style* pStyle = _widgetStyleArray.findByName(styleName);
		Style* pStyle2Sync = globalStylers.findByName(styleName);
		if (pStyle && pStyle2Sync)
		{
			writeStyle2Element(*pStyle, *pStyle2Sync, childNode);
		}
	}

	const auto savePath = _themeSwitcher.getSavePathFrom(_pXmlUserStylerDoc._path);
	if (!savePath.empty())
	{
		static_cast<void>(NppXml::saveFile(_pXmlUserStylerDoc._doc, savePath.c_str()));
		return savePath;
	}

	static_cast<void>(NppXml::saveFile(_pXmlUserStylerDoc._doc, _pXmlUserStylerDoc._path.c_str()));
	return L"";
}

bool NppParameters::insertTabInfo(const wchar_t* langName, int tabInfo, bool backspaceUnindent)
{
	if (!_pXmlDoc._doc) return false;
	const std::string sLangName = wstring2string(langName);
	NppXml::Element root = NppXml::firstChildElement(_pXmlDoc._doc, "NotepadPlus");
	NppXml::Element langRoot = NppXml::firstChildElement(root, "Languages");
	for (NppXml::Element childNode = NppXml::firstChildElement(langRoot, "Language");
		childNode;
		childNode = NppXml::nextSiblingElement(childNode, "Language"))
	{
		const char* nm = NppXml::attribute(childNode, "name");
		if (nm && std::strcmp(sLangName.c_str(), nm) == 0)
		{
			NppXml::setAttribute(childNode, "tabSettings", tabInfo);
			setBoolAttribute(childNode, "backspaceUnindent", backspaceUnindent);
			return NppXml::saveFile(_pXmlDoc._doc, _pXmlDoc._path.c_str());
		}
	}

	for (auto& extLexDoc : _pXmlExternalLexerDoc)
	{
		NppXml::Element root2 = NppXml::firstChildElement(extLexDoc._doc, "NotepadPlus");
		NppXml::Element langRoot2 = NppXml::firstChildElement(root2, "Languages");
		for (NppXml::Element childNode = NppXml::firstChildElement(langRoot2, "Language");
			childNode;
			childNode = NppXml::nextSiblingElement(childNode, "Language"))
		{
			const char* nm = NppXml::attribute(childNode, "name");
			if (nm && std::strcmp(sLangName.c_str(), nm) == 0)
			{
				NppXml::setAttribute(childNode, "tabSettings", tabInfo);
				setBoolAttribute(childNode, "backspaceUnindent", backspaceUnindent);
				return NppXml::saveFile(extLexDoc._doc, extLexDoc._path.c_str());
			}
		}
	}

	return false;
}

void NppParameters::writeStyle2Element(const Style& style2Write, Style& style2Sync, NppXml::Element& element)
{
	static constexpr size_t bufSize = 7;
	if (HIBYTE(HIWORD(style2Write._fgColor)) != 0xFF)
	{
		const DWORD rgbVal = RGBHEX(style2Write._fgColor);
		char fgStr[bufSize]{};
		std::snprintf(fgStr, bufSize, "%.6lX", rgbVal);
		NppXml::setAttribute(element, "fgColor", fgStr);
	}

	if (HIBYTE(HIWORD(style2Write._bgColor)) != 0xFF)
	{
		const DWORD rgbVal = RGBHEX(style2Write._bgColor);
		char bgStr[bufSize]{};
		std::snprintf(bgStr, bufSize, "%.6lX", rgbVal);
		NppXml::setAttribute(element, "bgColor", bgStr);
	}

	if (style2Write._colorStyle != COLORSTYLE_ALL)
	{
		NppXml::setAttribute(element, "colorStyle", style2Write._colorStyle);
	}

	if (!style2Write._fontName.empty())
	{
		const char* oldFontName = NppXml::attribute(element, "fontName");
		const std::string fontName = wstring2string(style2Write._fontName);
		if (oldFontName && oldFontName != fontName)
		{
			NppXml::setAttribute(element, "fontName", fontName);
			style2Sync._fontName = style2Write._fontName;
		}
	}

	if (style2Write._fontSize != STYLE_NOT_USED)
	{
		if (style2Write._fontSize == 0)
			NppXml::setAttribute(element, "fontSize", "");
		else
			NppXml::setAttribute(element, "fontSize", style2Write._fontSize);
	}

	if (style2Write._fontStyle != STYLE_NOT_USED)
	{
		NppXml::setAttribute(element, "fontStyle", style2Write._fontStyle);
	}

	NppXml::Node teteDeNoeud = NppXml::lastChild(element);

	const std::string& kws = style2Write._keywords;

	if (teteDeNoeud)
		NppXml::setValue(teteDeNoeud, kws);
	else
		NppXml::createChildText(element, kws);

}

void NppParameters::insertUserLang2Tree(NppXml::Element& node, const UserLangContainer* userLang)
{
	NppXml::Element rootElement = NppXml::createChildElement(node, "UserLang");

	static const std::string udlVersion = std::to_string(SCE_UDL_VERSION_MAJOR) + "." + std::to_string(SCE_UDL_VERSION_MINOR);

	NppXml::setAttribute(rootElement, "name", wstring2string(userLang->_name));
	NppXml::setAttribute(rootElement, "ext", wstring2string(userLang->_ext));
	if (userLang->_isDarkModeTheme) // set only if it's dark theme
		NppXml::setAttribute(rootElement, "darkModeTheme", "yes");
	NppXml::setAttribute(rootElement, "udlVersion", udlVersion);

	NppXml::Element settingsElement = NppXml::createChildElement(rootElement,"Settings");
	{
		NppXml::Element globalElement = NppXml::createChildElement(settingsElement, "Global");
		setBoolAttribute(globalElement, "caseIgnored", userLang->_isCaseIgnored);
		setBoolAttribute(globalElement, "allowFoldOfComments", userLang->_allowFoldOfComments);
		setBoolAttribute(globalElement, "foldCompact", userLang->_foldCompact);
		NppXml::setAttribute(globalElement, "forcePureLC", userLang->_forcePureLC);
		NppXml::setAttribute(globalElement, "decimalSeparator", userLang->_decimalSeparator);

		NppXml::Element prefixElement = NppXml::createChildElement(settingsElement, "Prefix");
		for (int i = 0 ; i < SCE_USER_TOTAL_KEYWORD_GROUPS ; ++i)
			setBoolAttribute(prefixElement, globalMappper().keywordNameMapper[i + SCE_USER_KWLIST_KEYWORDS1].c_str(), userLang->_isPrefix[i]);
	}

	NppXml::Element kwlElement = NppXml::createChildElement(rootElement, "KeywordLists");

	for (int i = 0 ; i < SCE_USER_KWLIST_TOTAL ; ++i)
	{
		NppXml::Element kwElement = NppXml::createChildElement(kwlElement, "Keywords");
		NppXml::setAttribute(kwElement, "name", globalMappper().keywordNameMapper[i]);
		NppXml::createChildText(kwElement, userLang->_keywordLists[i].c_str());
	}

	NppXml::Element styleRootElement = NppXml::createChildElement(rootElement, "Styles");

	for (const Style & style2Write : userLang->_styles)
	{
		NppXml::Element styleElement = NppXml::createChildElement(styleRootElement, "WordsStyle");

		if (style2Write._styleID == -1)
			continue;

		NppXml::setAttribute(styleElement, "name", wstring2string(style2Write._styleDesc));
		static constexpr size_t bufSize = 7;
		//if (HIBYTE(HIWORD(style2Write._fgColor)) != 0xFF)
		{
			const DWORD rgbVal = RGBHEX(style2Write._fgColor);
			char fgStr[bufSize]{};
			std::snprintf(fgStr, bufSize, "%.6lX", rgbVal);
			NppXml::setAttribute(styleElement, "fgColor", fgStr);
		}

		//if (HIBYTE(HIWORD(style2Write._bgColor)) != 0xFF)
		{
			const DWORD rgbVal = RGBHEX(style2Write._bgColor);
			char bgStr[bufSize]{};
			std::snprintf(bgStr, bufSize, "%.6lX", rgbVal);
			NppXml::setAttribute(styleElement, "bgColor", bgStr);
		}

		if (style2Write._colorStyle != COLORSTYLE_ALL)
		{
			NppXml::setAttribute(styleElement, "colorStyle", style2Write._colorStyle);
		}

		if (!style2Write._fontName.empty())
		{
			const std::string fontName = wstring2string(style2Write._fontName);
			NppXml::setAttribute(styleElement, "fontName", fontName);
		}

		if (style2Write._fontStyle == STYLE_NOT_USED)
		{
			NppXml::setAttribute(styleElement, "fontStyle", "0");
		}
		else
		{
			NppXml::setAttribute(styleElement, "fontStyle", style2Write._fontStyle);
		}

		if (style2Write._fontSize != STYLE_NOT_USED)
		{
			if (style2Write._fontSize == 0)
				NppXml::setAttribute(styleElement, "fontSize", "");
			else
				NppXml::setAttribute(styleElement, "fontSize", style2Write._fontSize);
		}

		NppXml::setAttribute(styleElement, "nesting", style2Write._nesting);
	}
}

void NppParameters::addUserModifiedIndex(size_t index)
{
	if (!std::any_of(_customizedShortcuts.begin(), _customizedShortcuts.end(),
		[&index](size_t userCmdIdx) { return userCmdIdx == index; }))
	{
		_customizedShortcuts.push_back(index); // Add index if not found
	}
}

void NppParameters::addPluginModifiedIndex(size_t index)
{
	if (!std::any_of(_pluginCustomizedCmds.begin(), _pluginCustomizedCmds.end(),
		[&index](size_t pluginCmdIdx) { return pluginCmdIdx == index; }))
	{
		_pluginCustomizedCmds.push_back(index); // Add index if not found
	}
}

void NppParameters::addScintillaModifiedIndex(int index)
{
	if (!std::any_of(_scintillaModifiedKeyIndices.begin(), _scintillaModifiedKeyIndices.end(),
		[&index](int scintCmdIdx) { return scintCmdIdx == index; }))
	{
		_scintillaModifiedKeyIndices.push_back(index); // Add index if not found
	}
}

#ifndef	_WIN64
void NppParameters::safeWow64EnableWow64FsRedirection(BOOL Wow64FsEnableRedirection)
{
	HMODULE kernel = GetModuleHandle(L"kernel32");
	if (kernel)
	{
		BOOL isWow64 = FALSE;
		typedef BOOL (WINAPI *LPFN_ISWOW64PROCESS) (HANDLE, PBOOL);
		LPFN_ISWOW64PROCESS IsWow64ProcessFunc = (LPFN_ISWOW64PROCESS) GetProcAddress(kernel,"IsWow64Process");

		if (IsWow64ProcessFunc)
		{
			IsWow64ProcessFunc(GetCurrentProcess(),&isWow64);

			if (isWow64)
			{
				typedef BOOL (WINAPI *LPFN_WOW64ENABLEWOW64FSREDIRECTION)(BOOL);
				LPFN_WOW64ENABLEWOW64FSREDIRECTION Wow64EnableWow64FsRedirectionFunc = (LPFN_WOW64ENABLEWOW64FSREDIRECTION)GetProcAddress(kernel, "Wow64EnableWow64FsRedirection");
				if (Wow64EnableWow64FsRedirectionFunc)
				{
					Wow64EnableWow64FsRedirectionFunc(Wow64FsEnableRedirection);
				}
			}
		}
	}
}
#endif

void NppParameters::setUdlXmlDirtyFromIndex(size_t i)
{
	for (auto& uxfs : _pXmlUserLangsDoc)
	{
		if (i >= uxfs._indexRange.first && i < uxfs._indexRange.second)
		{
			uxfs._isDirty = true;
			return;
		}
	}
}

/*
Considering we have done:
load default UDL:  3 languges
load a UDL file:   1 languge
load a UDL file:   2 languges
create a UDL:      1 languge
imported a UDL:    1 languge

the evolution to remove UDL one by one:

0[D1]                        0[D1]                        0[D1]                         [D1]                         [D1]
1[D2]                        1[D2]                        1[D2]                        0[D2]                         [D2]
2[D3]  [DUDL, <0,3>]         2[D3]  [DUDL, <0,3>]         2[D3]  [DUDL, <0,3>]         1[D3]  [DUDL, <0,2>]          [D3]  [DUDL, <0,0>]
3[U1]  [NUDL, <3,4>]         3[U1]  [NUDL, <3,4>]         3[U1]  [NUDL, <3,4>]         2[U1]  [NUDL, <2,3>]          [U1]  [NUDL, <0,0>]
4[U2]                        4[U2]                         [U2]                         [U2]                         [U2]
5[U2]  [NUDL, <4,6>]         5[U2]  [NUDL, <4,6>]         4[U2]  [NUDL, <4,5>]         3[U2]  [NUDL, <3,4>]         0[U2]  [NUDL, <0,1>]
6[C1]  [NULL, <6,7>]          [C1]  [NULL, <6,6>]          [C1]  [NULL, <5,5>]          [C1]  [NULL, <4,4>]          [C1]  [NULL, <1,1>]
7[I1]  [NULL, <7,8>]         6[I1]  [NULL, <6,7>]         5[I1]  [NULL, <5,6>]         4[I1]  [NULL, <4,5>]         1[I1]  [NULL, <1,2>]
*/
void NppParameters::removeIndexFromXmlUdls(size_t i)
{
	bool isUpdateBegin = false;
	for (auto& uxfs : _pXmlUserLangsDoc)
	{
		// Find index
		if (!isUpdateBegin && (i >= uxfs._indexRange.first && i < uxfs._indexRange.second)) // found it
		{
			if (uxfs._indexRange.second > 0)
				uxfs._indexRange.second -= 1;
			uxfs._isDirty = true;

			isUpdateBegin = true;
		}

		// Update
		else if (isUpdateBegin)
		{
			if (uxfs._indexRange.first > 0)
				uxfs._indexRange.first -= 1;
			if (uxfs._indexRange.second > 0)
				uxfs._indexRange.second -= 1;
		}
	}
}

void NppParameters::setUdlXmlDirtyFromXmlDoc(const NppXml::Document& xmlDoc)
{
	for (auto& uxfs : _pXmlUserLangsDoc)
	{
		if (xmlDoc == uxfs._udlXmlDoc)
		{
			uxfs._isDirty = true;
			return;
		}
	}
}

Date::Date(const char* dateStr)
{
	// timeStr should be Notepad++ date format : YYYYMMDD
	assert(dateStr);
	const size_t D = std::strlen(dateStr);

	if (8==D)
	{
		const std::string ds(dateStr);
		const std::string yyyy(ds, 0, 4);
		const std::string mm(ds, 4, 2);
		const std::string dd(ds, 6, 2);

		const int y = std::stoi(yyyy);
		const int m = std::stoi(mm);
		const int d = std::stoi(dd);

		if ((y > 0 && y <= 9999) && (m > 0 && m <= 12) && (d > 0 && d <= 31))
		{
			_year = y;
			_month = m;
			_day = d;
			return;
		}
	}
	now();
}

// The constructor which makes the date of number of days from now
// nbDaysFromNow could be negative if user want to make a date in the past
// if the value of nbDaysFromNow is 0 then the date will be now
Date::Date(int nbDaysFromNow) noexcept
{
	static constexpr time_t oneDay = (60 * 60 * 24);

	time_t rawtime;
	const tm* timeinfo;

	time(&rawtime);
	rawtime += (nbDaysFromNow * oneDay);

	timeinfo = localtime(&rawtime);
	if (timeinfo)
	{
		_year = timeinfo->tm_year + 1900;
		_month = timeinfo->tm_mon + 1;
		_day = timeinfo->tm_mday;
	}
}

void Date::now()
{
	time_t rawtime;
	const tm* timeinfo;

	time(&rawtime);
	timeinfo = localtime(&rawtime);
	if (timeinfo)
	{
		_year = timeinfo->tm_year + 1900;
		_month = timeinfo->tm_mon + 1;
		_day = timeinfo->tm_mday;
	}
}


EolType convertIntToFormatType(int value, EolType defvalue)
{
	switch (value)
	{
		using enum EolType;
		case static_cast<int>(windows):
		{
			return windows;
		}

		case static_cast<int>(macos):
		{
			return macos;
		}

		case static_cast<int>(unix):
		{
			return unix;
		}

		default:
		{
			return defvalue;
		}
	}
}

void NppParameters::initTabCustomColors()
{
	StyleArray& stylers = getMiscStylerArray();

	const Style* pStyle = stylers.findByName(TABBAR_INDIVIDUALCOLOR_1);
	if (pStyle)
	{
		individualTabHues[0].loadFromRGB(pStyle->_bgColor);
	}

	pStyle = stylers.findByName(TABBAR_INDIVIDUALCOLOR_2);
	if (pStyle)
	{
		individualTabHues[1].loadFromRGB(pStyle->_bgColor);
	}

	pStyle = stylers.findByName(TABBAR_INDIVIDUALCOLOR_3);
	if (pStyle)
	{
		individualTabHues[2].loadFromRGB(pStyle->_bgColor);
	}

	pStyle = stylers.findByName(TABBAR_INDIVIDUALCOLOR_4);
	if (pStyle)
	{
		individualTabHues[3].loadFromRGB(pStyle->_bgColor);
	}

	pStyle = stylers.findByName(TABBAR_INDIVIDUALCOLOR_5);
	if (pStyle)
	{
		individualTabHues[4].loadFromRGB(pStyle->_bgColor);
	}


	pStyle = stylers.findByName(TABBAR_INDIVIDUALCOLOR_DM_1);
	if (pStyle)
	{
		individualTabHuesFor_Dark[0].loadFromRGB(pStyle->_bgColor);
	}

	pStyle = stylers.findByName(TABBAR_INDIVIDUALCOLOR_DM_2);
	if (pStyle)
	{
		individualTabHuesFor_Dark[1].loadFromRGB(pStyle->_bgColor);
	}

	pStyle = stylers.findByName(TABBAR_INDIVIDUALCOLOR_DM_3);
	if (pStyle)
	{
		individualTabHuesFor_Dark[2].loadFromRGB(pStyle->_bgColor);
	}

	pStyle = stylers.findByName(TABBAR_INDIVIDUALCOLOR_DM_4);
	if (pStyle)
	{
		individualTabHuesFor_Dark[3].loadFromRGB(pStyle->_bgColor);
	}

	pStyle = stylers.findByName(TABBAR_INDIVIDUALCOLOR_DM_5);
	if (pStyle)
	{
		individualTabHuesFor_Dark[4].loadFromRGB(pStyle->_bgColor);
	}
}


void NppParameters::setIndividualTabColor(COLORREF colour2Set, int colourIndex, bool isDarkMode)
{
	if ((colourIndex < 0) || (colourIndex >= TAB_COLORS_COUNT)) return;

	if (isDarkMode)
		individualTabHuesFor_Dark[colourIndex].loadFromRGB(colour2Set);
	else
		individualTabHues[colourIndex].loadFromRGB(colour2Set);

	return;
}

COLORREF NppParameters::getIndividualTabColor(int colourIndex, bool isDarkMode, bool saturated)
{
	if ((colourIndex < 0) || (colourIndex >= TAB_COLORS_COUNT)) return {};

	HLSColour result;
	if (isDarkMode)
	{
		result = individualTabHuesFor_Dark[colourIndex];

		if (saturated)
		{
			result._lightness = 146U;
			result._saturation = std::min<WORD>(240U, result._saturation + 100U);
		}
	}
	else
	{
		result = individualTabHues[colourIndex];

		if (saturated)
		{
			result._lightness = 140U;
			result._saturation = std::min<WORD>(240U, result._saturation + 30U);
		}
	}

	return result.toRGB();
}

void NppParameters::initFindDlgStatusMsgCustomColors()
{
	StyleArray& stylers = getMiscStylerArray();

	const Style* pStyle = stylers.findByName(FINDDLG_STAUSNOTFOUND_COLOR);
	if (pStyle)
	{
		findDlgStatusMessageColor[0] = pStyle->_fgColor;
	}

	pStyle = stylers.findByName(FINDDLG_STAUSMESSAGE_COLOR);
	if (pStyle)
	{
		findDlgStatusMessageColor[1] = pStyle->_fgColor;
	}

	pStyle = stylers.findByName(FINDDLG_STAUSREACHED_COLOR);
	if (pStyle)
	{
		findDlgStatusMessageColor[2] = pStyle->_fgColor;
	}

}

void NppParameters::setFindDlgStatusMsgIndexColor(COLORREF colour2Set, int colourIndex)
{
	if (colourIndex < 0 || colourIndex > 2) return;

	findDlgStatusMessageColor[colourIndex] = colour2Set;

	return;
}

COLORREF NppParameters::getFindDlgStatusMsgColor(int colourIndex)
{
	if (colourIndex < 0 || colourIndex >= static_cast<int>(findDlgStatusMessageColor.size())) return black;

	return findDlgStatusMessageColor[colourIndex];
}

LanguageNameInfo NppParameters::getLangNameInfoFromNameID(const std::wstring& langNameID)
{
	for (const auto& lnf : ScintillaEditView::_langNameInfoArray)
	{
		if (lnf._langName == langNameID)
			return lnf;
	}
	return LanguageNameInfo{};
}

void NppParameters::buildGupParams(std::wstring& params)
{
	params = L"-v";
	params += VERSION_INTERNAL_VALUE;
	static constexpr int archType64 = NppParameters::archType();
	if constexpr (archType64 == IMAGE_FILE_MACHINE_AMD64)
	{
		params += L" -px64";
	}
	else if constexpr (archType64 == IMAGE_FILE_MACHINE_ARM64)
	{
		params += L" -parm64";
	}

	params += L" -infoUrl=";
	params += INFO_URL;

	params += L" -forceDomain=";
	params += FORCED_DOWNLOAD_DOMAIN;

	SecurityGuard sgd;

	//
	// Verify integrity & authenticiy of server-returned XML (XMLDsig) 
	//

	params += L" -chkCert4InfoXML";

	params += L" -chkCertKeyId4XML=";
	params += sgd.signer_key_id();

	//
	// Verify integrity & authenticiy of the downloaded installer
	//

	params += L" -chkCertSig=yes";

	params += L" -chkCertRevoc";
	params += L" -chkCertTrustChain";

	params += L" -chkCertName=";
	params += sgd.signer_display_name();

	params += L" -chkCertSubject=\"";
	params += stringReplace(sgd.signer_subject(), L"\"", L"{QUOTE}");
	params += L"\"";

	params += L" -chkCertKeyId=";
	params += sgd.signer_key_id();

	params += L" -errLogPath=";
	params += L"\"%LOCALAPPDATA%\\Notepad++\\log\\securityError.log\"";
}

void UserLangContainer::startAtTheme()
{
	// don't reset to the theme colors if it's already been set
	if (!_isUnset)
		return;

	NppParameters& nppParams = NppParameters::getInstance();
	COLORREF fg = nppParams.getCurrentDefaultFgColor();
	COLORREF bg = nppParams.getCurrentDefaultBgColor();

	for (Style& st : _styles)
	{
		st._bgColor = bg;
		st._fgColor = fg;

		// make BG "transparent" by default, to discourage changing background accidentally;
		//	but keep the _bgColor set, so that if they do un-transparent it, it starts at a reasonable default
		st._colorStyle = COLORSTYLE_FOREGROUND;
	}

	// now that it's started at theme values, not "unset" anymore
	_isUnset = false;
}
