{
  "summary": "All 12 Arena.exe-imported Media Foundation entry points exist in patched Wine 11.18 as real @ stdcall exports (or forwards to real implementations) — none are stubs or missing. Sample-grabber sink is real and delivers samples to OnProcessSample. H.264 decoder MFT (CLSID_MSH264DecoderMFT) is present but GStreamer-backed (needs host gst plugins). Color Converter DSP (CLSID_CColorConvertDMO, colorcnv) and Video Processor MFT (CLSID_VideoProcessorMFT, msvproc) are both present and implemented with libswscale. Notes written to notes/mf-gap.md.",
  "notes_file": "/home/asdf/projects/resolume-wine/notes/mf-gap.md",
  "key_facts": [
    "MF.dll: MFCreateTopology mf/topology.c:897, MFGetService mf/main.c:894, MFCreateMediaSession mf/session.c:5088, MFCreateTopologyNode mf/topology.c:1815, MFCreateSampleGrabberSinkActivate mf/samplegrabber.c:1543 — all real.",
    "MFPlat.DLL: MFCreateAttributes mfplat/main.c:3353, MFPutWorkItemEx mfplat/queue.c:79, MFCreateSourceResolver mfplat/main.c:6847, MFCreateMediaType mfplat/mediatype.c:1536, MFStartup mfplat/main.c:1591, MFShutdown mfplat/main.c:1609, MFCreateAsyncResult forwarded (mfplat.spec:44) to rtworkq RtwqCreateAsyncResult rtworkq/queue.c:1240 — all real.",
    "Sample grabber: sample_grabber_stream_ProcessSample (mf/samplegrabber.c:419) locks sample, converts contiguous, calls IMFSampleGrabberSinkCallback_OnProcessSample (lines 341-350); real delivery, pass-through (no decode).",
    "H.264 decoder MFT: CLSID_MSH264DecoderMFT in msmpeg2vdec.c:32; factory delegates to CLSID_wg_h264_decoder served by winegstreamer h264_decoder_create (winegstreamer/video_decoder.c:1701); requires GStreamer H.264 plugins at runtime, else returns error (not stub).",
    "Color Converter DSP CLSID_CColorConvertDMO: real, colorcnv/colorcnv.c:64 + color_converter.c:399 sws_scale_frame; Video Processor MFT CLSID_VideoProcessorMFT: real, msvproc/msvproc.c:47 + video_processor.c:358/1090."
  ]
}