{
  "summary": "Built the Windows-side API tracer in tools/apitrace/: apihook.dll (in-process Win64 IAT hooker, no Detours/MinHook needed), apitrace.exe (CreateProcess-suspended + remote LoadLibraryW injection, or --pid attach), plus a known-API selftest and a dynamic-load proof DLL. All acceptance items were demonstrated on real Windows (win11 guest) and cross-checked under host Wine 10.0. Builds are warning-free and reproducible (-Wl,--no-insert-timestamp); the guest binaries are bit-identical (MD5) to the host build.",
  "key_facts": [
    "Log grammar emitted exactly as specified, one line per call, written after the callee returns: `<seq> <tid> <dll>!<func> (arg0=0x..., arg1=0x...) -> 0x...`; seq is a locked counter, tid is GetCurrentThreadId, dll is the import-descriptor name (case preserved, e.g. KERNEL32.dll), arg0..arg3 are RCX/RDX/R8/R9 and arg4.. come from the caller stack at [rsp+0x28+8*(n-4)], return is RAX. Metadata lines all start with '#' (header: pid/tid, cfg/out, patterns/exclusions/modules, loader_notify, unresolved_patterns + `# unresolved: <raw>` per unresolved include pattern, `# exclude:`, `# pattern: <raw> -> dll=.. func=.. argc=.. mask=.. retw=..`, later `# resolved:`, `# process exit`).",
    "Config grammar: [~]dll!func[@argc[/argwidths][:retwidth]], dll!*, *!*, case-insensitive, '#' comments, '~' exclusions (evaluated first, always win). Extensions: @N = number of args to log (0..16, default 4, @0 for void), /argwidths = per-argument defined bytes (1/2/4/8) to mask ABI-undefined upper halves of 32-bit params, :retwidth = 4 or 8 bytes of RAX.",
    "Selftest EXE ({guest,host-Wine} runs): 13 call lines reproduce the process's own printed values exactly, e.g. CreateFileW (7 args incl. 3 stack args) arg0=path, arg4=0x2, arg5=0x80 -> 0xc0 = CreateFileW#1_ret; WriteFile arg0=0xc0 arg2=0xb arg3=&wrote -> 0x1; ReadFile arg1=buf arg3=&got -> 0x1; GetModuleHandleW -> 0x7ffc462d0000; MulDiv(7,3,2) -> 0xb; lstrlenA -> 0x5; pid/tid match. The excluded import kernel32!DeleteFileW is called twice by the test and never appears in the log; ntdll!ThisDoesNotExist is reported unresolved in the header.",
    "End-to-end in the guest: notepad.exe (Win11 Store-app launcher, 229 lines, 53 modules) and charmap.exe (5201 lines, 5147 calls; NtCreateFile with all 11 args, CreateWindowExW with 12, registry probes, ntdll status codes) traced via apitrace.exe; all logs copied back from the guest with curl.exe -T.",
    "Dynamic module hooking proven: winmm!timeGetTime is reported `(unresolved)` in the header, then `# resolved: winmm!timeGetTime@0:4 (first match WINMM.dll!timeGetTime)` appears and the call line returns 0xc85774d, the exact value the program printed after LoadLibraryW(\"lateload.dll\") (loader_notify=1; 200 ms polling fallback also present).",
    "Attach mode verified in the guest (--pid on an already-running process, hooks live, 26 call lines captured) and under Wine locally.",
    "Key design point for >4-arg APIs: a 29-byte generated stub (push imm32 idx; mov r11, orig; jmp [rip+0]) enters hook_common.S, which saves RAX/RCX/RDX/R8/R9/xmm0-3 and tail-jumps to the real function with a fresh callee frame built BELOW its own frame (copy of shadow space + 16 stack-arg slots), then logs from the return path; AL is preserved for varargs. Thread-safe via SRWLOCK + InterlockedIncrement64 + TlsAlloc re-entry guard; no heap use under the loader lock.",
    "Known limitations documented in notes/apitrace.md: ordinal imports skipped, delay-loaded IATs not patched, process trees not followed (Win11 System32\\notepad.exe spawns the packaged Notepad), Win64 targets only, no unwind info in the trampoline, tracer-internal calls not logged, ANSI paths, unbuffered log writes.",
    "Two real bugs found only on Windows (Wine hid them): GetFullPathNameW with aliased in/out buffers corrupted the DLL path (fixed with distinct buffers); and the arg-count sentinel collided with @0 (fixed with argc+1)."
  ],
  "paths": [
    "tools/apitrace/notes/apitrace.md",
    "tools/apitrace/src/apihook.c",
    "tools/apitrace/src/hook_common.S",
    "tools/apitrace/src/apitrace.c",
    "tools/apitrace/src/selftest.c",
    "tools/apitrace/tests/lateload.c",
    "tools/apitrace/build.sh",
    "tools/apitrace/test.cfg",
    "tools/apitrace/guest.cfg",
    "tools/apitrace/dyn.cfg",
    "tools/apitrace/evidence/selftest.guest.log",
    "tools/apitrace/evidence/charmap.guest.log",
    "tools/apitrace/evidence/notepad.guest.log",
    "tools/apitrace/evidence/dyn.guest.log",
    "tools/apitrace/evidence/attach.guest.log",
    "tools/apitrace/evidence/selftest.wine.log",
    "tools/apitrace/evidence/dyn.wine.log",
    "tools/apitrace/evidence/objdump-apihook.dll.txt",
    "tools/apitrace/evidence/objdump-apitrace.exe.txt",
    "tools/apitrace/build/apihook.dll",
    "tools/apitrace/build/apitrace.exe",
    "tools/apitrace/build/selftest.exe",
    "tools/apitrace/build/lateload.dll"
  ]
}