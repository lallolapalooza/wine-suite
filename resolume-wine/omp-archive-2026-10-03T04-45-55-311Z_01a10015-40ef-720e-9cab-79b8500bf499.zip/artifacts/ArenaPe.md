{
  "summary": "Produced notes/arena-pe.md with all requested PE facts for Arena.exe, each grounded in a command and observed output. Confirmed PE32+ x86-64 GUI, subsystem 6.0, linker 14.44 (VS 2022 17.14), image base 0x140000000, 8 sections, PDB path, msvc-1944 toolset string, MSVCP140/VCRUNTIME140(_1) imports. Enumerated 49 imported DLLs / 1224 functions with full sorted counts; captured exact complete import lists for every requested DLL, including ordinal imports. Delay-import table is empty (and bound imports empty). Extracted and quoted the RT_MANIFEST (asInvoker, dpiAware true, SegmentHeap, supportedOS Win10/11, Common-Controls 6 dependency) and RT_VERSION. Cross-checked all imports against wine-11.18 specs: everything resolves except COMCTL32 ordinal 345 (TaskDialogIndirect), which baseline comctl32.spec lacks and only the separate comctl32_v6 module provides.",
  "notes_file": "/home/asdf/projects/resolume-wine/notes/arena-pe.md",
  "key_facts": [
    "Arena.exe: PE32+ x86-64 GUI, image base 0x140000000, entry 0x141d16f6c, 8 sections, subsystem 6.0, linker 14.44 (VS 2022 17.14)",
    "COFF TimeDateStamp 0x6ab153c4 = 2026-09-21 15:56:52 UTC; PDB C:\\GitLab-Runner\\builds\\PvzR3vKgH\\0\\resolume\\software\\build\\RelWithDebInfo\\Arena.pdb",
    "49 imported DLLs, 1224 imported functions; largest: KERNEL32 229, MSVCP140 223, USER32 125, ucrt-math 52, OPENGL32 42",
    "MSVCP140.dll + VCRUNTIME140.dll + VCRUNTIME140_1.dll imported; embedded string COMPILER=msvc-1944 (MSVC 19.44 toolset); no MSVCP140_1/2",
    "OPENGL32 imports 42 fixed-function GL 1.x + wglCreateContext/wglMakeCurrent/wglGetProcAddress; SwapsBuffers/ChoosePixelFormat/SetPixelFormat come from GDI32",
    "MF.dll imports: MFCreateTopology, MFGetService, MFCreateMediaSession, MFCreateTopologyNode, MFCreateSampleGrabberSinkActivate",
    "MFPlat.DLL imports: MFCreateAttributes, MFPutWorkItemEx, MFCreateSourceResolver, MFCreateMediaType, MFStartup, MFShutdown, MFCreateAsyncResult",
    "No delay-import and no bound-import directories (both RVA 0/size 0); all imports static",
    "RT_MANIFEST: requestedExecutionLevel=asInvoker uiAccess=false, dpiAware=true (no dpiAwareness), heapType=SegmentHeap, supportedOS {8e0f7a12-bfb3-4fe8-b9a5-48fd50a15a9a}, dependency Microsoft.Windows.Common-Controls 6.0.0.0 token 6595b64144ccf1df",
    "Version info: FileVersion 7.28.0.24303, ProductVersion 7.28.0, OriginalFilename Arena.exe, CompanyName Resolume B.V.; embedded Authenticode signature (Resolume B.V. / DigiCert)",
    "Full Wine-export cross-check: every import resolves in wine-11.18 specs EXCEPT COMCTL32 ordinal 345 (TaskDialogIndirect); baseline dlls/comctl32/comctl32.spec omits 344/345/380/381 and the separate comctl32_v6 module provides 345",
    "Ordinal-import DLLs: WSOCK32 (29 winsock1.1 ordinals), OLEAUT32 (10), SHLWAPI (ord219=QISearch), COMCTL32 (ord345)"
  ]
}