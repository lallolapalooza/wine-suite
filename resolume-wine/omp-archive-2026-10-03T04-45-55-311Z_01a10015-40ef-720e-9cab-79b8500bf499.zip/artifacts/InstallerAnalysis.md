{
  "summary": "Analysed the Resolume Arena 7.28.0 Inno Setup 6.1.0 (unicode) installer. Confirmed silent switches, default dir, uninstall key, prerequisite launch behaviour, tmp/app/pf semantics and first-run licensing. To read the compressed Inno header directly I built a debug-enabled innoextract 1.9 from source in state/tmp (boost 1.90 headers/libs downloaded there); the decompressed [Setup] header and decoded entry dump back every claim. Notes written to notes/installer.md.",
  "notes_file": "/home/asdf/projects/resolume-wine/notes/installer.md",
  "key_facts": [
    "Setup is Inno Setup 6.1.0 (unicode), English, not passworded; innoextract -l -s lists 1180 entries.",
    "Engine accepts /VERYSILENT /SILENT /SUPPRESSMSGBOXES /NORESTART /SP- /NOCANCEL /LOG= /DIR= /LANG= /TASKS etc (UTF-16 help strings in the loader). Recommended: /VERYSILENT /SUPPRESSMSGBOXES /NORESTART /LOG=\"...\" /DIR=\"...\".",
    "/ALLUSERS and /CURRENTUSER are parsed but have no effect: PrivilegesRequiredOverridesAllowed is empty (override flag byte 0) and PrivilegesRequired=Admin (byte 2).",
    "DefaultDirName={pf}\\Resolume Arena; ArchitecturesInstallIn64BitMode=amd64 => C:\\Program Files\\Resolume Arena (UsePreviousAppDir set).",
    "AppId=\"Resolume Arena\" (not a GUID); Uninstallable=yes, UninstallRegKey=yes, admin mode => uninstall key HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\Resolume Arena_is1 (64-bit view) [key name derived per Inno's AppId+'_is1' convention].",
    "Prerequisites are run from [Code], not [Run]: msiexec.exe /i \"{tmp}\\Bonjour64.msi\" /quiet (Check not BonjourInstalled); {tmp}\\VC_redist_2022.x64.exe /quiet /norestart (Check not VS2022Installed, InstallVS('2022')); {tmp}\\vulkan-runtime.exe with NO arguments (InstallVulkan); optional Adobe DXV plugin copy via InstallAdobePlugins.",
    "tmp/ entries are {tmp} staging files with 'never uninstall, delete after install'; app/ = {app} permanent; pf/ = fixed {pf}\\Resolume Wire and {pf}\\Resolume Alley.",
    "[Run] installs netsh firewall rules for Arena, launches Arena.exe (Options: skip if silent), netsh rules for Wire, and runs {pf}\\Resolume Wire\\Wire.exe --FixLicensePermissions. UninstallRun deletes the firewall rules.",
    "Installer shows the EULA (app/licenses/Resolume-License.txt, 7055 bytes). The app itself is unregistered at first run and watermarked: Arena.exe contains '#1 is not registered. The video and audio are watermarked.', 'No license file installed.', 'Enter your #1 serial number...', plus online re-verification expiry messages and dongle/registration classes. Registration data goes to {commonappdata}\\Resolume Arena\\Registration\\."
  ]
}