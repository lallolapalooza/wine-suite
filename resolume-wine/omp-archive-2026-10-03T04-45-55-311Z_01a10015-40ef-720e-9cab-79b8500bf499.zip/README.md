# Session archive

Generated 2026-10-04T21:09:18.696Z from session `01a10015-40ef-720e-9cab-79b8500bf499`.

## Layout

| Path | Contents |
| --- | --- |
| `manifest.json` | Index of everything below (counts, sizes, subagent list) |
| `session.jsonl` | The main session transcript, verbatim |
| `agents.json` | Live per-agent state captured while the session ran (model, system prompt, tools) |
| `jobs.json` | Background jobs: `completed` (recovered from transcripts) + `live` (running/recent at archive time) |
| `artifacts/` | Every file under the session artifact directory, verbatim |
| `viewer.html` | Standalone HTML viewer (all subagent sessions embedded) |

`artifacts/` is the important part: it holds each subagent's own
`<AgentId>.jsonl` transcript (recursively nested), the session's
`*.bash.log` / `*.eval.log` / `*.read.log` files with the **full, untruncated**
tool and background-job output, and `*.jsonl.tombstone` kill markers.

## Background jobs

21 completed jobs recovered from the transcripts (main + every subagent); full list in `jobs.json`. A live snapshot of running/recent jobs for Main is also included. Per-job output lives in the owning transcript and in `artifacts/*.log`.

## Subagents (14)

- `ApiTracer` — 21 entries, 446137 bytes
- `ApiTracer2` — 11 entries, 21175 bytes
- `ApiTracer2-2` — 203 entries, 1027112 bytes
- `ArenaPe` — 246 entries, 647779 bytes
- `Components` — 106 entries, 332069 bytes
- `FfmpegTrace` — 151 entries, 457107 bytes
- `GlProbe` — 159 entries, 461059 bytes
- `GlProbe2` — 12 entries, 20992 bytes
- `GlProbe2-2` — 128 entries, 316517 bytes
- `InstallerAnalysis` — 326 entries, 1040584 bytes
- `LogDiff` — 115 entries, 533584 bytes
- `LogDiffFinish` — 15 entries, 25124 bytes
- `LogDiffFinish-2` — 130 entries, 446427 bytes
- `MfGap` — 106 entries, 353480 bytes

## Totals

78 files, 33453590 bytes.
