# Session archive

Generated 2026-10-04T21:08:38.345Z from session `01a10268-3db5-706c-a606-5001389a4de3`.

## Layout

| Path | Contents |
| --- | --- |
| `manifest.json` | Index of everything below (counts, sizes, subagent list) |
| `session.jsonl` | The main session transcript, verbatim |
| `agents.json` | Live per-agent state captured while the session ran (model, system prompt, tools) |
| `jobs.json` | Background jobs: `completed` (recovered from transcripts) + `live` (running/recent at archive time) |
| `artifacts/` | Every file under the session artifact directory, verbatim |
| `viewer.html` | Standalone HTML viewer (all subagent sessions embedded) |

`artifacts/` is the important part: it holds each subagent's own
`<AgentId>.jsonl` transcript (recursively nested), the session's
`*.bash.log` / `*.eval.log` / `*.read.log` files with the **full, untruncated**
tool and background-job output, and `*.jsonl.tombstone` kill markers.

## Background jobs

78 completed jobs recovered from the transcripts (main + every subagent); full list in `jobs.json`. A live snapshot of running/recent jobs for Main is also included. Per-job output lives in the owning transcript and in `artifacts/*.log`.

## Subagents (25)

- `CodeMeterProbe` — 602 entries, 1744771 bytes
- `DotnetProbe` — 274 entries, 727714 bytes
- `EosApiDiff` — 630 entries, 2117265 bytes
- `EosDeadlockRE` — 465 entries, 1587286 bytes
- `EosImportsRecon` — 266 entries, 5345841 bytes
- `EosVMReference` — 545 entries, 1529050 bytes
- `HogApiDiff` — 626 entries, 2059219 bytes
- `HogImportsRecon` — 224 entries, 2837240 bytes
- `HogMonitorRenderRE` — 493 entries, 1828166 bytes
- `HogVMReference` — 564 entries, 1435131 bytes
- `InitialPaintPatch` — 384 entries, 1548261 bytes
- `IpHlpapiPatch` — 188 entries, 770283 bytes
- `LaunchCrashRE` — 695 entries, 1744796 bytes
- `LockPermRE` — 359 entries, 1251828 bytes
- `McInstallWine` — 481 entries, 1872535 bytes
- `PayloadRecon` — 11 entries, 21127 bytes
- `PayloadRecon-2` — 216 entries, 717176 bytes
- `QtSourceIndex` — 596 entries, 1952773 bytes
- `QtSourceIndex/QtSourceIndex.ChromiumWin32Surfaces` — 12 entries, 25399 bytes
- `QtSourceIndex/QtSourceIndex.WineSpecInventory` — 8 entries, 19145 bytes
- `SeriesRecon` — 8 entries, 15752 bytes
- `SeriesRecon-2` — 79 entries, 509485 bytes
- `SvcTokenPatch` — 168 entries, 415487 bytes
- `VMReference` — 8 entries, 19780 bytes
- `VMReference-2` — 673 entries, 1452794 bytes

## Totals

132 files, 96288045 bytes.
