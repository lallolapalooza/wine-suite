{
  "status": "complete",
  "deliverable": "docs/VM_REFERENCE.md (268 lines) — exact commands, working install line, install tree, main exe paths, first-launch behaviour with no hardware/licence + screenshots, remaining guest free space",
  "install": {
    "transfer": "HTTP from host vmserv (vmshare/ served on 0.0.0.0:8000, guest reaches http://192.168.122.1:8000/): curl.exe -s -o C:\\hog\\Hog_PC_5.2.1.31.msi http://192.168.122.1:8000/Hog_PC_5.2.1.31.msi (3.4 s, 365039616 B, sha256 29aae8efc9639462252ace17e4d359116affe3b2e68df193b7e7e80034ffcac2)",
    "copied_to_guest": "C:\\hog\\Hog_PC_5.2.1.31.msi (still there, 348 MB; deletable to reclaim)",
    "command_that_worked": "msiexec /i C:\\hog\\Hog_PC_5.2.1.31.msi /qn /norestart /L*v C:\\hog\\hog_msi2.log  -> RC=0, 91 s, run ELEVATED",
    "no_properties_needed": "plain /qn; HASPEXISTS is an AppSearch property (guest already had HASP driver 9.16.156120.1, so it was set from the first run); Install_HASP/Enable_HASP are declared but NOT scheduled, so haspdinst never ran under /qn",
    "hard_requirement": ">= ~8 GB free on guest C: — first attempt died 1603 with 6.554 GB free (SA_FixLib_Unpack: fixturelib.hog5lib 137 MB -> 2.92 GB tar -> 2.92 GB extracted = ~5.8 GB peak). Succeeded with 7.903 GB free.",
    "failed_attempt_log": "logs/vm/vm_hog_msi.log",
    "success_log": "logs/vm/vm_hog_msi2.log"
  },
  "install_result": {
    "root": "C:\\Program Files (x86)\\ETC\\HogPC (565.7 MB; 32-bit package, ProgramFilesFolder -> x86)",
    "data_dir": "C:\\ProgramData\\ETC\\HogPC (fixtureLibrary 2.9 GB + helptext + resources)",
    "product": "Hog PC 5.2.1.31, ProductCode {6501E546-28F5-4A0E-97E0-1CD914185417}",
    "uninstall": "HKLM\\SOFTWARE\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\{6501E546-...}: DisplayName 'Hog PC', DisplayVersion 5.2.1.31, InstallLocation 'C:\\Program Files (x86)\\', EstimatedSize 776187 KB, UninstallString MsiExec.exe /X{6501E546-...}",
    "services": "fpstftp (Hog TFTP) + fpsdhcp (Hog DHCP), Manual/Stopped, image netservices-win32-golden.exe",
    "shortcuts": "Start Menu\\Programs\\HogPC\\{Hog PC -> launcher-win32-golden.exe, Widget Upgrader, Hog Manuals}; Public Desktop\\Hog PC.lnk -> launcher-win32-golden.exe",
    "registry": "HKLM\\SOFTWARE\\WOW6432Node\\ETC\\HogPC ProductVersion=5.2.1.31",
    "firewall": "10 inbound-allow rules (Server/Critical/Launcher/Desktop/DP8K TCP+UDP) - note NO rule for monitor-*"
  },
  "gui_entry_point": "launcher-win32-golden.exe (32-bit Qt 5.15.1). Single window class Qt5151QWindow / inner class ShowConnectWindow, title 'Hog Start', 792x338 at (244,231). Buttons: New Show, Launch Show(disabled), Browse, Connect to Show(disabled), Start Processor, Control Panel, File Browser, Help, Quit. text: 'Version: v5.2.1 (b 31)', HN/FN IP 192.168.122.230, 'No Show found'. NOT desktop-* ; the launcher spawns the children.",
  "first_launch_no_hw_no_licence": {
    "launcher": "comes straight up - NO licence dialog, NO HASP/hardware error, NO demo nag",
    "start_processor": "spawns monitor-win32-golden.exe -> top-level window 'Processor' (class MonitorWindow, 770x370) showing 'Show Server IP: No Server', Hog/Fixture Net IP, 'Offline', 'Port Number: 6600', 'Software Version: v5.2.1 (b 31)'; buttons Lock/Touchscreens/Quit => runs fully offline",
    "only_dialog": "Windows Firewall consent for monitor-win32-golden (installer has no rule for it)",
    "elevation": "launcher exe/shortcut requests elevation (UAC prompt: 'launcher / Application / Verified publisher: Electronic Theatre Controls, Inc.')",
    "gpu": "guest has only Microsoft Basic Display Adapter (10.0.26100.1); Qt/QML renders fine in software => NO GPU required",
    "new_show_chain": "New Show -> Hog's own Qt file dialog (title 'New Show', Look In: Shows/Hog PC, File name/Comment, Finish/Cancel) -> Finish creates C:\\Users\\adsf\\Documents\\ETC\\HogPC\\Shows\\<name>\\{hogdatabase.mk2,hog_ident.json,blackbox\\0.hbb} -> window 'Console Startup Process' ('Waiting on Desktop Process') -> launcher spawns server-win32-golden.exe + critical-win32-golden.exe + desktop-win32-golden.exe -> real console window 'Hog PC - Primary Screen' (class Qt5151QWindowIcon, (-8,0)-(1280,799), top bar Palettes/Master/Programmer/Output/Views; 187 UIA elements). Still no licence/hardware prompt. Answer to Wine team: YES, on Windows the launcher spawns server/critical/desktop itself (no manual -port/-netnum needed); argv not recoverable (WMI CommandLine empty for elevated children).",
    "persisted_state": "%APPDATA%\\ETC\\Persistent\\client_settings.json {startOb,startProcessor,startServer,startVob,portNum:6600,pin:1234,...} - once startProcessor/startServer are true the next launcher start auto-starts the processor and 'Hog Start' never shows; also last_newshow.json, old_shows.json, server_settings.json, playback_bar_config.json, %APPDATA%\\ETC\\Hog.ini"
  },
  "housekeeping": {
    "free_before_GB": 6.894,
    "reclaimed": "4.44 GB failed-install fixture-library debris + Eos Family install (C:\\Program Files\\ETC 0.67 + C:\\ProgramData\\ETC\\EosFamily 0.95) + C:\\apitrace 0.39 (Eos was explicitly disposable)",
    "free_after_cleanup_GB": 7.903,
    "free_immediately_after_install_GB": 3.18,
    "free_at_handoff_GB": 3.125,
    "kept": "WebView2, VC++ 2022, .NET 10 desktop, .NET Framework 4.8 (untouched); other projects' data (acadbox/Autodesk) untouched"
  },
  "artifacts": {
    "doc": "docs/VM_REFERENCE.md",
    "logs": [
      "logs/vm/vm_hog_capture.txt (full tree/registry/services/shortcuts/firewall)",
      "logs/vm/vm_hog_msi.log + vm_hog_msi2.log",
      "logs/vm/vm_hog_launch.txt (window/process dumps)",
      "logs/vm/vm_hog_uia_launcher.txt, vm_hog_uia_console.txt",
      "logs/vm/vm_hog_dialogs.txt, vm_hog_windows.txt, vm_hog_fresh.txt, vm_hog_newshow.txt"
    ],
    "evidence": [
      "evidence/vm_hog_launch_01/02/03* (Hog Start launcher)",
      "vm_hog_launch_04_firewall_monitor.png",
      "vm_hog_launch_05_processor*.png",
      "vm_hog_launch_07_launcher_non_elevated.png (UAC)",
      "vm_hog_launch_10/11_newshow*.png (New Show dialog)",
      "vm_hog_launch_12_console_startup.png, _13_console.png",
      "evidence/vm_hog_state_now.png"
    ],
    "new_reusable_tools": "tools/vm/hog_capture.ps1, hog_launch.ps1, hog_uia.ps1, hog_dialogs.ps1, hog_windows.ps1, hog_restore.ps1, hog_start.ps1, hog_fresh.ps1, hog_newshow.ps1, hog_space.ps1, hog_space2.ps1, hog_leftovers.ps1, hog_diag.ps1, hog_diskusage.ps1, hog_cleanup.ps1, vm_admin2.ps1 (hardened elevated loop)"
  },
  "notes_for_main": [
    "The old elevated loop C:\\Users\\adsf\\vm_admin.ps1 was wedged by a variable collision ($out) and was replaced by tools/vm/vm_admin2.ps1 (relaunch with tools/vm/elev.sh tools/vm/vm_admin2.ps1 --name vm_admin2.ps1). Scripts sent through the channel MUST NOT assign $out/$raw/$res/$o/$in/$U - it Invoke-Expression's in the runner's scope.",
    "Guest handed to peer HogApiDiff (their destructive apitrace of launcher/server/desktop) after I captured everything; they have the console UI state and the answers they asked for.",
    "Left on the guest: Hog install + C:\\hog\\{MSI 348 MB, hog_msi.log, hog_msi2.log, log} + a 'yNewShow' show; 3.125 GB free. Delete C:\\hog\\Hog_PC_5.2.1.31.msi + logs to reclaim ~360 MB if the guest gets tight.",
    "No tests/builds run by me on the Wine side (out of scope); verification left to main."
  ]
}