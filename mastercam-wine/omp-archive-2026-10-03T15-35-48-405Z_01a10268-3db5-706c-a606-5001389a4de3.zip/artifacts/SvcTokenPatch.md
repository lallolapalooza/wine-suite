{
  "status": "complete",
  "deliverable": "/home/user/projects/mastercam-wine/patches/local/0101-services-service-logon-token.patch (5601 bytes, 4 files, 4 hunks)",
  "files_changed": [
    {
      "file": "server/token.c",
      "change": "new file-scope `static const struct sid service_sid = { SID_REVISION, 1, SECURITY_NT_AUTHORITY, { SECURITY_SERVICE_RID } };` next to `interactive_sid`; new exported helper `void token_make_service_logon( struct token *token )` inserted after `token_get_session_id()`. It removes the group equal to `interactive_sid` (S-1-5-4) from `token->groups` (list_remove + free), then if `service_sid` (S-1-5-6) is absent allocates `offsetof(struct group, sid.sub_auth[service_sid.sub_count])` via mem_alloc, sets attrs = SE_GROUP_ENABLED|SE_GROUP_ENABLED_BY_DEFAULT|SE_GROUP_MANDATORY, copy_sid(), list_add_tail(); calls allocate_luid(&token->modified_id) iff something actually changed (same 'mark modified' idiom as token_adjust_privileges). Removing the interactive group is safe because the primary group is domain_users, never interactive, so token->owner/primary_group cannot dangle. OOM on the add leaves the token with only the interactive group removed (helper is void per spec, mirrors existing non-failing style)."
    },
    {
      "file": "server/security.h",
      "change": "declaration `extern void token_make_service_logon( struct token *token );` added between token_get_session_id and token_sid_present (the block where the server declares token helpers)."
    },
    {
      "file": "server/process.c",
      "change": "in create_process(), immediately after the existing session_id assignment: `if (parent && !parent->session_id && !token) token_make_service_logon( process->token );`. Applied to the freshly duplicated token (token_duplicate gives a private copy of the groups), so the parent's token is untouched; skipped when an explicit token handle was passed to NtCreateProcess/NtCreateUserProcess."
    },
    {
      "file": "programs/services/services.c",
      "change": "secondary/optional hunk: `DWORD service_pipe_timeout = 10000;` -> `30000;` (matches Windows' 30 s service-control wait; does NOT fix a service that never connects)."
    }
  ],
  "trigger_condition": "parent != NULL && parent->session_id == 0 && token == NULL (no explicit token handle). parent->session_id is 0 only for services.exe (set by 0004-services-session-0.patch in server/mapping.c add_process_view() via is_services_exe()) and for its descendants (0004's cascade in create_process: `(parent && !parent->session_id) ? 0 : ...`). Every ordinary interactive process gets session_id = default_session_id = 1 (server/process.h) or the token session id, so the trigger cannot fire for interactive processes. 0004 exposes only a static is_services_exe() helper and no process flag, so the session-id of the parent is the only available signal; it is the exact same signal 0004 already uses. Ownership/data-flow: the transformation only ever runs on the child's own duplicated primary token, never the parent's or a caller-supplied one.",
  "validation": {
    "base_trees": "state/tmp/p0101/pristine (5 files extracted from /home/user/Downloads/wine-11.18.tar.xz) and state/tmp/p0101/base = pristine + patches/series/0004-services-session-0.patch applied (verified byte-identical to the live wine-11.18/server/process.c, token.c, security.h, services.c).",
    "dry_run_pristine_plus_series": "`cd state/tmp/p0101/base/wine-11.18 && patch -p1 --dry-run < patches/local/0101-...patch` -> 'checking file server/token.c / server/security.h / server/process.c / programs/services/services.c', exit 0, no fuzz/rejects.",
    "dry_run_live_tree_series_plus_0100": "`cd wine-11.18 && patch -p1 --dry-run < patches/local/0101-...patch` -> exit 0. 0100-msi-class-registry-view.patch touches only dlls/msi/classes.c, so 0100 and 0101 share no file and apply in either order.",
    "real_apply_reproduces_intent": "patch applied for real to a throwaway copy of base; all four resulting files are byte-identical to the hand-edited reference tree (diff clean).",
    "syntax": "gcc -m64 -fsyntax-only -Wall -D__WINESRC__ -DWINE_UNIX_LIB -I<buildtree> -I<buildtree>/server -I<buildtree>/include on patched server/token.c and server/process.c -> exit 0, no warnings. services.c shows only the pre-existing `wcsdup` warning under my ad-hoc flag set (identical on the unpatched base), none from the changed line."
  },
  "how_to_verify": [
    "Rebuild wineserver and programs/services with the patch (do not build in this session; a build was running).",
    "Start a service that 0004 fixed, e.g. `sc start CmWebAdmin` (CodeMeter, from the failing MSI) or Autodesk's AdskLicensingService.",
    "Inspect the *service process* primary token groups: S-1-5-6 (SERVICE) must be present and enabled, S-1-5-4 (INTERACTIVE) must be absent. Before the patch the measured set was S-1-1-0, S-1-2-0, S-1-5-4, S-1-5-11, S-1-5-21-0-0-0-513, S-1-5-32-544, S-1-5-32-545, S-1-5-5-0-0 (SERVICE=0).",
    "Consequence: golang.org/x/sys/windows/svc.IsAnInteractiveSession() returns false, the Go service calls StartServiceCtrlDispatcherW(), connects to the SCM control pipe, and `sc start`/`sc query` reports STATE 4 RUNNING instead of 1053 ERROR_SERVICE_REQUEST_TIMEOUT; the MSI no longer rolls back.",
    "Regression guard: an ordinary interactive process (e.g. cmd launched from the desktop) must still have S-1-5-4 present and S-1-5-6 absent, since its parent's session_id is 1."
  ],
  "notes": "Scratch validation tree left at /home/user/projects/mastercam-wine/state/tmp/p0101/{pristine,seriestree,base,verify} for re-verification; the live source and build trees were never modified (only read + --dry-run)."
}