{
  "verdict": {
    "category": "b) architectural / Wine-API gap in the network path (NOT a Wine synchronisation bug, NOT a Qt/graphics issue)",
    "one_line": "The post-splash stall is a ~58 s start-up block gated on the ACN/sACN/SLP discovery bring-up, which fails under Wine (SLP registration times out per interface, iphlpapi change-notification callbacks never fire, sACN multicast setsockopt fails); while it is pending the GUI thread sits in RtlpWaitForCriticalSection on an app CRITICAL_SECTION whose owner is parked in Wine's server wait, and the whole app piles up behind it. The same transient exists on Windows and self-heals in 10 s; under Wine it takes ~58 s and then the editor opens.",
    "permanent_deadlock": false,
    "recovery_observed": "Two clean runs: 'OnyxConsole recovered from hang after 54.09 s / 58.08 s', main editor window 'Eos : 1' 1600x1000 up (OCR = live Eos editor). Other runs stayed stalled for 115-160 s (watchdog 'hang 4 detected after 159.77 s')."
  },
  "named_blocker": {
    "lock": "app CRITICAL_SECTION (three of them, +0x38/+0x78/+0x338 inside one heap object), identical every run",
    "gui_thread_stall": "ntdll!RtlEnterCriticalSection -> ntdll!RtlpWaitForCriticalSection -> ntdll!RtlWaitOnAddress -> ntdll!ZwWaitForAlertByThreadId (futex)",
    "section_owner": "parked in ntdll.so wait_select_reply (dlls/ntdll/unix/server.c:357) <- server_select (:777) <- wait_reply (:276) <- server_call_unlocked (:292) = a WaitForSingleObject-class wait on a Wine server object; Linux wchan anon_pipe_read is Wine's client/server pipe (server_pipe, dlls/ntdll/unix/server.c:1280), not an app pipe",
    "err_sync_example": "err:sync:RtlpWaitForCriticalSection section 00007B42C31F48F8 \"?\" wait timed out in thread 07ec, blocked by 01d0, retrying (60 sec)  [07ec = GUI thread]"
  },
  "failing_calls": [
    "iphlpapi!NotifyIpInterfaceChange -> Wine stub, never invokes the app callback: dlls/iphlpapi/iphlpapi_main.c:3966 (relay: 'fixme:iphlpapi:NotifyIpInterfaceChange (...): stub' then 'retval=00000000')",
    "iphlpapi!NotifyUnicastIpAddressChange -> semi-stub that only fires when init_notify != 0 (app passes 0): dlls/iphlpapi/iphlpapi_main.c:4014",
    "SLPReg() failed with result -19 (SLP_NETWORK_TIMED_OUT) per interface ~27.6 s -> 'SDT Couldn't Create component EF4DC218-... on iface N -- Couldn't register that protocol in discovery' -> 'CreateComponent Created component handle=ffffffff' (Windows: handle=80000000 in ~10 ms, zero SLP failures)",
    "sACN: setsockopt(IP_MULTICAST_IF) / IP_ADD_MEMBERSHIP fail with 'Invalid argument' (WSAEINVAL) -> '[CRIT] sACN: None of the network interfaces were usable for the sACN API.' (ws2_32)"
  ],
  "per_thread_stacks": {
    "source": "live gdb attach (PR_SET_PTRACER re-armed after Wine's own prctl at dlls/ntdll/unix/server.c:1668) + the app's own EOSHang minidumps parsed by tools/host/mdmp.py",
    "gui_key_thread": "RtlEnterCriticalSection -> RtlpWaitForCriticalSection -> RtlWaitOnAddress -> futex syscall, app/Qt5Core frames above",
    "section_owner": "ntdll.so server_select/wait_reply -> read() on the Wine server pipe",
    "48 threads": "pooled app workers idle in ntdll!ZwWaitForSingleObject / ZwRemoveIoCompletion",
    "4 threads": "app worker objects in kernelbase!WaitForSingleObject (same Eos.exe frames)",
    "2 threads": "ws2_32!select socket pollers (Linux wchan poll_schedule_timeout)",
    "1 thread": "network monitor: ZwDelayExecution (Sleep loop)"
  },
  "discriminators": {
    "sync_on_relay_off": "same stall (+relay only changes the CS retry period 60s -> 300s)",
    "platform_windows_plus_QT_QPA_PLATFORM_PLUGIN_PATH_plus_QT_LOGGING_RULES_plus_QT_OPENGL_software_plus_WINEDLLOVERRIDES_d3d11,dxgi,d2d1,opengl32=b": "same stall, same network phase, then recovered at 54.09 s and opened the editor -> graphics/Qt is not the blocker (app log shows UI init completed; graphics/Vulkan threads idle in all dumps)",
    "plain_control_run": "reproduced: 'Registering for network changes...' 13:58:26 -> SLP timeouts -> handle=ffffffff 13:59:05 -> ACN started -> 'recovered from hang after 58.08 s' -> editor window at t=75 s"
  },
  "windows_reference": "EosVMReference: same transient (unresponsive at +10 s) but self-heals: 'OnyxConsole recovered from hang after 10.10 s', NICs 0->9, CreateComponent handle=80000000, ACN started, no SLP failures, editor up ~+18 s, no licence dialogue.",
  "where_to_patch": [
    "dlls/iphlpapi/iphlpapi_main.c:3966 NotifyIpInterfaceChange() - implement on the existing NSI plumbing (NotifyAddrChange already uses NsiRequestChangeNotification + nsiproxy IOCTL_NSIPROXY_WINE_CHANGE_NOTIFICATION) and deliver change callbacks instead of returning NO_ERROR with *handle=NULL",
    "dlls/iphlpapi/iphlpapi_main.c:4014 NotifyUnicastIpAddressChange() - same (deliver changes, not only init_notify)",
    "optionally an SLP service agent so SLPReg() does not time out (-19), and ws2_32 setsockopt(IP_MULTICAST_IF)/IP_ADD_MEMBERSHIP so sACN sees a usable interface",
    "explicitly NOT dlls/ntdll/sync.c: RtlpWaitForCriticalSection behaves as specified; the lock is simply never released because the owner's network step never completes"
  ],
  "artifacts": [
    "docs/EOS_STALL_RE.md (full report)",
    "logs/runs/winedbg/run4/{gdb.txt,maps.txt,task_state.txt,sync_errors.txt}",
    "logs/runs/winedbg/stacks1/{gdb_raw.txt,maps.txt,task_state.txt,sync_errors.txt}",
    "logs/runs/winedbg/dumps/{hang_A_S.dmp,hang_threads.txt,bt_hangS.txt,EosAsserts.txt,OnyxConsole.log,NetworkFeedback.log,CriticalIssues.txt}",
    "logs/runs/{disc1,ctrl2}/{out.txt,windows_*.txt,screen_*.png}",
    "logs/api/wine_eos.relay.log",
    "tools/host/{mdmp.py,bt_raw.py,resolve_addr.py,stall_dump.sh,win_stack_run.sh,stack_dump.sh,late_ptrace.c,winedbg_dump.py,mdump_bt.py}"
  ],
  "tooling_gotcha": "tools/run_eos.sh's kill loop checks /proc/<pid>/comm for 'wine' but the app process' comm is 'Eos.exe', so it never kills leftovers; Eos is single-instance (QSharedMemory), so a leftover makes the next launch exit in ~3 s silently. Use pkill -9 -x Eos.exe first. Also: winedbg<dmp> loads the app's EOSHang minidumps but its 'info threads' hangs and 'thread <tid>' is a no-op for minidumps - parse them with tools/host/mdmp.py instead."
}