{
  "language_pack": {
    "installed": "yes",
    "command": "WINEPREFIX=state/work/prefix wine /run/media/user/Windows/mastercam-media/support/languagepacks/2027_en_language_pack_mastercam.exe /s /v\"/qn REBOOT=ReallySuppress\"",
    "rc": 0,
    "wall": "~68 s",
    "log": "logs/runs/langpack/install.stderr"
  },
  "verification_vs_windows": {
    "registry": "HKLM\\SOFTWARE\\CNC Software\\Mastercam 2027 now has LanguagePackProvider=Mastercam, LanguagePackVersion=29.0.10172.0, LocalLanguagePacksDirectory (Windows-identical block) + ApplicationLocaleName=en",
    "uninstall_entry": "Mastercam 2027 English Language Pack ({C253C79A-...})",
    "en_trees": [
      "en/ (31 res dlls incl opmanres.dll, MCToolRes.dll, MCCoreRes.dll)",
      "apps/en",
      "chooks/en",
      "Extensions/en",
      "importexport/en",
      "simulator/en",
      "help/en",
      "Documentation/en"
    ],
    "Res_dll_count": "95 in prefix == 95 on Windows (exact match)",
    "app_dir_files": "8129 / 3.0 GB vs Windows 10908 (still missing Mastercam 2027 Updater and Common Files\\Mastercam\\MastercamLicensing)"
  },
  "relaunch_mastercam_exe_240s": {
    "alive": "whole 240 s, zero exceptions (direct or loader)",
    "windows": [
      "0x1200001 \"Warning\" (frame 356x147 / client 354x124) - viewable but its client area is painted SOLID BLACK, no glyphs at any 0-255 threshold -> text unreadable, not OCR-able",
      "0xc00001 \"Exiting...\" (frame 253x105 / client 251x82) - OCR: \"No Valid Mastercam License found\" (exact string in en/opmanres.dll: 'Exiting... No Valid Mastercam License found')",
      "hidden 1x1 message + Default IME windows; crashpad_handler.exe running"
    ],
    "timeline": "dialogs exist by t=10 s; no such dialogs in the pre-language-pack runs",
    "dismissing": "click OK on Warning then OK on Exiting... -> process exits; no main window ever"
  },
  "relaunch_launcher_240s": {
    "alive": "whole 240 s, no errors",
    "window": "0xc00001 \"MastercamLauncher\" (159x103 frame / 157x82 client), viewable - OCR: \"No license found\"",
    "note": "exactly the terminus already documented in docs/LICENSING_VERDICT.md"
  },
  "target_state_reached": "NO - Windows target is main window 'Mastercam 2027' -> 400x400 'Checking license...' splash -> modal 'No Mastercam license found. Do you have an activation code?' [Yes][No]; under Wine there is no main window, no splash and no activation prompt at any sample (20..240 s). Wine's user32/GDI do create real viewable windows (dialogs are drawn, clickable, clicks work) - the licence gate fires first.",
  "single_next_blocker": "The licence gate (documented architectural wall, NOT a UI problem). WIBUCM64.dll (CodeMeter) is loaded by Mastercam.exe at start-up (+module trace: MODULE_InitDLL ... L\"WIBUCM64.dll\", THREAD_ATTACH), so the licence check goes through CodeMeter; docs/LICENSING_VERDICT.md already proves the CodeMeter service never publishes Global\\CmApiCallIn because the Wibu/HASP kernel driver + device surfaces are absent (vusb.sys, \\.\\pipe\\SafeNet-SentinelPIPE-*, \\.\\Nsi, \\.\\PhysicalDriveN -> c0000034). The app therefore takes its hard 'no valid licence' exit path (Warning + 'Exiting... No Valid Mastercam License found'), while Windows' intact licensing stack reaches the interactive licence UI. Same wall as before, now hit after the DllMain crash.",
  "side_finding_not_the_blocker": {
    "error": "err:module:import_dll Library ManagedUI.Controllers.dll (which is needed by ...\\ManagedUI\\MCCore.Controllers.dll) not found (~2 s in, first hard error)",
    "detail": "+module shows ManagedUI.Controllers.dll was mapped 0.66 s earlier by the CLR (full path, build_module loaded) then detached; MCCore.Controllers.dll is a mixed-mode C++/CLI assembly (imports ijwhost.dll) loaded by full path with the standard search path, which does NOT include ...\\ManagedUI -> by-name import lookup fails (status=c0000135)",
    "test": "copied ManagedUI\\ManagedUI.Controllers.dll into the app root -> error disappears and behaviour is IDENTICAL (same dialogs, same exit). Copy reverted.",
    "wine_src": "wine-11.18/dlls/ntdll/loader.c:3348 load_dll / :3273 find_dll_file (find_basename_module)"
  },
  "prefix_changes": [
    "Mastercam 2027 English Language Pack installed (intended prerequisite fix, kept)",
    "ApplicationLocaleName=en kept (from previous step)",
    "temporary ManagedUI.Controllers.dll copy in app root: reverted"
  ],
  "doc": "docs/LAUNCH_CRASH_RE.md updated with a new section 9 (language-pack install + post-fix UI behaviour + next blocker)",
  "artifacts": [
    "logs/runs/langpack/install.stderr",
    "logs/runs/mc_lp/",
    "logs/runs/mc_diag/",
    "logs/runs/mc_mod/",
    "logs/runs/mc_fix1/",
    "logs/runs/launcher_lp/",
    "/tmp/mc_live.stderr",
    "/tmp/mc_live2.stderr",
    "/tmp/mclaunch_live.stderr",
    "/tmp/lch.png",
    "/tmp/win_0x1200001.png",
    "/tmp/win_0xc00001.png"
  ],
  "answer_summary": "Mastercam's UI opens only as far as real licence-error dialogs. Under Wine the app never builds its main window / 'Checking license...' splash / activation prompt because the CodeMeter-based licence check can never see a licence (documented kernel-level gap). Nothing further is fixable by a Wine patch on this path."
}