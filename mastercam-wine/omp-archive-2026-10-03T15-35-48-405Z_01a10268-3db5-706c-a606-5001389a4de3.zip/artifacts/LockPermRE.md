{
  "doc": "/home/user/projects/mastercam-wine/docs/ISLOCKPERMISSIONS_RE.md",
  "wine_symbol": "CLSID_PSDispatch 00020420-0000-0000-c000-000000000046 factory (oleaut32 DllGetClassObject; oleaut.c:1182/1209; oleaut32_ocidl.idl:56)",
  "return_site": "combase.c com_get_class_object E_NOINTERFACE, via marshal.c get_ps_clsid/marshal_object 855-907",
  "why": "64-bit registry view lacked HKCR CLSID 00020420; only Wow6432Node had it; 64-bit ISBEW64.exe could not marshal IID_IDispatch; CA QueryInterface got 0x80004002",
  "fix": "A: built-in fallback in com_get_class_object for CLSCTX_PS_DLL Automation PS CLSIDs. B: register oleaut32 PS coclasses in both regviews at prefix creation. Immediate: ensure 64-bit view key exists (wineboot -u); key present since 11:22:19",
  "evidence": "trace logs/exp/mcinstall/winedbg_min_trace.log lines 32401-33064; winedbg_patched.log; decompiled FUN_10009930/10003760/10002c30; sha256 dll 9f6088540e20d8e180eb7d40505ac4c2202b704966208a3cd4bc1dc4b47bb25d"
}