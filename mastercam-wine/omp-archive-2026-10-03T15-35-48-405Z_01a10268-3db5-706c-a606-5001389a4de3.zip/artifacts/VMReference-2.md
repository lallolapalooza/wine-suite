{
  "status": "complete",
  "headline": "Mastercam 2027 is INSTALLED in the win11 guest, its UI is reachable, and the whole install flow + first-launch licensing behaviour are captured. docs/VM_REFERENCE.md is written.",
  "install_command_line_that_worked": {
    "bootstrapper": "\"E:\\setup.exe\"  (run elevated, working dir E:\\) — the vendor MFC bootstrapper drives everything",
    "vendor_msiexec_pattern_caught_verbatim_on_the_updater_stage": "msiexec.exe /i \"C:\\Users\\adsf\\AppData\\Local\\Downloaded Installations\\{77E84394-2DEA-47B8-8E1D-064095FCF0DD}\\Mastercam_Installer.msi\" REBOOT=ReallySuppress /L*V <log> /qn TRANSFORMS=\"...\\1033.MST\" SETUPEXEDIR=\"E:\\support\\updater\" SETUPEXENAME=\"mastercam2027-updater.exe\" IS_RUNTIME_FILES_LOCATION=\"...\"",
    "how_the_media_reached_the_guest": "not the 2 GB SFX (C: had only 5.45 GB free, and the SFX would need 2.0 GB + 2.3 GB temp extract). Used an ISO of the extracted payload: xorriso -as mkisofs -V MCMEDIA -J -R -o state/mc_media.iso /run/media/user/Windows/mastercam-media ; virsh attach-disk win11 state/mc_media.iso sdd --type cdrom --mode readonly --live --targetbus usb  (guest sees E:). Detached again after the install (sdc solidedge untouched).",
    "equivalent_unattended_line_for_wine": "msiexec /i \"<media>\\mastercam\\Mastercam_Installer.msi\" TRANSFORMS=\"<media>\\mastercam\\1033.mst\" INSTALLDIR=\"C:\\Program Files\\Mastercam 2027\" /qn /norestart /l*v C:\\vm_msi.log  [INFERENCE — derived from the measured installer behaviour; the bootstrapper calls the MSI API internally]"
  },
  "install_result": {
    "setup_complete_page": "4/4 products 'Installed.': Licensing Utilities, Mastercam 2027, Updater, English Language Pack",
    "install_root": "C:\\Program Files\\Mastercam 2027  — 10,908 files, 3,649.0 MB (matches the MSI File table reconstruction 3,105 MB + language pack), full listing logs/vm/vm_tree_Program_Files_Mastercam_2027.txt",
    "common_files": "C:\\Program Files\\Common Files\\Mastercam — 709 files, 127.6 MB",
    "top_level_dirs": "apps, chooks, common, crashservice, documentation, en, Extensions, 'glf fonts', help, importexport, ManagedUI, simulator",
    "main_exes": [
      "C:\\Program Files\\Mastercam 2027\\Mastercam.exe  FileVersion 29.0.0.0 / ProductVersion 22.0 / 'Mastercam 2027'",
      "C:\\Program Files\\Mastercam 2027\\MastercamLauncher.exe  29.0.0.0 / 2027 / 'Mastercam Launcher Application'",
      "C:\\Program Files\\Common Files\\Mastercam\\McamVersionSelector.exe  29.0.0.0 / 1.2"
    ],
    "uninstall_entries": [
      "Mastercam 2027 | 29.0.10172.0 | C:\\Program Files\\Mastercam 2027\\ | \"...\\InstallShield Installation Information\\{F25E5DEF-DB04-4C91-A400-2CF4E3FC2989}\\uninstaller.exe\" -remove -runfromtemp -language:1033",
      "Mastercam Licensing Utilities | 29.0.10172.0 | MsiExec.exe /X{6FCF92EF-02B6-45BB-82CE-1C0A52F3338A}",
      "Mastercam 2027 Updater | 29.0.10172.0 | MsiExec.exe /X{1E59AE7A-09DE-41B7-97A1-32A5C7CEAEDB}",
      "Mastercam 2027 English Language Pack | 29.0.10172.0"
    ],
    "product_code": "{E3A7A159-C187-44D3-93E8-5EF961F4E0DD}",
    "shortcuts": "C:\\Users\\Public\\Desktop\\Mastercam 2027.lnk; Start Menu 'Mastercam 2027\\Mastercam 2027.lnk', 'Utilities\\Mastercam Launcher.lnk'",
    "msi_cache": "C:\\Users\\adsf\\AppData\\Local\\Downloaded Installations\\{77E84394-...}\\Mastercam_Installer.msi (1.19 GB) + 1033.MST — this is where ~1.2 GB of C: went beyond the installed bytes"
  },
  "first_launch": {
    "reachable": true,
    "processes": "two 'Mastercam' processes (UI + helper), each with a window titled 'Mastercam 2027', plus MastercamLauncher.exe",
    "windows": [
      "400x400 license splash: License number / License type / User type / Expiration date / Version: 29.0.10172.0 / '© 1983-2026 CNC Software, LLC. All Rights Reserved.' with a progress bar '**Checking license...**'",
      "modal dialog 'Mastercam 2027' (399x159): '**No Mastercam license found.  Do you have an activation code?**' with Yes (688,468) / No (771,468)"
    ],
    "note": "read via UI Automation (logs/vm/vm_mastercam_first_launch_uia.txt); the app's own windows screenshot as blank frames, so the UIA text is the reliable evidence. Not driven past the licence prompt."
  },
  "guest_free_space": {
    "before": "5.45 GB",
    "after_cleanup": "10.14 GB (freed Downloads\\ResArena.exe 1.6 GB, %TEMP%\\mcsize.txt 2.0 GB, temp)",
    "after_install": "2.34 GB",
    "after_first_launch": "1.74 GB",
    "installer_minimum": "'at least 20 GB free' — the requirements page reported 3/5 met (video + monitor + storage failed) yet allowed Next"
  },
  "prerequisites": ".NET 4.8.09221 and the **.NET 10.0.9 desktop runtime** were already present; VC++ 2022 14.50 was present. The installer did NOT complain about a missing runtime (the payload ships no .NET runtime, and ManagedUI targets net10.0). CodeMeter runtime was installed by the setup's Setup Prerequisites stage (C:\\Program Files\\CodeMeter\\Runtime).",
  "deliverables": {
    "doc": "docs/VM_REFERENCE.md (232 lines) — environment, exact commands, the working command lines, install flow table with screenshots, verbatim options page, install logs, install dir layout, main exe + versions, uninstall entries, first-launch licensing, free space ledger, 6 gotchas",
    "evidence": "evidence/vm_install/ — 247 PNGs: named pages page01_launcher, page02_sysreqs, page03_language, page04_options, page05_eula, page06..page10 progress, page12_complete, page13_after_finish, app_first_launch*, plus the full 5 s film-strip 0*.png",
    "logs": "logs/vm/ — vm_tree_*.txt (full tree+sizes), vm_ver_*.txt (exe versions), vm_uninstall_reg.txt, vm_services.txt, vm_mcim_*.log (bootstrapper), vm_Mastercam_2027_Install_*.log (8.4 MB MSI verbose), vm_Licensing_Utilities_Install_*.log (5.0 MB), vm_mastercam_first_launch_uia.txt, vm_mc_boot.log",
    "tools_added": "tools/vm/{capture.sh,vmshot.sh,ocr_click.py,uac_yes.sh,vmcmda.sh,pull_artifacts.sh} and guest scripts vmshare/vm_{mc_boot,mc_install,dump_all,uia,mcuia,children2,admin,clean,inv}.ps1"
  },
  "remaining": [
    "The guest still has AutoCAD 2027 / Power BI Desktop / Resolume Arena 7 installed (~16 GB) — Main asked for these to be uninstalled AFTER the Mastercam install; not started (no reboot attempted, per instructions).",
    "The elevated loop C:\\seref\\vm_admin.ps1 and the medium poller are still running in the guest, and state/mc_media.iso remains on the host (detached from the guest).",
    "Mastercam's own UI past the 'No Mastercam license found' prompt was not explored (it needs an activation code or a CodeMeter licence)."
  ]
}