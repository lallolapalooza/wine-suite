{
  "result": "Windows reference captured; docs/VM_REFERENCE.md written.",
  "install": {
    "worked": "E:\\ETC_EosFamily_v3.3.10.28.exe /S /noreboot, ELEVATED (tools/vm/vmcmda.sh) -> rc=0, 4m20s, 9.925->7.287 GiB",
    "failed": "same exe via non-elevated vmcmd.sh -> 'operation was canceled by the user' (unanswered UAC; NSIS requireAdministrator). Also 4 Mastercam MSIs returned rc=1603 non-elevated, rc=0 elevated.",
    "payload_in": "read-only ISO state/eosmedia.iso (1,699,997,696 B, label EOSMEDIA) built with xorriso graft-points; virsh attach-disk FAILS with 'No more available PCI slots', so attached via XML disk dev=sdd bus=usb; guest sees E:"
  },
  "housekeeping": {
    "before": "1.716 GiB free (1,842,880,512 B)",
    "after": "9.917 GiB free",
    "installed_after": "7.287 GiB",
    "handoff": "6.897 GiB (drop = sibling's 417 MB C:\\apitrace\\win_eos.log)",
    "removed": "Mastercam 2027 (3,649 MB) + Updater + Language Pack + Licensing Utilities + CodeMeter runtime + Downloaded Installations + %TEMP%; stopped CodeMeter.exe/hasplms and killed Cnc.Math.GridCompute.Server",
    "kept": "WebView2, VC++ 2022, .NET 10 desktop, .NET Framework 4.8, Edge (as instructed); Package Cache 758.7 MB untouched (belongs to kept products); one 36 MB locked temp file left",
    "unremovable": "stale Mastercam/CodeMeter uninstall entries (cleared by the elevated MSI /X re-run); AutoCAD/Resolume/PowerBI left alone (other workstreams)"
  },
  "ground_truth": {
    "roots": "C:\\Program Files\\ETC\\EosFamily\\v3 (295.8 MB), C:\\Program Files\\ETC\\Augment3d (394.8 MB), C:\\ProgramData\\ETC\\EosFamily\\v3 (968.3 MB); total 1658.8 MB / 10,744 files / 757 dirs",
    "tree": "logs/vm/vm_install_tree.txt (11,503 lines)",
    "main_exes": [
      "C:\\Program Files\\ETC\\EosFamily\\v3\\Eos\\Eos.exe 3.3.10.28 41,645,024 B sha256 41007AC5E252D0A4A7CDA9CA99E1ADD2B24343FDF0143D371AADD0B6A7EFFA8A",
      "C:\\Program Files\\ETC\\EosFamily\\v3\\ETC_Launch\\ETC_LaunchOffline.exe 3.3.10.28 11,316,696 B sha256 463979AEF93E5AFF3640C84B2B9F5E3A59C451DE73D507E483935D32B8694552",
      "C:\\Program Files\\ETC\\Augment3d\\augment3d_app.exe 1.4.10.3",
      "C:\\Program Files\\ETC\\Augment3d\\augment3d_engine.exe 1.4.10.3"
    ],
    "note": "ETC_Launch.exe (console Shell feature) is NOT installed: MSI Condition raises ShellOffline when NOT IS_CONSOLE; product renamed to 'ETCnomad Eos Application v3'",
    "uninstall_entries": [
      "Eos Family ETCnomad Software 3.3.10.28 (NSIS bundle, key 27024dc9-1a70-41ec-954c-6017cabe9d83)",
      "ETCnomad Eos Application v3 {F4DF9106-8D55-4CFB-83D4-A6C992E1D1BB}",
      "Augment3d 1.4.10.3 {5BAB341A-E50E-4D25-AD9D-2E9D3019E759}",
      "ETC USB Device Drivers 2.0.7",
      "ETC SLP 3.0.0.22"
    ],
    "services": "no Eos service; slpd (Service Location Protocol) Running/Auto from C:\\Windows\\SysWOW64\\slpd.exe; hasplms (Sentinel LDK) Auto/Stopped; no Winlogon\\Shell rewrite",
    "firewall": "Eos TCP-in/UDP-in + 4 Augment3d rules",
    "shortcuts": "Start Menu ETC\\Eos Family v3\\Launch Eos Family v3.lnk and Public Desktop copy -> ETC_LaunchOffline.exe (wd ...\\v3\\ETC_Launch)"
  },
  "no_licence": {
    "asks_for_key": false,
    "flow": "ETC_LaunchOffline.exe -> 'Please select your console mode' (Eos/Element buttons) -> launcher panel (Offline w/viz, Backup DISABLED, Mirror, Offline, Augment3d Tether, Settings) -> 'Offline' -> Eos.exe",
    "state": "ETCnomad, MultiConsole Mode=Offline, UserID=1, Device Status Offline, [EOS] OfflineOutputEnable=0, [LocalDMX] ClientOutput=0; no demo/activation dialog anywhere",
    "works": "complete offline editor: (untitled) show, Live/Table/2PSD/Patch tabs, full command line softkeys, Preview/Fader/Offset, Cue/Loop/Curve/Rate, LIVE/Offline status",
    "screenshots": "evidence/vm_shell_select_console_mode.png, vm_shell_launcher.png, vm_after_eos_mode.png, vm_eos_editor_01.png, vm_eos_editor_status.png",
    "stall": "Eos.exe unresponsive at +10 s; app logs 'recovered from hang after 10.10 s' at 11:51:53.660 (~18 s after start); Responding=True at +85 s, WS ~1.05 GB. Root cause of the Wine 54 s variant: ETC SLP/slpd (UDP+TCP 427, service:acn.esta) missing in an MSI-only prefix; slp.conf/slpd.exe/slptool.exe pulled to vmshare for the peer. No SLPReg() failure on Windows.",
    "gpu": "QXL-only was NOT a blocker; no GPU dialog"
  },
  "evidence": {
    "screenshots": "evidence/*.png (13) incl. vm_uac_eos_install.png (UAC prompt), vm_installer_gui_close_apps.png (interactive installer's 'close ETCnomad Shell/Eos' dialog), plus 2 filmstrip dirs",
    "logs": "logs/vm/: vm_install_tree.txt, vm_install_registry.txt, vm_install_facts.txt, vm_etc_tree_user.txt, vm_OnyxConsole.log, vm_NetworkFeedback.log, vm_eos.ini, vm_uia.txt, vm_windows.txt, vm_winprobe.txt, nsis_installer_strings.txt, eos_exe_strings.txt, msi_*.txt, aug3d_*.txt, payload_sha256.txt"
  },
  "handoff": {
    "guest": "win11 left with Eos 3.3.10.28 installed, no Eos/ETC/Augment/apitrace process running, installer processes killed, ISO still attached as sdd (state/tmp/eosmedia-disk.xml to detach)",
    "peers": "EosApiDiff: handed the guest GO for the apitrace run + supplied slp.conf.win/slpd.exe/slptool.exe and port-427 evidence; EosDeadlockRE: answered the (a)/(b)/(c) verdict. Both are producing docs/API_DIFF.md and docs/EOS_STALL_RE.md.",
    "gotchas_for_repro": [
      "default vmcmd.sh channel is NOT elevated - use vmcmda.sh for installers/msiexec/process-kill",
      "virsh attach-disk fails (No more available PCI slots); attach XML with bus='usb'",
      "interactive installer re-run is a dead end ('close ETCnomad Shell/Eos' even when not running) - always use /S",
      "shell + Eos windows are created BEHIND the console window, so screenshots need SetWindowPos(HWND_TOPMOST) or minimising the console"
    ]
  }
}