{
  "status": "done",
  "verdict": "Patch written and validated. NotifyIpInterfaceChange and NotifyUnicastIpAddressChange now deliver real change callbacks with usable handles, and CancelMibChangeNotify2 unregisters. One deliberate simplification is labelled in the patch (interface-table changes without an accompanying address-table change are detected by a 1 s periodic re-check, since Wine's NSI/nsiproxy has no interface-table change source).",
  "deliverables": {
    "patch": "patches/local/0102-iphlpapi-notify-interface-changes.patch",
    "patch_size_bytes": 19566,
    "touched_files": [
      "dlls/iphlpapi/iphlpapi_main.c"
    ],
    "diffstat": "+400 -11 in dlls/iphlpapi/iphlpapi_main.c (4 hunks: include, new machinery, NotifyIpInterfaceChange, NotifyUnicastIpAddressChange; CancelMibChangeNotify2 lands inside the new-machinery hunk)",
    "doc": "docs/IPHLPAPI_NOTIFY.md (single-paragraph note: what changes, what Windows did that Wine did not, how to verify)"
  },
  "what_it_does": {
    "notify_interface": "Worker thread per registration keeps an async NsiRequestChangeNotification() on NSI_IP_UNICAST_TABLE armed (IPv4 / IPv6 / both for AF_UNSPEC), re-enumerates GetIpInterfaceTable() on each wake plus a 1 s timeout, diffs against the previous snapshot and calls the callback with MibAddInstance / MibDeleteInstance / MibParameterNotification (row pointer, incomplete key fields as Windows documents).",
    "notify_unicast": "Same machinery with GetUnicastIpAddressTable(); key match on (family, address, luid).",
    "initial_notification": "Delivered synchronously before the worker starts, with a NULL row and MibInitialNotification, exactly matching MSDN and the in-tree Wine test.",
    "cancel": "CancelMibChangeNotify2 stops the thread (SetEvent + join), the thread cancels and drains its pending NSI IRPs, then the registration is freed; the handle is an opaque per-registration pointer so CloseHandle() on it fails, as Windows/the Wine test expect.",
    "params": "family must be AF_INET / AF_INET6 / AF_UNSPEC and callback/out-handle non-NULL, else ERROR_INVALID_PARAMETER; allocation failure -> ERROR_NOT_ENOUGH_MEMORY."
  },
  "why_nsi_alone_is_not_enough": "nsiproxy's Linux poll_events() binds netlink with RTMGRP_IPV4_IFADDR|RTMGRP_IPV6_IFADDR and only queues NSI_IP_UNICAST_TABLE notifications for RTM_NEWADDR/RTM_DELADDR, so the NSI plumbing has no notification source for the interface table. The patch therefore combines NSI (address changes, immediate) with a periodic re-check (interface link/MTU/param changes) and labels this a deliberate simplification in the patch message.",
  "validation_performed": {
    "dry_run_on_base": "Fresh state/tmp copy of pristine wine-11.18 + all patches/series (0001-0019) + patches/local/0100,0101, then `patch -p1 --dry-run -i patches/local/0102-...` -> 'checking file dlls/iphlpapi/iphlpapi_main.c', exit 0, no fuzz/offset.",
    "full_series_apply": "Second fresh pristine extraction, `tools/apply_patches.sh <tree>` (which now picks up 0102 after 0101): all 0001-0019 + 0100 + 0101 + 0102 report OK.",
    "patch_also_applies_on_pristine": "`patch -p1 --dry-run` on the bare pristine tree is also clean (no other patch touches dlls/iphlpapi/iphlpapi_main.c, so the base state is pristine).",
    "syntax_check": "`-fsyntax-only` with the build tree's real compile commands for both i686-w64-mingw32-gcc and x86_64-w64-mingw32-gcc against the patched file: no errors, no warnings. (Built objects were never overwritten.)",
    "no_live_tree_edits": "All editing/dry-runs happened in throwaway state/tmp copies, which were removed afterwards; wine-11.18 and wine/wine-11.18 were not modified."
  },
  "checks_main_agent_should_run": [
    "Re-run `tools/apply_patches.sh <build-tree>` (or the project's normal build) and confirm 0102 stays OK.",
    "Rebuild Wine (this patch does not require it, but it is a native DLL change) and run Wine's iphlpapi tests: test_NotifyUnicastIpAddressChange must still pass (initial callback, CancelMibChangeNotify2 -> NO_ERROR, CloseHandle(handle) -> FALSE).",
    "Run Eos and confirm the two former `fixme:iphlpapi:NotifyIpInterfaceChange ... stub` / `...NotifyUnicastIpAddressChange ... semi-stub` lines are gone and both calls return a non-NULL handle; add/remove an address on a host interface during the run and confirm the app's callback fires.",
    "Measure the start-up transient: expectation is that the ~54 s `recovered from hang` window drops toward the Windows ~10 s. NOTE: reaching ~10 s also requires the bundle's slpd SLP service in the prefix (docs/API_DIFF.md 6.1; agent EosApiDiff is working that), so judge this patch's own contribution by the handle/callback log lines as well as the timing."
  ],
  "caveats": [
    "The interface-change callback path is materially correct but the notification is only immediate when the change also touches the unicast address table; pure link-state/MTU changes wait up to 1 s for the poll. This is stated in both the patch message and the doc.",
    "NotifyRouteChange2 remains a stub (explicitly out of scope)."
  ]
}