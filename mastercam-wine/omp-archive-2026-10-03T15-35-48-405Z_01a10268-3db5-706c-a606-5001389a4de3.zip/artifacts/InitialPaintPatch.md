{
  "status": "complete",
  "deliverables": {
    "patch": "patches/local/0103-win32u-initial-client-paint.patch",
    "doc": "docs/INITIAL_PAINT_PATCH.md",
    "also_updated": "patches/README.md (added a 0103 row + section header local/0100..0103)"
  },
  "what_changed": {
    "file": "dlls/win32u/window.c, function set_window_pos()",
    "diff": [
      "added local `BOOL need_update = FALSE;`",
      "in the existing \"Give newly shown windows a chance to redraw\" block (the same condition that already guards erase_now(), i.e. a genuine hidden->visible transition; fixup_swp_flags() clears SWP_SHOWWINDOW when the window is already visible) set `need_update = TRUE` after erase_now()",
      "after the WM_WINDOWPOSCHANGED send, if need_update: `NtUserRedrawWindow( winpos->hwnd, NULL, NULL, RDW_INVALIDATE | RDW_ERASE | RDW_UPDATENOW )`"
    ],
    "scope": "only the window being shown, no RDW_ALLCHILDREN; only on the visibility transition, not a blanket redraw"
  },
  "root_cause": {
    "verdict": "The RE agent's residual question (queue->paint_count vs find_window_to_repaint) is resolved as *neither*: the server's WM_PAINT branch is never reached because the server only synthesises WM_PAINT when the thread's queue is otherwise empty, and the monitor's queue never drains. So no amount of (re-)invalidation can produce the queued WM_PAINT for this app.",
    "evidence": [
      "dlls/win32u/window.c set_window_pos() only called erase_now() for a newly shown window -> the measured WM_NCPAINT/WM_ERASEBKGND come from there; the client paint was left to the queued WM_PAINT.",
      "server/queue.c DECL_HANDLER(get_message): the WM_PAINT branch is after sent/posted/hotkey/quit/hardware, so WM_PAINT is only produced when the queue is otherwise empty (same priority as Windows).",
      "logs/api/monpeek.relay.log: the monitor GUI thread's outer PeekMessageW(&msg,NULL,0,0,PM_REMOVE) returned a message 3407 times and 0 (empty) zero times (the one retval=0 in the file belongs to another 64-bit process at startup). Hence get_message never reached the paint branch.",
      "Windows win_mon.log: BeginPaint immediately after ShowWindow (delivered through the loop while its queue drained), which Wine's never-draining queue prevents."
    ]
  },
  "why_not_invalidate_only": "The ticket's suggested invalidation-only fix cannot paint the Processor window: the report itself shows RedrawWindow(RDW_INVALIDATE) leaves the region pending and still produces no WM_PAINT, and §root_cause explains why. The fix therefore both invalidates the client area (matches 'a newly shown window is fully invalid') and forces the first paint as part of the show, as Windows observably does.",
  "validation": {
    "dry_run": "clean (rc=0) on a fresh state/tmp copy of the current patched base (wine-11.18 = pristine + patches/series/* + patches/local/*); also clean in a single-file copy, and reverse dry-run clean",
    "apply_check": "applying the final patch file for real in the scratch copy reproduces the intended window.c byte-for-byte",
    "syntax": "no compile performed (a build is in progress and live trees must not be modified); the inserted call uses NtUserRedrawWindow with RDW_INVALIDATE|RDW_ERASE|RDW_UPDATENOW, a combination already used in the same file (window.c:5257) and in defwnd.c, and `need_update` is a fresh local",
    "not_done": "Wine's test suite was not built/run"
  },
  "watch_for_when_testing": [
    "Reentrancy: WM_PAINT is now sent from inside SetWindowPos/ShowWindow (the same place Wine already sends WM_NCPAINT/WM_ERASEBKGND/WM_WINDOWPOSCHANGED, and where Windows paints a newly shown window), so a wndproc that assumes no WM_PAINT until the message loop runs could misbehave; watch QWindowsWindow::handleWmPaint for asserts.",
    "CreateWindowEx(WS_VISIBLE) goes through the same block during creation; if a class misbehaves there, restrict the new call to windows that already existed.",
    "erase_now() then BeginPaint may each send WM_ERASEBKGND (double background fill) on the show transition - harmless but extra work.",
    "The synchronous paint validates the region, so no queued WM_PAINT should follow; a window proc that ignores WM_PAINT may still get the queued one later (normal Win32 contract).",
    "If the aim is strictly to keep the queued path and only invalidate, note that the evidence above says that alone does not paint this window."
  ],
  "artifacts_for_repro": [
    "docs/MONITOR_RENDER_RE.md (defect + Windows reference)",
    "logs/api/monpeek.relay.log (queue never empty)",
    "logs/api/win_mon.log (Windows BeginPaint after ShowWindow)",
    "tools/winenum/showpaint3.exe (minimal app check)"
  ]
}