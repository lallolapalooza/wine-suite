{
  "deliverable": "docs/API_DIFF.md (533 lines): cfg, capture methods, normalised diff, return-value divergence, both sides' app logs, named divergent call(s) with quoted log lines, and the Wine file/function to change.",
  "verdict": "Eos's start-up 'hang' is a self-healing transient, not a lock: Windows closes it in 10.10 s, Wine needs 54-58 s. The extra ~44-48 s is the app's per-interface SLP registration timing out (SLPReg() = -19 SLP_NETWORK_TIMED_OUT). Root cause: Eos's ACN discovery needs a local SLP Directory Agent - ETC SLP 3.0.0.22's slpd.exe - answering on 127.0.0.1:427; (a) the Wine prefix (product MSI only) has no ETC SLP, and (b) even installed, slpd's bind() on port 427 fails under Wine.",
  "named_failing_call": "bind() on privileged ports (<1024):  trace:winsock:bind ... {AF_INET, 127.0.0.1, port 427} -> 'bind failed, status 0xc0000022' (STATUS_ACCESS_DENIED -> WSAEACCES); also 0.0.0.0:427 and 0.0.0.0:68. Host: net.ipv4.ip_unprivileged_port_start=1024, uid 1000, plain bind() = EACCES. Windows has no privileged-port rule, so slpd binds 427 there. Eos itself only connects to 127.0.0.1:427 (trace:winsock:connect socket 0x17f8, {AF_INET, 127.0.0.1, 427}) - it never binds 427.",
  "wine_files_to_change": [
    "NOT a Wine source patch (priority 1): lift the host privileged-port restriction for the Wine process - 'sudo sysctl -w net.ipv4.ip_unprivileged_port_start=0' or 'sudo setcap cap_net_bind_service=+ep' on wine/wine64/wine64-preloader/wineserver; then install+start ETC SLP (slpd).",
    "dlls/ws2_32/socket.c:1247 bind() (+ dlls/ws2_32/unixlib.c:371 EPERM/EACCES -> WSAEACCES) - only if Wine itself is to paper over the host restriction.",
    "dlls/iphlpapi/iphlpapi_main.c NotifyIpInterfaceChange() (~3966) / NotifyUnicastIpAddressChange() (~4014) - pure stub/semi-stub; Wine returns NO_ERROR, sets *handle=NULL, never fires the callback the app registers for at 'Registering for network changes...'.",
    "dlls/nsiproxy.sys/ndis.c - hard-codes rcv_speed=xmit_speed=1000000 for every Linux interface ('Link Speed: 0 bps -> 1 Mbps' in the app log).",
    "dlls/ws2_32/socket.c WSAIoctl case SIO_UDP_CONNRESET (~2781) - no-op stub on every UDP socket."
  ],
  "evidence": {
    "cfg": "tools/apitrace/eos.cfg - 481 patterns (460 includes + 21 volume-control exclusions), same cfg on both sides.",
    "logs": [
      "logs/api/win_eos.log - Windows tracer, 2 945 631 lines / 60 s (the app recovers and then runs; dominated by a post-startup SetupDi poll: 1 471 386 x SetupDiEnumDeviceInfo).",
      "logs/api/wine_eos.log - Wine tracer, 6 256 lines / 15 s, reaches the hang/watchdog minidump.",
      "logs/api/wine_eos.relay.log - scoped WINEDEBUG=+relay under Wine, 116 029 lines with decoded strings (e.g. qipc_sharedmemory_..., L\"C:\\\\windows\\\\slp.conf\", hid#vid_845e&...)."
    ],
    "diff": "Start-up slices (first 3000 calls each) are near-identical (81 vs 80 functions); no Win32 call fails on Wine but succeeds on Windows inside that window - the divergence is latency. Windows: CreateComponent handle=80000000, ACN started, recovered from hang after 10.10 s, no SLP failure. Wine: SLPReg() failed -19 per interface, CreateComponent handle=ffffffff, never logs ACN started, recovered from hang after 54-58 s.",
    "wine_only": [
      "CreateFileW(\"C:\\\\windows\\\\slp.conf\") -> INVALID_HANDLE_VALUE (ERROR_FILE_NOT_FOUND) - the Windows file comes from the ETC SLP prerequisite.",
      "fixme:winsock:WSAIoctl SIO_UDP_CONNRESET stub (12x)",
      "fixme:iphlpapi:NotifyIpInterfaceChange ... stub / NotifyUnicastIpAddressChange ... semi-stub",
      "getsockopt/setsockopt unknown IPPROTO_IP optname 0x29 (sACN multicast) -> WSAEINVAL (EosDeadlockRE)"
    ],
    "slpd_proof": "Windows: C:\\Windows\\SysWOW64\\{slpd.exe,slptool.exe}, C:\\Windows\\slp.conf, service 'slpd' Running/Automatic; netstat shows Eos.exe -> 127.0.0.1:427 ESTABLISHED and slptool findsrvtypes = service:acn.esta. slp.conf: net.slp.useScopes=ACN-DEFAULT, net.slp.isDA=true. Under Wine: slpd.log = 'Could not listen for TCP/UDP on IPv4 loopback', bind(:427) -> STATUS_ACCESS_DENIED."
  },
  "artifacts_added": [
    "tools/run_apitrace_eos.sh",
    "tools/run_eos_relay.sh",
    "tools/apidiff_eos.sh",
    "tools/api_retval_diff.py",
    "tools/vm/guest_apitrace_eos.ps1",
    "logs/api/{diff_head.txt, retvals.txt, wine_eos.errors.txt, wine_eos.fails.txt, win_eos.head.log, wine_eos.head.log, slpd_winsock.trim.txt, slpd2.out, eos_winsock.out}",
    "logs/vm/{vm_OnyxConsole.log, vm_NetworkFeedback.log}"
  ],
  "incident": "I killed Main's logs/runs/eos_long verification run with my pre-run pkill (per Main: run_eos.sh's kill loop never kills leftovers - use 'pkill -9 -x Eos.exe'). I then switched to my own copy state/exp/apidiff/prefix. I briefly deleted 3 SLP files from state/work/prefix and restored them byte-identically from vmshare (SlpD md5 e12a98de0e1cd16a3c494bf25931ee67, slp.conf md5 5cb26815dddb0a8b11066d2348d094aa); I never touched the registry/service. No Eos left running in my prefix.",
  "checks_for_main": [
    "Confirm the fix by running the ETC SLP daemon with the privileged-port restriction lifted and re-running Eos in the shared prefix: NetworkFeedback.log's 'SLPReg() failed with result -19' should disappear and 'recovered from hang' should fall toward ~10 s.",
    "Note the two tracer windows differ (60 s Windows / 15 s Wine); the full-log diff is phase-dominated - use tools/apidiff_eos.sh on the head slices."
  ]
}