{
  "verdict": "Cause (a): the Processor window never receives a paint/expose under Wine. Wine-fixable.",
  "doc": "docs/MONITOR_RENDER_RE.md (226 lines) on disk; tools/winenum/winenum.c + showpaint3.c; logs/runs/mon1..mon12, logs/api/monrelay*.relay.log, monpeek.relay.log, mon4/dbg.log, win_mon.log, logs/vm/win_mon_status.txt",
  "reproduced": "Window `Processor` = Qt5151QWindow, 770x370, style 0x96000000, IsViewable, unoccluded; contents 100% white (root histogram only #000000 + one 770x370 #FFFFFF; evidence/hog_processor_wine.png = 2-colour 436-byte PNG; OCR empty). Windows same window: vis=True, class Qt5151QWindow, renders 'Show Server IP: No Server / Hog Net IP / Fixture Net IP / Port Number: 6600 / Software Version: v5.2.1 (b 31) / Offline'.",
  "cause_evidence": [
    "Wine scoped +relay of hwnd 0x10074 lists the whole window-proc stream: WM_NCCREATE WM_NCCALCSIZE WM_CREATE WM_SIZE WM_MOVE WM_WINDOWPOSCHANGING WM_WINDOWPOSCHANGED WM_SETICON WM_SETTEXT WM_SHOWWINDOW WM_QUERYNEWPALETTE WM_ACTIVATEAPP WM_NCACTIVATE WM_ACTIVATE WM_IME_SETCONTEXT WM_SETFOCUS WM_NCPAINT WM_ERASEBKGND - and NO WM_PAINT ever (30 s capture).",
    "Wine counts: BeginPaint 0, EndPaint 0, GetUpdateRect 0, InvalidateRect 0, UpdateWindow 0, RedrawWindow 0, ValidateRect 0. Windows same exe/argv: BeginPaint 1 (seq 2087 hwnd 0x870442) + EndPaint 1 (seq 2632).",
    "+win,+msg of the monitor: `grep -c WM_PAINT dbg.log` = 0; the only messages dequeued for 0x10074 are WM_WINE_WINDOW_STATE_CHANGED/WM_WINE_SETCURSOR.",
    "The window is a legitimate paint target: winenum.exe (built in-tree) - GetUpdateRgn(hwnd,rgn,FALSE) returns SIMPLEREGION box=(0,0)-(770,370) (whole client) continuously every 250 ms while the app pumps PeekMessage(&msg,0,0,0,PM_REMOVE) (relay-confirmed args); Visible=1, WS_VISIBLE set, ValidateRect(NULL) does clear it (so Wine's server considers it visible), RedrawWindow(RDW_INVALIDATE) re-invalidates it, still no queued WM_PAINT.",
    "The app itself is fine: PostMessage(hwnd,WM_PAINT,0,0) and RedrawWindow(RDW_INVALIDATE|RDW_UPDATENOW|RDW_ERASE|RDW_ALLCHILDREN) both paint the complete UI immediately (histogram gains #333333/#5A5A5A/...). Only the *synchronous* paths reach Qt; the *queued* path never does.",
    "Not (b)/(c)/(d): the window is a raster QWindowsWindow (GCL_STYLE=0x8=CS_DBLCLKS, COLOR_WINDOW brush, class name has no OwnDC suffix); all pixel-format/wgl probe calls succeed; no err:/fixme: explains it; the app is not blocked (polls ~44x/s) and paints instantly when handed a paint."
  ],
  "wine_files": [
    "server/queue.c - DECL_HANDLER(get_message), 'now check for WM_PAINT' branch (queue->paint_count && check_msg_filter(WM_PAINT,...) && find_window_to_repaint(get_win, current)) - the message that is never produced",
    "server/window.c - find_window_to_repaint() / find_child_to_repaint() / win_needs_repaint() (win->update_region || PAINT_INTERNAL) - selection",
    "dlls/win32u/window.c - set_window_pos(), 'Give newly shown windows a chance to redraw' block (~line 4197, erase_now(winpos->hwnd,0)) - emits only WM_NCPAINT/WM_ERASEBKGND, does not invalidate the client area",
    "dlls/win32u/dce.c - redraw_window()/set_update_region()/erase_now() and the synchronous counterparts update_now()/NtUserUpdateWindow() that DO work"
  ],
  "same_as_powerbi_gap": "No - different defect, same family. The Power BI gap is an already-painted window that is occluded then uncovered and never re-damaged (no compositor/DWM). Here the window was never painted once, is freshly shown and unoccluded (a full-body GetUpdateRgn proves the region is not cropped), and the missing message is the initial WM_PAINT Windows generates for any newly shown window. Both are Wine's window-damage/paint scheduling being incomplete and both leave a Hog Qt surface showing the COLOR_WINDOW white.",
  "residual_uncertainty": "The exact server bookkeeping fault (queue->paint_count, or find_window_to_repaint() returning NULL, given the region is known non-empty and the window known visible on the desktop with the sampling thread owning it) could not be isolated without adding traces to Wine; the project forbids rebuilding Wine. The minimal native repro tools/winenum/showpaint3.c (identical owner/popup/style/ShowWindow sequence) does get its WM_PAINT on this Wine, so the trigger is some per-process state of the monitor, not the window shape - the doc's table names exactly where to put the trace once a patch is attempted.",
  "files_changed": [
    "docs/MONITOR_RENDER_RE.md (new)",
    "tools/apitrace/monitor.cfg (new)",
    "tools/winenum/winenum.c + winenum.exe, showpaint3.c + showpaint3.exe (new)",
    "tools/vm/guest_monitor_hog.ps1 (new)"
  ],
  "cleanup": "No Hog/wine processes left running; superseded probes (showpaint.c, showpaint2.c, qprobe.c) deleted."
}