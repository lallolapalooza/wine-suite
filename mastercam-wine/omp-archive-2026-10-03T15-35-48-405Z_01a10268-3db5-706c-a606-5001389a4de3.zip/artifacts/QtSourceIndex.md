{
  "status": "complete",
  "acceptance": {
    "doc": "/home/user/projects/hog-wine/docs/QT_CHROMIUM_SOURCE.md (2399 lines)",
    "contains": [
      "§1 where sources live on disk",
      "§2.2 curated + §2.5 full Win32→Qt file:line→expectation table (820 APIs)",
      "§3 Wine cross-check with .spec evidence + body-level FIXME stubs (23)",
      "§4.1 Chromium single-file fetch recipe (verified, with the 429/trailing-slash gotchas)",
      "§4.2/4.3 Chromium Win32 surface (562 APIs from 203 files) + Wine status",
      "§5 how-to-use playbook when a trace shows a failing call"
    ]
  },
  "artifacts": {
    "doc": "docs/QT_CHROMIUM_SOURCE.md",
    "tools": [
      "tools/qt_win32_index.py",
      "tools/chromium_win32_index.py",
      "tools/wine_impl_audit.py",
      "tools/assemble_doc.py (marker-based, idempotent doc build)"
    ],
    "generated_data": [
      "docs/_qt_win32_index.json",
      "docs/_qt_win32_table.md",
      "docs/_qt_win32_stubs.tsv",
      "docs/_chromium_win32_index.json",
      "docs/_chromium_win32_table.md",
      "docs/_wine_impl_audit_all.tsv"
    ],
    "sources_on_disk": {
      "qtbase_5_15_1": "/run/media/user/Windows/qt-src/qtbase (303 MiB, MODULE_VERSION=5.15.1)",
      "winapi_rs_0_3_9": "/run/media/user/Windows/qt-src/winapi/winapi-0.3.9 (canonical per-DLL Win32 name list)",
      "chromium_80_0_3987_163": "/run/media/user/Windows/chromium-src (549 files cached, _paths.txt + _listings/ for re-runs, _listings/)"
    }
  },
  "counts": {
    "qt_apis_indexed": 820,
    "qt_files_scanned": 386,
    "qt_wine_status": {
      "impl": 433,
      "forward": 371,
      "not-an-export": 15,
      "absent": 1,
      "stub": 0
    },
    "qt_dynamic_resolve": {
      "apis_with_dynamic_site": 82,
      "dynamic_only": 38
    },
    "chromium_apis_indexed": 562,
    "chromium_files": 203,
    "chromium_wine_status": {
      "impl": 308,
      "forward": 246,
      "absent": 5,
      "not-an-export": 3
    },
    "wine_body_only_stubs": 23,
    "wine_body_only_real_gaps": 19
  },
  "stubbed_apis": {
    "spec_level_missing_named_export": [
      {
        "api": "user32!SkipPointerFrameMessages",
        "evidence": "dlls/user32/user32.spec:1142 is commented out (# @ stub SkipPointerFrameMessages)",
        "caller": "qtbase src/plugins/platforms/windows/qwindowscontext.cpp:211 (dynamic resolve; NULL-checked, degrades)",
        "kind": "candidate_wine_patch"
      },
      {
        "api": "userenv!DeriveAppContainerSidFromAppContainerName",
        "evidence": "no spec entry anywhere in wine-11.18/dlls",
        "caller": "sandbox/win/src/app_container_profile_base.cc:23 (GetProcAddress)"
      },
      {
        "api": "userenv!DeleteAppContainerProfile",
        "evidence": "no spec entry",
        "caller": "app_container_profile_base.cc:26"
      },
      {
        "api": "userenv!GetAppContainerFolderPath",
        "evidence": "no spec entry",
        "caller": "app_container_profile_base.cc:28"
      },
      {
        "api": "userenv!GetAppContainerRegistryLocation",
        "evidence": "no spec entry",
        "caller": "app_container_profile_base.cc:31"
      },
      {
        "api": "kernel32!GetThreadInformation",
        "evidence": "no spec entry (Win10 1607+)",
        "caller": "base/threading/platform_thread_win.cc:197 (DCHECK-only, NULL-checked; cosmetic in release)"
      }
    ],
    "body_only_fixme_stubs_qt_surface": [
      "crypt32!CertFindChainInStore (chain.c:3002, returns NULL; hit by qsslsocket_schannel.cpp:661)",
      "user32!ChangeWindowMessageFilterEx (message.c:1215)",
      "d3d9!D3DPERF_GetStatus (d3d9_main.c:244)",
      "d3d9!D3DPERF_SetMarker (d3d9_main.c:271)",
      "dcomp!DCompositionCreateDevice (device.c:28, E_NOTIMPL)",
      "dwmapi!DwmEnableBlurBehindWindow (dwmapi_main.c:163, E_NOTIMPL)",
      "imm32!ImmReleaseContext (imm.c:2350, TRACE-only no-op - acceptable)",
      "user32!IsTouchWindow (input.c:667)",
      "netapi32!NetShareEnum (netapi32.c:388)",
      "user32!RegisterTouchWindow (input.c:676)",
      "user32!SetDisplayAutoRotationPreferences (sysparams.c:1009)",
      "shell32!Shell_NotifyIconGetRect (systray.c:299, E_NOTIMPL; tray geometry)",
      "uiautomationcore!UiaClientsAreListening (uia_main.c:265, acceptable)",
      "uiautomationcore!UiaRaiseAutomationPropertyChangedEvent (uia_main.c:304)",
      "uiautomationcore!UiaRaiseNotificationEvent (uia_main.c:343)",
      "user32!UnregisterPowerSettingNotification (misc.c:419)",
      "user32!UnregisterTouchWindow (input.c:685)"
    ],
    "body_only_fixme_stubs_chromium_surface": [
      "userenv!CreateAppContainerProfile (userenv_main.c:690, returns E_NOTIMPL - AppContainer sandbox degrades)",
      "user32!UserHandleGrantAccess (misc.c:401, returns TRUE but grants nothing - job-object sandbox)",
      "sechost!ProcessTrace (trace.c:134, ERROR_CALL_NOT_IMPLEMENTED - ETW)",
      "gdi32!GetColorSpace (objects.c:730, returns 0)",
      "user32!AllowSetForegroundWindow (win.c:779, return TRUE - acceptable)",
      "gdi32!GdiDllInitialize (objects.c:1092, return TRUE - acceptable)"
    ],
    "already_patched": "iphlpapi!NotifyIpInterfaceChange + NotifyUnicastIpAddressChange: wine-11.18 tree already has patches/local/0102 applied (iphlpapi_main.c:4356 uses mib_notification_register). NotifyRouteChange2 immediately below is still a FIXME stub."
  },
  "notable_findings": [
    "Shipped HogPC tree was observed to contain NO libEGL.dll / libGLESv2.dll / opengl32sw.dll / vk_swiftshader*; d3dcompiler_47.dll is present in C:\\windows\\system32. Expect NULL LoadLibraryW for the ANGLE/SwiftShader DLLs and GL fallback - not Wine bugs (marked [INFERENCE] for runtime behaviour).",
    "sqldrivers ships qsqlite only, so the indexed ODBC (odbc32, 30 APIs) paths are not reached by this installer.",
    "Chromium 80's network monitor uses the legacy NotifyAddrChange (net/base/network_change_notifier_win.cc:293, Wine implements via NsiRequestChangeNotification); qtbase 5.15.1 contains no NotifyIpInterfaceChange call at all - patch 0102 matters for other callers.",
    "Chromium 80 uses BoringSSL: zero BCrypt/NCrypt/Cert* calls in the 549 fetched files (base/crypto/net/sandbox/ui).",
    "Chromium 80's D3D11/DXGI device creation lives in ANGLE (separate repo, not fetched); Qt's bundled ANGLE (qtbase/src/3rdparty/angle) is indexed instead.",
    "Scanner bug found and fixed: lines starting with '*' (e.g. '*winsta = ::CreateWindowStationW(') were dropped as Doxygen comments; both scanners now do real /* */ and // comment stripping. This is why sandbox/win/src/window.cc's CreateWindowStationW/CreateDesktopW are now indexed.",
    "Wine -noname (ordinal-only) spec entries are excluded from the candidate set (Alloc/Free/GetSize comctl32 false positives)."
  ],
  "main_agent_checks": [
    "Open docs/QT_CHROMIUM_SOURCE.md and skim §0/§2.2/§3.2/§5.",
    "Optional: `python3 tools/assemble_doc.py` is idempotent (verified twice) - re-running must not change the file.",
    "Confirm the §1.1 GL-fallback observation against a live trace before acting on it."
  ]
}