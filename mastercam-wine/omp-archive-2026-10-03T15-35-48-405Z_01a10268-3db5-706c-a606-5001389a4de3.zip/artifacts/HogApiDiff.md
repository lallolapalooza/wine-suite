{
  "deliverable": "docs/API_DIFF.md (689 lines) — cfg, capture methods, the diff, named divergences with quoted log lines, and the Wine file/function per divergence",
  "verdict": "Hog PC's start-up diverges nowhere on Wine that stops, blocks or corrupts it. Locking of the show store is identical (1574 LockFileEx/NtLockFile pairs on Windows vs 1584 on Wine for the same show-open burst, all success on Wine). No start-up-critical call is missing in the launcher-vs-launcher diff; both sides end idle at 'Hog Start'. No stall on either side.",
  "enabler": "Hog is i386 but tools/apitrace was x86-64 only, so no Windows reference was possible. Ported the tracer: new src/hook_common32.S (i386 tail-jump trampoline) + #ifdef i386 paths in apihook.c (32-bit stub emitter, HDR32 magic, ORDINAL_FLAG32, trace_pre32, MAX_PATTERNS 512->1024) + build.sh CC/OUT; `CC=i686-w64-mingw32-gcc OUT=build32 ./build.sh`. Validated against selftest.exe under Wine (64-bit build regression-tested too). 32-bit tracer records args but not return values (tail-jump); return values come from Wine's scoped +relay.",
  "artifacts": {
    "cfg": "tools/apitrace/hog.cfg (541 patterns, 21 exclusions)",
    "wine": "logs/api/wine_hog.log (launcher 61405), wine_hog_server.log (32519), wine_hog_desktop.log (55649)",
    "wine_relay": "logs/api/wine_hog_{launcher,server}.relay.log (retvals + fixmes)",
    "windows": "logs/api/win_hog.log (launcher 5737), win_hog_server_start.log (12175, show open), win_hog_{server,desktop,critical}.log (attach)",
    "diff": "logs/api/hog_apidiff.txt from tools/hog_apidiff.sh (relaydiff diff, same-role only)",
    "scripts": [
      "tools/run_apitrace_hog.sh",
      "tools/run_hog_relay.sh",
      "tools/hog_apidiff.sh",
      "tools/vm/guest_apitrace_hog.ps1",
      "tools/vm/guest_attach_hog.ps1",
      "tools/vm/guest_server_hog.ps1"
    ]
  },
  "divergences": [
    {
      "call": "user32!RegisterPowerSettingNotification",
      "wine": "FIXME stub returns fake handle 0xdeadbeef",
      "windows": "real HPOWERNOTIFY (call present 458x on Windows launcher)",
      "patch": "dlls/user32/misc.c:410 (+win32u power path)",
      "impact": "cosmetic"
    },
    {
      "call": "user32!EnableNonClientDpiScaling",
      "wine": "FIXME + SetLastError(ERROR_CALL_NOT_IMPLEMENTED); return FALSE (measured retval=00000000)",
      "windows": "returns TRUE; Qt resolves it dynamically (qwindowscontext.cpp:217)",
      "patch": "dlls/user32/sysparams.c:785",
      "impact": "non-client DPI scaling off"
    },
    {
      "call": "newdev!DiInstallDriverA/W",
      "wine": "FIXME stub returns TRUE, installs nothing (measured retval=1)",
      "windows": "installs drivers\\gadget\\gadget.inf",
      "patch": "dlls/newdev/main.c:154",
      "impact": "hardware-only"
    },
    {
      "call": "netprofm change notifications (init_networks)",
      "wine": "initial adapter enumeration works, ConnectivityChanged never fires",
      "windows": "Qt QNetworkListManagerEvents gets async events",
      "patch": "dlls/netprofm/list.c:1844 (wire iphlpapi/NSI notifications)",
      "impact": "start-up OK; network-change reactions lost"
    },
    {
      "call": "wtsapi32!WTSQuerySessionInformationW class 4 (WTSSessionId)",
      "wine": "falls through to FIXME + FALSE",
      "windows": "returns session id; caller is QtWebEngineCore/Chromium (only non-QPA WTSAPI32 importer), not Qt (asks class 25)",
      "patch": "dlls/wtsapi32/wtsapi32.c:547",
      "impact": "caller gets FALSE"
    },
    {
      "call": "file:NtLockFile",
      "wine": "lock succeeds; only overlapped/APC completion missing; early STATUS_NOT_IMPLEMENTED not taken (apc/io_status/key are NULL from LockFileEx)",
      "patch": "dlls/ntdll/unix/file.c:7112 (cosmetic)",
      "impact": "none — show-DB locking verified working"
    },
    {
      "call": "user32!SkipPointerFrameMessages",
      "wine": "not exported (user32.spec:1142 commented stub); Qt dynamic-resolves and degrades",
      "patch": "dlls/user32/user32.spec + input.c",
      "impact": "pointer-frame degradation"
    },
    {
      "call": "14 body-level stubs from the Qt audit",
      "examples": "Shell_NotifyIconGetRect E_NOTIMPL, CertFindChainInStore NULL, CreateAppContainerProfile stub, DCompositionCreateDevice/DwmEnableBlurBehindWindow E_NOTIMPL, UiaRaise* swallowed, ChangeWindowMessageFilterEx, NetShareEnum ERROR_NOT_SUPPORTED",
      "patch": "see docs/QT_CHROMIUM_SOURCE.md 3.2 / docs/_wine_impl_audit_qt.tsv",
      "impact": "degradation paths only"
    },
    {
      "call": "FIXME-only, NOT divergences",
      "examples": "ntdll!NtQuerySystemInformation(SystemPerformanceInformation) fills the struct and succeeds; kernelbase!AppPolicyGetProcessTerminationMethod returns ERROR_SUCCESS; font get_nearest_charset/find_matching_face chatter"
    }
  ],
  "measured_nonfunctional": [
    "Wine launcher Qt event loop polls instead of blocking: PeekMessageW 13398 vs 395, QueryPerformanceCounter 6093 vs 413, AcquireSRWLockShared 6133 vs 49 over the same 70 s (latency/CPU class).",
    "Wine-only wgl* (1156 wglGetProcAddress) + DeviceIoControl 919 is environmental: the win11 guest has only the Microsoft Basic Display Adapter, so its launcher never enters the GL path."
  ],
  "caveats": [
    "Windows desktop/server logs are attach-window (steady state); the matched comparison is win_hog_server_start.log vs wine_hog_server.log, which is where the lock burst lives.",
    "Importer asymmetry: the tracer hooks all modules' IATs, so on Wine some logged calls are Wine-internal (Wine builtins import kernel32 by name; Windows system DLLs import api-ms-win-core-* API sets which the kernel32 patterns don't match). Windows-only rows are genuine app calls; some Wine-only rows are Wine-internal noise — flagged in 5.2.",
    "launcher-win32-golden.exe has a requireAdministrator manifest (CreateProcessW -> GetLastError=740), so the guest capture runs via tools/vm/elev.sh; the capture script also builds one quoted argument string because Start-Process -ArgumentList does not quote array elements."
  ],
  "handoff": "No build needed. To reproduce: tools/hog_apidiff.sh (uses the existing logs/api). 64-bit tracer regression was re-run and passes; the Wine prefix has no leftover Hog processes. Follow-up if wanted: re-run the launcher under the tracer on Windows with the attach poll loop to capture desktop start-up byte-for-byte (needs a New Show click; the server start-up already covers show creation)."
}