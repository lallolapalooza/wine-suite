{
  "job": "verify patch 0101 with own probes on the patched build, then re-run the real CodeMeter MSI without the stub workaround",
  "build": "/home/user/projects/mastercam-wine/wine-install/bin/wine (wine-11.18, patches/local/0100-* + 0101-services-service-logon-token.patch); fresh separate prefix state/exp/CodeMeterProbe/prefix-0101 (win64, wineboot exit 0)",
  "step1_token_groups": {
    "probe": "tokprobe.exe started by wine's SCM (parent services.exe), pid 336",
    "raw_group_list": [
      "S-1-1-0 attr=0x7",
      "S-1-2-0 attr=0x7",
      "S-1-5-11 attr=0x7",
      "S-1-5-21-0-0-0-513 attr=0xf",
      "S-1-5-32-544 attr=0xf",
      "S-1-5-32-545 attr=0x7",
      "S-1-5-5-0-0 attr=0xc0000007",
      "S-1-5-6 attr=0x7 (SERVICE, enabled|enabled-by-default|mandatory)"
    ],
    "verdict": "PASS: INTERACTIVE(S-1-5-4)=0, SERVICE(S-1-5-6)=1 - exact inverse of the pre-patch INTERACTIVE=1 SERVICE=0; S-1-5-4 is gone. svc.IsAnInteractiveSession() would now return false => service mode.",
    "sessprobe_same_run": "pid=364 session=0 parent_pid=56 parent_session=0 parent=\"C:\\windows\\system32\\services.exe\" - session/parent semantics unchanged and correct"
  },
  "step2_real_msi_no_stub": {
    "command": "wine msiexec /i <CodeMeterRuntime64.msi> ALLOW_BELOW=1 REBOOT=ReallySuppress /qn /norestart /l*v C:\\cm-install-0101.log (fresh prefix, no stand-in service)",
    "exit_code": 0,
    "was": "exit 91 on the 19-patch build without 0101",
    "dispatcher_evidence": [
      "trace: 0250 process_send_start_message 00007FFFFE89B1F0 L\"CmWebAdmin.exe\" 0000000000000000 0",
      "then 0260 service_run_main_thread Starting 1 services running as process 604 (client-side dispatcher trace - absent in the unpatched run)",
      "service_start returning 0 x14; grep -c 'failed to start' = 0 (unpatched: err:service:process_send_start_message service L\"CmWebAdmin.exe\" failed to start + service_start returning 1053)"
    ],
    "post_install_state": [
      "sc query CmWebAdmin.exe -> STATE 4 RUNNING (exit code 0)",
      "sc query CodeMeter.exe -> STATE 4 RUNNING (checkpoint 0x10)",
      "MSI log: Action ended 12:03:23: INSTALL. Return value 1. (InstallFinalize present)",
      "installed: 38 files in C:\\Program Files\\CodeMeter\\Runtime\\bin, cpsrt.dll/WibuCm64.dll in system32, 118 MB total (same tree as the old stub-workaround install)"
    ],
    "verdict": "PASS - CmWebAdmin.exe now calls StartServiceCtrlDispatcherW, reports RUNNING and the MSI completes with exit 0 without any workaround."
  },
  "step3_still_off": "nothing - both patch halves behaved as designed. The 30 s service_pipe_timeout was not even needed, because the service now connects immediately.",
  "caveat": "This fixes the INSTALL only. The licensing verdict is unchanged: the local CodeMeter Runtime Server still never publishes Global\\CmApiCallIn (kernel-driver gated, proven in docs/CODEMETER_ON_WINE.md sections 12/12.1/12.2), so Mastercam cannot be licensed locally on Wine; the network/HASP path (hasplms / nethasp.ini) is the only option.",
  "evidence": "logs/exp/CodeMeterProbe/msi-0101.log (full +service trace, MSIEXEC_EXIT=0, sc query results), prefix-0101/drive_c/cm-install-0101.log, prefix-0101/drive_c/tokprobe.log, prefix-0101/drive_c/sessprobe.log; probes kept in state/exp/CodeMeterProbe/{tokprobe,sessprobe,cmstub}.c/.exe and msi-0101.sh",
  "scratch": "prefix-0101 1.8G (wineboot + CodeMeter install; removed the 195 MB cached copy from windows/Installer), logs 1.1M; no interference with McInstallWine's state/work/prefix. df -h / -> 15G free"
}