{
  "verdict": "YES — the net10.0 WindowsDesktop runtime installs and runs under the patched Wine 11.18, and WPF presents a real painted window. No failing call/exception; zero wine err: lines.",
  "runtime_installed": {
    "artifact": "Microsoft Windows Desktop Runtime 10.0.12 (x64), windowsdesktop-runtime-10.0.12-win-x64.exe",
    "sha512_verified": "0b907e9312867172a4eb82f4b5ab3f7c2d25e27d8349546d77eeb5d5b8cbecab9ebebfed189b13e9669dc578d892756c548366da539d47b3ddac5efcb7ae72fe (matches dotnet release metadata)",
    "command": "wine wd10.exe /install /quiet /norestart /log C:\\wd10.log",
    "exit": "0 (bundle Burn v6.0.3-dotnet.6; per-MSI 0x0 for DotNetHost, DotNetHostFxr, DotNetRuntime, WindowsDesktopRuntime)",
    "result": "C:\\Program Files\\dotnet + shared/Microsoft.NETCore.App/10.0.12 (188 files) + shared/Microsoft.WindowsDesktop.App/10.0.12 (78 files incl. PresentationFramework/Core, WindowsBase, wpfgfx_cor3, D3DCompiler_47_cor3); hostfxr/sharedhost registry keys written"
  },
  "managed_code_executed": {
    "dotnet_info": "Host 10.0.12, RID win-x64; runtimes Microsoft.NETCore.App 10.0.12 + Microsoft.WindowsDesktop.App 10.0.12; 'No SDKs were found'; exit 0",
    "framework_dependent_console": "net10.0 FDD pinned to Microsoft.NETCore.App 10.0.0 → rolled forward to 10.0.12; printed FrameworkDescription=.NET 10.0.12, OSDescription=Microsoft Windows 10.0.19045; exit 42 propagated",
    "both_launch_paths": "wine C:\\hello\\hello.exe  AND  wine dotnet.exe C:\\hello\\hello.dll — both exit 42"
  },
  "wpf_window": {
    "probe": "net10.0-windows + UseWPF, FDD, runtimeconfig naming exactly Mastercam's tfm/frameworks/versions (net10.0; NETCore.App 10.0.0; WindowsDesktop.App 10.0.0)",
    "result": "window created, Map State: IsViewable, 412x226; WPF infrastructure windows present (MediaContextNotificationWindow, SystemResourceNotifyWindow) => MilCore/MediaContext live",
    "pixel_proof": "import -window <id> -> 412x226 PNG (173 colours); tesseract OCR reads 'WPF PROBE OK' and 'tier =131072'; app marker file C:\\wpf-started.txt = 'started tier=131072'",
    "render_tier": "RenderCapability.Tier = 131072 = 0x00020000 (WPF tier 2 / hardware) via wined3d→OpenGL",
    "real_display": "also verified on DISPLAY=:0 (X.Org 1920x1200, reparenting WM): wmctrl -l lists 0x01e00007 'WPF-PROBE-WINDOW', client window 412x226 Map State: IsViewable, app lifecycle identical, exit 0"
  },
  "errors": {
    "err_lines": "zero err: lines in the whole WPF run (WINEDEBUG=err+fixme, 33 lines total, all fixme)",
    "notable": "fixme:dwmapi:DwmAttachMilContent/DwmDetachMilContent are Wine stubs (the WPF MilCore/DWM hook) — benign here; fixme:d3d (Last Pixel Drawing Disabled, line patterns in core contexts) cosmetic; libEGL 'DRI3 error' only on the GPU-less Xvfb",
    "environment_quirk": "on display :0 XGetImage is refused (xwd -root and import → BadMatch, _NET_WM_CM_S0 absent) so screenshots/OCR must be done on an Xvfb display"
  },
  "dotnet_framework_48": {
    "verb": "winetricks -q -f dotnet48 (winetricks 20250102)",
    "semantics": "verb is load_dotnet48 → download ndp48-x86-x64-allos-enu.exe (same file Mastercam ships) + remove_mono + w_call dotnet40 (installs .NET 4.0 first!) + w_set_winver win7 + ndp48 /sfxlang:1027 /q /norestart + *mscoree=native",
    "result": "WT_EXIT=0 (~15 min, ~2.7 GiB). Registry NDP\\v4\\Full Release=0x80eb1 (528049 = 4.8); framework csc.exe compiled a test exe -> 'FX48-MANAGED-OK / CLR=4.0.30319.42000 / CLRdesc=.NET Framework 4.8.3761.0', exit 9",
    "caveat": "winetricks records a WPF infinite-loop bug (winehq #47277) for non-en_US.UTF-8 locales, workaround LC_ALL=C"
  },
  "mastercam_notes": {
    "needs_both": "Mastercam ships SetupPrerequisites/ndp48-x86-x64-allos-enu.exe (121 MB, 4.8.4115.0) but no .NET 10 runtime and no hostfxr/coreclr; ManagedUI runtimeconfig = net10.0 + NETCore.App 10.0.0 + WindowsDesktop.App 10.0.0. .NET Framework 4.8 and the .NET 10 Desktop Runtime are separate requirements — install both.",
    "ijwhost": "ijwhost.dll is NOT part of the runtime install (it lives in the apphost pack); Mastercam ships its own (10.0.25.52411) and will resolve hostfxr via the Software\\dotnet\\Setup\\InstalledVersions\\x64 registry keys the installer wrote [INFERENCE, untested]"
  },
  "recommended_path": [
    "Install windowsdesktop-runtime-10.0.12-win-x64.exe /install /quiet /norestart into the SAME prefix that hosts Mastercam (verified exit 0x0; 10.0.12 satisfies the 10.0.0-pinned runtimeconfig).",
    "Also install .NET Framework 4.8 (Mastercam's own ndp48 prerequisite, or the verified `winetricks -q dotnet48` which also adds dotnet40 + native mscoree). Neither substitutes for the other.",
    "Do not expect the shipped WebView2Loader/wrappers to cover the My-Mastercam panel — the Edge WebView2 Evergreen Runtime is still a separate prerequisite.",
    "If the ManagedUI client area is blank/black, look first at dwmapi:DwmAttachMilContent (the one WPF-render-path API Wine stubs) via relay tracing.",
    "WPF renders on a GPU-less box via wined3d-on-OpenGL; budget for that if the viewport is heavy."
  ],
  "unknowns": [
    "End-to-end Mastercam ManagedUI (Mastercam.exe → C++/CLI ManagedUI.Interop.dll → ijwhost.dll → hostfxr → WPF) not yet run; a peer's install at state/exp/mcinstall/prefix was still only at 'common' (no ManagedUI tree) while probing.",
    "Mastercam's own XAML/Actipro views not exercised (stock WPF window only).",
    "Visual readback on the real display :0 impossible in this environment; GPU throughput untested.",
    "WindowsDesktop assemblies beyond those WPF touches (XPS/printing, theme assemblies) untested.",
    "WebView2 stack out of scope."
  ],
  "deliverable": "/home/user/projects/mastercam-wine/docs/DOTNET_ON_WINE.md (497 lines, 9 sections, every claim paired with the exact command + observed output)",
  "disk": {
    "left_behind": "state/exp/DotnetProbe = 2.2 GiB total, of which prefix/ = 2.2 GiB; prefix-fx (the .NET Framework 4.8 prefix) deleted; build outputs (hello/, wpfapp/) ~1.5 MB; logs/pngs <1 MB",
    "reusable_artifact": "state/exp/DotnetProbe/prefix/drive_c/Program Files/dotnet is a complete, working .NET 10.0.12 install tree (host + both shared frameworks) that can be copied straight into the Mastercam prefix instead of re-running the installer",
    "scratch_download": "windowsdesktop-runtime-10.0.12-win-x64.exe lives at /run/media/user/Windows/mc-scratch/wd10.exe (60 MB, NTFS partition)",
    "df_root": "/dev/nvme0n1p5 213G total, 24G available (89% used) — was 17G before cleanup"
  }
}