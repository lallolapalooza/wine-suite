{
  "answer_0100": "YES - patch 0100 fixed it. Our build (19-patch series + patches/local/0100-msi-class-registry-view.patch + 0101, msi.dll rebuilt 11:50 AFTER classes.c was patched at 11:27) installs the product MSI: MSIEXEC_EXIT=0, `ISLockPermissionsInstall. Return value 1`, `InstallFinalize. Return value 1`, `INSTALL. Return value 1`. Reproduced twice (scratch prefix pfx2 and the canonical state/work/prefix). Before the patch the same command gave exit 67 with `Error 27555 ... 0x00000643` and a full rollback. Registry monitor (`logs/exp/mcinstall/keymon3.log`) shows the 64-bit `HKLM\\Software\\Classes\\CLSID\\{00020420-...}\\InprocServer32` stays `C:\\windows\\system32\\oleaut32.dll` for the whole run (was overwritten with the syswow64 path and then deleted pre-patch). ps_test32/ps_test64 both return 0x00000000 in the new prefix.",
  "answer_0101": "YES - the CmWebAdmin service start now succeeds as-is; the CodeMeterProbe stub service was NOT needed. `msiexec /i CodeMeterRuntime64.msi ALLOW_BELOW=1 /qn` exits 0, 118 MB installed, `Program Files/CodeMeter/Runtime/bin/CodeMeter.exe` + `system32/WibuCm64.dll`, MSI log `StartServices. Return value 1`, `net start` lists `CmWebAdmin` and `CodeMeter Runtime Server` running, zero err:service/1053 lines. NOTE: my first attempt failed (exit 67) but NOT at a service - it aborted at the CodeMeter `CA_OSBelowWinVerX` OS guard, because tools/mkprefix.sh never actually set Windows 10 (see below). After `winecfg -v win10` the MSI installed in 15 s.",
  "install": {
    "command": "wine msiexec /i $MCW_MEDIA/mastercam/Mastercam_Installer.msi TRANSFORMS=$MCW_MEDIA/mastercam/1033.mst INSTALLDIR='C:\\Program Files\\Mastercam 2027' SHAREDDEFAULTS='C:\\ProgramData\\Mastercam' CNC_UNIT_TYPE=I REBOOT=ReallySuppress /qn /norestart /L*v 'C:\\mc_msi_final.log'",
    "exit_code": 0,
    "wall": "~2 min (after the 3.3 GB payload; earlier full runs 9-10 min)",
    "footprint": "1215 files, 2.5 GB under state/work/prefix/drive_c/Program Files/Mastercam 2027 (MastercamLauncher.exe 11 815 768 B, Mastercam.exe 226 136 B, Backplot.dll, BCGCB*, Cnc.*, ...)",
    "log": "logs/exp/mcinstall/mc_msi_final.log (690 KB)"
  },
  "prereqs_installed_on_state_work_prefix": [
    "core fonts (Arial/Verdana enumerated by fontprobe)",
    ".NET 10 Desktop Runtime 10.0.12 x64 (wd10.exe /install /quiet) rc=0",
    ".NET Framework 4.8 via winetricks -q -f dotnet48 (~8 min) rc=0",
    "VC++ 2022 x64 rc=0",
    "CodeMeter Runtime exit 0 (118 MB, services running)"
  ],
  "launch": {
    "MastercamLauncher.exe": "starts, gets through CodeMeter/WMI/device probing, then `err:seh:NtRaiseException Unhandled exception code c0000409 flags 1 addr 0x140800701` ~5.6 s in. NO window ever created (window tree shows only Openbox + explorer.exe). All window/screen captures OCR to empty text. Wrapper stayed resident for the full 180 s.",
    "Mastercam.exe": "`err:module:loader_init \"MCTool.dll\" failed to initialize, aborting` + `Initializing dlls for C:\\Program Files\\Mastercam 2027\\Mastercam.exe failed, status e06d7363` (MSVC C++ exception escaping MCTool.dll init; the +seh trace shows the __CxxFrameHandler4 unwind ending in RtlRestoreContext). NO window, OCR empty.",
    "target_state": "NOT reached. Windows reference (Mastercam 2027 window -> 400x400 'Checking license...' splash -> modal 'No Mastercam license found.  Do you have an activation code?') was not reproduced; both entry points crash during start-up before any UI.",
    "new_wine_error_lines": [
      "err:secur32:start_samss Failed to start SamSs service",
      "err:secur32:load_auth_packages Failed to get security packages list: 80090304",
      "err:ole:start_rpcss Failed to start RpcSs service",
      "err:service:device_notify_proc failed to open RPC handle, error 1722",
      "trace:seh:dispatch_exception code=6ba (RPC_S_SERVER_UNAVAILABLE)",
      "err:module:loader_init \"MCTool.dll\" failed to initialize / status e06d7363"
    ]
  },
  "tool_bugs_found_and_fixed": [
    "tools/mkprefix.sh 'set Windows 10': the `ProductName|Windows 10 Pro` entry was split on the SPACE (wrote a value literally named `ProductName|Windows`), and setting only the CurrentVersion string is ignored by Wine once CurrentMajorVersionNumber/CurrentMinorVersionNumber exist -> the prefix reported **Windows 7 SP1 (6.1.7601)**. That is what tripped CodeMeter's CA_OSBelowWinVerX. Fixed: set the two DWORDs (10/0), CurrentBuildNumber/CurrentBuild 19045, CurrentVersion 6.3, ProductName.",
    "tools/mkprefix.sh --stage fonts: install_corefonts.sh needs RW_TMP (else `mktemp -d /corefonts.XXXXXX`). Fixed by passing RW_TMP=\"$MCW_TMP\".",
    "tools/run_mastercam.sh killed itself: pre-run cleanup `pgrep -f \"$EXE\"` matched the wrapper's own cmdline (`--exe MastercamLauncher.exe`) whose env has WINEPREFIX -> `kill -9` on itself, empty out.txt. Fixed: skip $$/$PPID and require /proc/<pid>/comm to be wine/wineserver."
  ],
  "next_debug_leads": [
    "MCTool.dll initialisation throwing during Mastercam.exe startup (Wine loads MCTool.dll, its init raises -> whole process aborts). Prev: Mastercam.dll/MCCore.dll load fine.",
    "RpcSs/SamSs failing to start for the app process (`err:ole:start_rpcss`, `err:secur32:start_samss`) with RPC_S_SERVER_UNAVAILABLE exceptions - plausibly the reason MCTool.dll's init fails; worth checking whether patch 0101 or the services.exe session-0 change affects RpcSs when started on demand by ole32."
  ],
  "deliverables": [
    "docs/MC_INSTALL_WINE.md (425 lines): commands, exit codes for all 7 runs, decisive MSI-log + stderr lines, the live registry capture of the clobber, the fix verification, the end-to-end section, the launch results and the 3 tool fixes.",
    "tools/mkprefix.sh, tools/run_mastercam.sh (fixed, syntax-checked)",
    "regression check: /run/media/user/Windows/mc-scratch/{ps_test.c,ps_test32.exe,ps_test64.exe,oleaut_test*,dll/ISBEW64.exe}",
    "logs/exp/mcinstall/: winedbg_install.log, winedbg_min_trace.log (+ole,+msi,+process), keymon2.log, keymon3.log, rerun_ourwine.log, e2e_stageA/B.log, mc_msi_final.log, cm*.log"
  ],
  "disk": {
    "left": [
      "state/work/prefix 7.5 GB (canonical prefix, full install + prereqs)",
      "logs/exp/mcinstall 4.5 MB",
      "/run/media/user/Windows/mc-scratch 1.5 GB (probes + carved DLLs; the 2.1 GB pfx2 scratch prefix was deleted)"
    ],
    "df": "/dev/nvme0n1p5 213G 189G 14G 94% /  |  /dev/nvme0n1p3 259G 224G 36G 87% /run/media/user/Windows",
    "note": "state/exp/mcinstall/prefix (the poisoned 2.0 GB scratch prefix) no longer exists - something outside my session removed it; all its evidence was already copied/quoted into the doc and logs/exp/mcinstall/."
  }
}