# Session archive

Generated 2026-10-04T21:08:14.668Z from session `01a1054a-e00e-7663-ba26-bd902f0caf20`.

## Layout

| Path | Contents |
| --- | --- |
| `manifest.json` | Index of everything below (counts, sizes, subagent list) |
| `session.jsonl` | The main session transcript, verbatim |
| `agents.json` | Live per-agent state captured while the session ran (model, system prompt, tools) |
| `jobs.json` | Background jobs: `completed` (recovered from transcripts) + `live` (running/recent at archive time) |
| `artifacts/` | Every file under the session artifact directory, verbatim |
| `viewer.html` | Standalone HTML viewer (all subagent sessions embedded) |

`artifacts/` is the important part: it holds each subagent's own
`<AgentId>.jsonl` transcript (recursively nested), the session's
`*.bash.log` / `*.eval.log` / `*.read.log` files with the **full, untruncated**
tool and background-job output, and `*.jsonl.tombstone` kill markers.

## Background jobs

72 completed jobs recovered from the transcripts (main + every subagent); full list in `jobs.json`. A live snapshot of running/recent jobs for Main is also included. Per-job output lives in the owning transcript and in `artifacts/*.log`.

## Subagents (9)

- `CapCutRenderDiag` — 640 entries, 2406665 bytes
- `Crash100s` — 651 entries, 2296203 bytes
- `GuestCapCutCapture` — 486 entries, 1220955 bytes
- `HardwareBranch` — 761 entries, 2184194 bytes
- `MergeWinePatchSeries` — 193 entries, 510494 bytes
- `QtDcompPath` — 740 entries, 2326353 bytes
- `SWbemDateTime` — 402 entries, 1252823 bytes
- `VEDetectorRE` — 330 entries, 1188135 bytes
- `VolumeInfo` — 670 entries, 2005747 bytes

## Totals

114 files, 49381420 bytes.
