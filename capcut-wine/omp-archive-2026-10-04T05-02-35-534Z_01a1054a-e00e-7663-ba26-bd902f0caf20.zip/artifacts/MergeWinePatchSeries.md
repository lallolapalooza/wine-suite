{
  "status": "complete",
  "tree": {
    "path": "/home/asdf/projects/capcut-wine/wine/wine-11.18",
    "vcs": "git, branch 'merged'",
    "commits": 24,
    "log": "pristine wine-11.18 + 23 patch commits",
    "status_porcelain": "empty (clean)"
  },
  "series": {
    "dir": "/home/asdf/projects/capcut-wine/patches",
    "count": 23,
    "renumbered": true,
    "map": "patches/base-roles.tsv (new# -> origin acad/powerbi/acad-private -> source patch -> subject)"
  },
  "report": "/home/asdf/projects/capcut-wine/recon/MERGE.md",
  "input_format_note": "input patches are plain unified diffs, NOT git-format-patch (no From/diff --git); git am impossible, so applied with git apply --index + manual commit (documented fallback). No --3way needed except the handled overlap.",
  "ordering": {
    "acad": [
      "0001",
      "0002",
      "0003",
      "0004",
      "0006",
      "0007",
      "0008",
      "0009",
      "0010",
      "0012",
      "0013",
      "0014",
      "0015",
      "0016",
      "0017"
    ],
    "powerbi": [
      "0001",
      "0002",
      "0003",
      "0004",
      "0006",
      "0007"
    ],
    "excluded": [
      "acad-private 0011-user32-debug-licence-hooks (debug-only, out of scope)"
    ]
  },
  "decisions": {
    "0017 vs .patch.new": "used .patch.new (later revision); dropped duplicate .patch; reference tree matches .new content (softpub FIELD_OFFSET, crypt32 CertFindCertificateInStore). .new had a malformed duplicated '--- a/' header line, removed before applying.",
    "acad-private 0005 bcrypt-debug": "INCLUDED as new 0023 (applies cleanly). DEBUG-ONLY: prints symmetric keys/plaintext, zero behavioural change; must be dropped before shipping.",
    "recovered from acad reference tree": "ntdll/tests/file.c post-0008 test update exists only in the reference tree, no patch carries it; folded into new 0015.",
    "recovered from powerbi reference tree": "dlls/msxml3/mxnamespace.c implements IVBMXNamespaceManager::reset, no powerbi patch carries it; added as new 0022 so tree is a superset."
  },
  "conflicts": {
    "acad0014 vs powerbi0005": {
      "resolution": "union",
      "detail": "hunks byte-identical (HUNKS_IDENTICAL); powerbi0005 subsumed by new 0012; proof: merged dlls/secur32/secur32.c diff vs BOTH reference trees = 0"
    },
    "acad0017 vs powerbi0007": {
      "resolution": "union",
      "detail": "only dlls/secur32/tests/secur32.c overlaps; both add the identical testGetUserNameEx_domain (kept once), powerbi adds the LsaFreeReturnBuffer assertion; acad tests = new 0015, powerbi tests = new 0021; proof: merged secur32 tests == powerbi ref exactly (diff 0) and == acad ref + only the added assertion (strict superset)"
    }
  },
  "verification": {
    "reverse_apply_all_23": "OK (each patch's exact post-image present in tree)",
    "series_reproduces_head": "applying all 23 patches in order to pristine gives git write-tree 28b5c9fa7bae02dc42c9330bfc204bf3af2c8001 == merged tree (SERIES_REPRODUCES_HEAD_EXACTLY)",
    "cross_diff_acad_ref": "18 files differ + actctx.c.orig only-in-ref; all explained (powerbi-owned files, our recovered msxml3, excluded debug 0011, junk .orig)",
    "cross_diff_powerbi_ref": "17 files differ; all explained (acad-owned files, our 0015 file.c fix, our debug 0023, excluded debug 0011)"
  },
  "not_done": [
    "configure/make (explicitly out of scope for a later task)"
  ],
  "notes_for_main": [
    "Run the x86_64-only build from /home/asdf/projects/capcut-wine/wine/wine-11.18 (branch merged) or by applying /home/asdf/projects/capcut-wine/patches/*.patch to a pristine tree.",
    "PATCH 0023 (bcrypt DEBUG ONLY) prints secrets to stderr; drop it (git revert / omit that patch) for any shippable build.",
    "acad-private 0011 (user32 debug licence hooks) was deliberately NOT included; it exists in both reference trees if needed.",
    "Helper scripts: capcut-wine/scripts/merge/{apply_one.py,msg_filter.sh}.",
    "Reference trees untouched; /dev/shm worktree removed; tree 494M incl .git."
  ]
}