{
  "status": "partial",
  "A": {
    "closed": false,
    "fixed": "a real Wine defect, with test + reproducibility",
    "commit_messages": [
      "d3d11: only advertise GDI compatibility for formats that support it  (commit fff4ac8)",
      "dxgi: read composition swap chain buffers that have no DDI format  (commit 7e11e15)"
    ],
    "patches": [
      "patches/series/0028-d3d11-gdi-compatibility-flag-only-where-valid.patch",
      "patches/series/0029-dxgi-read-composition-buffers-without-a-ddi-format.patch"
    ],
    "series": "29 patches, reproducibility re-verified 29/29 (pristine 2ca2d8f worktree + patch -p1 for all of series/ + diff -rq against git archive HEAD = empty); patches/local/ still empty (both are general Wine gaps)",
    "root_cause": "series/0024 forces DXGI_SWAP_CHAIN_FLAG_GDI_COMPATIBLE on every composition swap chain; d3d11/device.c's dxgi_device_parent_register_swapchain_texture then unconditionally added D3D11_RESOURCE_MISC_GDI_COMPATIBLE, which D3D11 allows only for B8G8R8 formats. The app asks for R8G8B8A8_UNORM + PREMULTIPLIED + FLIP_DISCARD at 1440x994, so CreateSwapChainForComposition failed E_INVALIDARG.",
    "evidence": [
      "before 0028: hw branch died t=12-38s with the crash handler running (logs/hwprobe1, logs/hw2); err:dxgi:d3d11_swapchain_create_d3d11_textures ... hr 0x80070057 preceded by warn:d3d11:validate_texture2d_desc Incompatible description used to create GDI compatible texture",
      "after 0028: app alive 70-160s with the main window mapped (logs/hwfix1, hwfix2, hwtrace3, hwpid, hwattr, hwrb1, hwrb3)",
      "dxgi_test.exe: 20446 tests / 1 failure without 0028 -> 20460 tests / 0 failures with it (logs/dxgi_test_pre.log, logs/dxgi_test_post.log); new test dlls/dxgi/tests/dxgi.c:test_create_swapchain_for_composition",
      "probe work/tools/t_compositionsurface.exe (Wine): RGBA8 comp swap chain now creates, but GetDC fails 8876086c (wined3d has no DDI format for R8G8B8A8) and Map fails 80070057; BGRA8 GetDC ok -> 0029 adds a staging-texture readback + StretchDIBits with per-format DIB masks"
    ],
    "still_open": "the main window is still uniformly white, and it is measured NOT to be the compositor: in every post-fix hardware run the app creates that swap chain and then never composites (no DCompositionCreateDevice/SetContent/Commit; grep -c 'now composites into' = 0), so 0029's readback is never exercised by the app (it builds, dxgi suite green, but app-level verification of the readback is missing). Attribution (A1): the swap chain belongs to pid 348 = CapCut's MAIN process (parent of all CEF renderers), i.e. Qt's RHI, not a CEF GPU process; the next pieces are (a) trace which dcomp entry point Qt calls after the swap chain, (b) implement DCompositionCreateSurfaceHandle (+ a shareable surface) which is still '@ stub' in dcomp.spec while CreateSurface* already exist in the device vtables. Ruled out for the white window: adapter identity (white with both fabricated cards), DXVK (off), display :9 vs :10, our composite (never called).",
    "runs_during_full_disk_note": "Main reports / was at 100% (1.2GB) during part of this session; all §35.1/§35.2 runs were made after their cleanup and are re-runnable via scripts/cc_run.sh"
  },
  "B": {
    "closed": false,
    "started": "partially",
    "windows_shows_modal": "NO - recon/win_install/capcut_after_agree.png is the guest home screen with a 'Get started...' tooltip and no modal, so the modal is Wine-only",
    "guest_half_blocked": "the guest command channel is dead: vmshare/cmd.txt is written and vmserv.py (pid 298237, :8000) runs, but vmshare/guest_cmd_out.txt stays 0 bytes for Write-Output and cmd echo (2 attempts at 12:07-12:09). I also could not establish how a host file gets to the guest (could not push volprobe.exe). The guest PowerShell poll loop needs a restart.",
    "wine_answers_from_main": "GetDriveTypeW 3 FIXED; GetVolumeInfoW ok=1 vol='' fs=NTFS serial=43000000 flags=0100008a; GetDiskFreeSpaceExW ok; GetVolumeAttrs dir; CreateFileW write probe succeeds (work/tools/volprobe_wine.txt)",
    "next": "restart the guest agent, run the same volprobe.exe there against %USERPROFILE%\\AppData\\Local\\CapCut\\User Data\\Projects, and diff - first candidates are the empty volume label and serial 0x43000000"
  },
  "docs": [
    "STATE.md 35 (root cause, before/after table, ruled-out list, next experiments) and 35.6 (A1 attribution, Windows-modal answer, guest-channel status)",
    "recon/RENDER.md 9",
    "patches/README.md + patches/SERIES.tsv (0028/0029, 29 patches, local/ still empty)",
    "work/tools/t_compositionsurface.cpp/.exe + t_compositionsurface_wine_after.txt; work/tools/cc_cfg.sh switches the prefix between the hardware and Windows-matching config states and shows that the software branch is a race (the app rewrites EnvDetect.json/globalSetting during startup)"
  ]
}