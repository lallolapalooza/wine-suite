{
  "status": "complete",
  "app": "CapCut PC 9.5.0.4050 (channel capcutpc_0, release)",
  "install_dir": "C:\\Users\\adsf\\AppData\\Local\\CapCut\\Apps\\9.5.0.4050\\",
  "install_root": "C:\\Users\\adsf\\AppData\\Local\\CapCut\\Apps\\ (CapCut.exe, uninst.exe, Configure.ini, ProductInfo.xml)",
  "main_exe": {
    "path": "C:\\Users\\adsf\\AppData\\Local\\CapCut\\Apps\\CapCut.exe",
    "size": 90536,
    "sha256": "3CC2239FC086742FF4C127CB8990A7B1441225D1F7477C36F282D05F0A10E089"
  },
  "main_exe_version_dir": {
    "path": "C:\\Users\\adsf\\AppData\\Local\\CapCut\\Apps\\9.5.0.4050\\CapCut.exe",
    "size": 90536,
    "sha256": "4F07A09FEED96D3DF8F5D0485CED9C6C1B8C87E410EE327E8F254C416EB6D9F6"
  },
  "launch_command": "Start-Process -FilePath 'C:\\Users\\adsf\\AppData\\Local\\CapCut\\Apps\\CapCut.exe' -WorkingDirectory 'C:\\Users\\adsf\\AppData\\Local\\CapCut\\Apps'",
  "silent_path": "FAILED. 'capcut_setup.exe /S' only creates a 0-byte %TEMP%\\installer_downloader.log and exits; no download/no UI. Interactive launch of the same stub is what works.",
  "installer_log": "C:\\Users\\adsf\\AppData\\Local\\Temp\\installer_downloader.log (full text in report; no URL in it; channel capcutpc_0; download 22:08:15->22:09:41, install done 22:13:18, auto-launched Apps\\CapCut.exe)",
  "download_urls": {
    "payload_exact": "https://sf16-web-tos-buz.capcutstatic.com/obj/capcut-web-buz-sg/packages/CapCut_9_5_0_4050_capcutpc_0_creatortool.exe",
    "how_obtained": "user-mode minidump of the running capcut_setup downloader process; its own auto_updater.cc(1952) log line in memory",
    "config_endpoints": [
      "https://mcs-v2-boot.capcutapi.com/v1/json",
      "https://mcs.zijieapi.com/v1/json",
      "https://mcs.bytedance.net/v1/json_test",
      "https://mcs.byteoversea.net/v1/json_test"
    ],
    "app_setting_host": "https://editor-api-v2-boot.capcutapi.com (app_id 423531, key windows_update_oversea)",
    "cdn_hosts_resolved": [
      "sf16-web-tos-buz.capcutstatic.com (payload)",
      "lf16-beecdn.ibytedtos.com (installer UI banner pngs)",
      "mcs-v2-boot.capcutapi.com",
      "editor-api-v2-boot.capcutapi.com",
      "editor-api-sg.capcutapi.com",
      "mcs-normal-sg.capcutapi.com",
      "pc-mon-v2-boot.capcutapi.com"
    ]
  },
  "payloads": {
    "installed_tree_zip": {
      "host_path": "$CCWS/recon/win_install/capcut_payload.zip (hardlink of $CCWS/vmshare/capcut_payload.zip)",
      "size": 836520814,
      "sha256_guest": "4D282DA0ABDB1B82225E07A0FBBDF682912433372BC8396F3CA860C05916FF05",
      "sha256_host": "4d282da0abdb1b82225e07a0fbbdf682912433372bc8396f3ca860c05916ff05",
      "match": true,
      "contents": "whole Apps\\ tree, 5223 zip entries / 4084 files, 1665551280 bytes uncompressed"
    },
    "raw_installer_payload": {
      "host_path": "$CCWS/recon/win_install/capcut_installer_payload.exe",
      "size": 559656336,
      "sha256": "E3755D1798FDEA572E4A781E5B39F759B3F2C32CC5D590E71006DF7B6F00664F",
      "identity": "Bytedance.CapCut / CapCut Installer Application v1.0 / 9.5.0.4050 / JYPacket",
      "guest_origin": "C:\\Users\\adsf\\AppData\\Local\\app_shell_cache_562354\\app_package_37889d0f29.exe (installer deletes it on success; recaptured by killing the stub right after 'Downloader download finish')"
    }
  },
  "inventory": {
    "files": 4084,
    "bytes": 1665551280,
    "top": [
      "VECreator.dll 262527400",
      "cef\\libcef.dll 217550760",
      "cccreator.dll 158417832",
      "lens.dll 88502184",
      "videoeditor.dll 71016360",
      "deepagents_capi.dll 42067992",
      "lynx.dll 24506792",
      "pc_push.dll 24096168",
      "cef\\dxcompiler.dll 21875624",
      "opengl32sw.dll 20640160",
      "avcodec-61.dll 19722664",
      "Resources\\Font\\SystemFont\\zh-hant.ttf 19783436",
      "openvino.dll 14304168",
      "audioeffect.dll 14009768",
      "metasecml.dll 12629928"
    ],
    "full_listing": "$CCWS/recon/win_install/capcut_listing.txt (519137 B)"
  },
  "stack_confirmed": {
    "qt6": true,
    "cef": true,
    "lynx": "lynx.dll 24.5MB + lynx_core.js",
    "vec": "VECreator.dll 262MB + videoeditor.dll 71MB",
    "angle": "VEAngle\\libEGL.dll 220072 + VEAngle\\libGLESv2.dll 5672360 (also cef\\libEGL.dll 486824 + cef\\libGLESv2.dll 7657896)",
    "ffmpeg": "avcodec-61/avformat-61/avfilter-10/avutil-59/swscale-8/swresample-5/avdevice-61",
    "openvino": true
  },
  "launch_evidence": {
    "screenshots": [
      "pre_00.png",
      "step1_after_S.png",
      "step2_interactive.png",
      "step2b_moved.png",
      "step2c_front.png",
      "step3_app_launched.png",
      "step3b_vedetector.png",
      "vedet.png",
      "capcut_launch_t10s.png",
      "capcut_launch_t30s.png",
      "capcut_launch_t60s.png",
      "capcut_launch_t120s.png",
      "capcut_after_agree.png",
      "probe2_state.png"
    ],
    "dir": "$CCWS/recon/win_install/",
    "observed": "No window at t+10s/t+30s (process up, no MainWindowTitle). At t+60s the app window appears with a Terms-of-Service/Privacy modal over a dark home screen; at t+120s the modal is still up and the background is fully painted. After clicking 'Agree and continue' the full editor home renders (Create project, AI-powered creative suite, sidebar AI Studio/Editing Studio/AI tools/Create with AI/Marketing tools/Marketplace/Library, Projects).",
    "rendered_on_qxl": true,
    "render_note": "Renders fine on QXL. EnvDetect.json Qt6RenderEnvironment: angle_device=auto, hw_render=0, final_hw_enable=0, qt6_render_engine=d3d11; globalSetting: hardwareRenderEnable=false, hardwareRenderForbid=true, enableUseDirectComposition=1, enableQtRhiBackendFallback=1. Main process (PID 2496) loads d3d11, dxgi, dcomp, OPENGL32, Qt6OpenGL, D3DCOMPILER_47, and VEAngle\\libEGL/libGLESv2.",
    "login_required": "No login wall. The only first-run gate is the ToS/Privacy modal; after agreeing the editor home is fully usable locally. Account/login only needed for cloud/AI/share features."
  },
  "ve_detector_finding": "ve_detector does NOT exist anywhere on the Windows disk (whole-disk dir /s /b and Get-ChildItem -Recurse -Filter *ve_detector* both empty). VeDetector_*.log has zero EGL/GLES/AGFX/GPDevice/ve_detector lines. So Wine's attempted 've_detector/libEGL.dll' load is purely a Wine-side path-resolution artifact.",
  "report": "$CCWS/recon/GUEST_CAPTURE.md",
  "guest_state": {
    "capcut_running": true,
    "main_pid": 2496,
    "window_title": "CapCut",
    "responding": true,
    "installer_or_modal_left": false,
    "note": "Left CapCut running because Main explicitly asked to preserve it as the Windows reference (the original ticket said to kill it afterwards - Main's later instruction supersedes). VEDetector killed; all temp files we created removed; C: free 9.31 GB."
  },
  "channel": {
    "original_agent": "DEAD - the pre-existing cmd.txt/guest_cmd_out.txt loop stalled in a long recursive scan and never responded again (verified).",
    "replacement": "RUNNING: vmshare/agent3.ps1 (started on the guest, hidden), channel commands via vmshare/cmd3.txt -> vmshare/guest_cmd_out3.txt, cache-busting + instance guard. Drive it with scripts/vmcmd3.sh (same interface as vmcmd.sh).",
    "note": "vmcmd.sh / cmd.txt no longer work."
  },
  "extra_host_artifacts": [
    "$CCWS/recon/win_install/winlog.zip (1078549 B, User Data\\Log+Config, sha256 CDB1D5150F06A95A7DB04D8953F65C47791949606FE0AA1BCBDC390F4E1DFA21)",
    "$CCWS/recon/win_install/ProductInfo.xml",
    "$CCWS/recon/win_install/ccsetup.dmp (124142421 B, downloader minidump = URL evidence)",
    "$CCWS/recon/win_install/urlhunt_note3.txt, urlscan.txt, urlhunt_note.txt, ved_search.txt",
    "$CCWS/recon/win_install/capcut_setup.exe (stub copy)"
  ],
  "acceptance": {
    "capcut_payload.zip_present_and_hash_matches": true,
    "GUEST_CAPTURE.md_written": true,
    "no_hanging_installer_or_modal": true
  }
}