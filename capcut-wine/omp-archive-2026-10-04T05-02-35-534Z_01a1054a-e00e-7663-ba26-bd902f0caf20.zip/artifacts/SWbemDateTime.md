{
  "summary": "Implemented the missing SWbemDateTime (CLSID {47DFBE54-CF76-11D3-B38F-00105A1F473A}) WMI scripting object in Wine's wbemdisp, with tests and evidence; committed and filed as series patch 0026.",
  "classification": "GENERAL Wine gap found while making CapCut run — NOT a CapCut-exclusive hack. The class is absent from every Wine build checked (25-patch tree, upstream 11.18, /opt/wine-staging); any WMI-scripting consumer hits the same REGDB_E_CLASSNOTREG. Per Main's instruction it lives in patches/series/0026 (not patches/local/, which is now empty), and the patch header states this plainly.",
  "commit": {
    "branch": "merged",
    "hash": "d460abf",
    "message": "wbemdisp: implement the SWbemDateTime scripting object\\n\\nCapCut's WMI layer requests CLSID_SWbemDateTime {47dfbe54-cf76-11d3-b38f-00105a1f473a},\\nwhich Wine does not register or implement, so CoCreateInstance fails with\\nREGDB_E_CLASSNOTREG. Add interface ISWbemDateTime and coclass SWbemDateTime\\n(CIM DATETIME <-> VT_DATE/FILETIME conversions) plus wbemdisp tests.\\n\\nGeneral Wine gap found via CapCut, not a CapCut-exclusive hack.",
    "files": [
      "include/wbemdisp.idl",
      "dlls/wbemdisp/Makefile.in",
      "dlls/wbemdisp/main.c",
      "dlls/wbemdisp/locator.c",
      "dlls/wbemdisp/wbemdisp_private.h",
      "dlls/wbemdisp/datetime.c (new)",
      "dlls/wbemdisp/tests/wbemdisp.c"
    ],
    "working_tree_clean": true
  },
  "patch": {
    "path": "$CCWS/patches/series/0026-wbemdisp-implement-SWbemDateTime.patch",
    "applies": "git apply --check OK and patch -p1 --dry-run OK against eeb3172 (the commit before d460abf); self-contained (full ISWbemDateTime vtable+IDL, no external deps)",
    "series_reproducibility": "26/26 patches applied with patch -p1 to the pristine wine-11.18 root commit (2ca2d8f1) reproduce git-archive HEAD byte-for-byte: diff -rq --exclude=.git is EMPTY",
    "docs_updated": [
      "patches/SERIES.tsv (0026 row)",
      "patches/README.md (table row, 26/26 counts, local/ note)"
    ]
  },
  "implementation": {
    "interface": "Full Microsoft ISWbemDateTime: Value, Year/YearSpecified, Month/MonthSpecified, Day/DaySpecified, Hours/HoursSpecified, Minutes/MinutesSpecified, Seconds/SecondsSpecified, Microseconds/MicrosecondsSpecified, UTC/UTCSpecified, IsInterval, GetVarDate/SetVarDate, GetFileTime/SetFileTime; IDispatch via shared get_typeinfo; Value is DISPID 0 (default property).",
    "conversions": "Stores components + CIM offset O + per-field *Specified; instant T_utc = components - O. Value <-> components incl. interval form ddddddddHHMMSS.mmmmmm:000 (leading 8 digits = day count) and '*' wildcards; GetVarDate/GetFileTime convert through VARIANT DATE / decimal-BSTR FILETIME with the local/UTC flag and machine DST; error codes match Windows: 0x80041021 malformed/invalid-for-conversion, 0x8004102b component out of range, 0x80041001 interval/unspecified on Get*."
  },
  "verification": {
    "probe": {
      "program": "$CCWS/work/tools/swbemdatetime_probe.c/.exe (x86_64-w64-mingw32-gcc -lole32 -loleaut32 -luuid), run under prefix-test (:10)",
      "before": "CoCreateInstance(CLSID_SWbemDateTime) -> 80040154 (REGDB_E_CLASSNOTREG) — file work/tools/swbemdatetime_probe_pre.txt",
      "after_build_tree": "-> 00000000 (S_OK); full conversion dump matches the Windows reference — work/tools/swbemdatetime_probe_post_buildtree.txt",
      "after_install": "-> 00000000 (S_OK) with wine-install/bin/wine — work/tools/swbemdatetime_probe_post_install.txt"
    },
    "wine_test": {
      "name": "test_datetime (dlls/wbemdisp/tests/wbemdisp.c, winetest entry wbemdisp)",
      "covers": "CoCreateInstance + QueryInterface(IDispatch/ISWbemDateTime), Value<->VT_DATE for a UTC and an offset timestamp, IsInterval, interval parse/build, GetFileTime/SetFileTime round trip, malformed input",
      "before": "225 tests executed, 1 failure — wbemdisp.c:658 got 0x80040154 (work/tools/wbemdisp_test_pre.log)",
      "after_build_tree": "267 tests executed, 0 failures (work/tools/wbemdisp_test_post.log)",
      "after_install": "267 tests executed, 0 failures (work/tools/wbemdisp_test_post_install.log)"
    },
    "windows_reference": "Measured on the win11 guest (build 26200, Pacific) running the real wbemdisp.dll via vmshare/swdt_probe.ps1 and swdt_probe2.ps1: Value '20000120195632.000000-480' -> GetVarDate(false)=2000-01-21 03:56:32 UTC / GetVarDate(true)=2000-01-20 19:56:32 local, GetFileTime(false)=125929005920000000 / (true)=125928717920000000; SetFileTime(...,false) -> '...+000', (...,true) -> '...-420'; interval GetVarDate/GetFileTime -> 0x80041001; put_Value('garbage') -> 0x80041021 unchanged; put_Month(13)/put_UTC(9999)/put_Hours(99)/put_Day(0) -> 0x8004102b; wildcards render '*' per unspecified field. Wine reproduces all of these."
  },
  "install": {
    "done": "copied dlls/wbemdisp/x86_64-windows/wbemdisp.dll -> wine-install/lib/wine/x86_64-windows/wbemdisp.dll and ran 'wine regsvr32 /s wbemdisp.dll' in prefix-test, after the render lock cleared (cc_run.sh idle)",
    "sanity": "wine-install/bin/wine --version -> wine-11.18; wine-install/bin/wine cmd /c echo ok -> ok",
    "not_done_intentionally": "$CCWS/prefix (CapCut's own prefix) was NOT modified (contract). One remaining deployment step to make the class visible to the app: WINEPREFIX=$CCWS/prefix wine-install/bin/wine regsvr32 wbemdisp.dll (or wineboot -u in that prefix)."
  },
  "docs": "recon/SWBEMDATETIME.md documents CLSID/IID/ProgID, interface surface, conversion semantics, the Windows reference table, probe before/after, test name/results, and the general-vs-app-exclusive verdict.",
  "notes": [
    "I did not add a STATE.md entry to avoid concurrent-append conflicts with peers; the required recon doc + patch/README/SERIES.tsv are updated.",
    "The probe 'before' evidence used wine-install's pre-change DLL (its wineboot registration lacked the class); 'after' used the build tree while the render lock was held, then the installed DLL once idle."
  ]
}