{
  "identified_call": "EnumServicesStatusExA — CapCut's metasecml.dll calls OpenSCManagerA(NULL,NULL,SC_MANAGER_ENUMERATE_SERVICE) then EnumServicesStatusExA twice (SC_ENUM_PROCESS_INFO / SERVICE_WIN32 / SERVICE_ACTIVE: size query with NULL, then fill with the buffer it then walks). It walks the returned ENUM_SERVICE_STATUS_PROCESSA array with a 0x38 stride until lpServiceName/lpDisplayName is NULL.",
  "root_cause": "Windows anchors the enumerated service strings at the END of the caller's buffer and zeroes the space between the array of structures and the string block, so entry[returned] is {NULL,NULL,...}. Wine packed the strings immediately after the array, so entry[returned] held the first service name; metasecml's walk then treated the characters 'Eventlog' (RDX=0x676f6c746e657645, R8=0) as a char* and the inline strlen at metasecml.dll+0x29943 (bytes 42 80 3c 02 00 = cmpb $0,(%rdx,%r8,1)) faulted.",
  "how_found": "Crashpad stores memory around the faulting RIP plus the full thread context, so the VMProtect-packed instruction was disassembled straight out of logs/ours_d10_final/crash.dmp (work/tools/dmp_fault.py); +relay restricted to metasecml (RelayFromInclude=metasecml + RelayInclude whitelist, run logs/relay2) showed OpenSCManagerA/EnumServicesStatusExA on the same thread whose dump has R14 equal to the relay-logged buffer.",
  "wine_vs_windows": {
    "wine_before": "entry[returned].lpServiceName = 0x676f6c746e657645 (\"Eventlog\"); string block [280..412] right after the array; 0 zeroed bytes in between",
    "wine_after": "entry[returned] = NULL; string block [836..968] anchored to the buffer end; gap zeroed",
    "windows_11": "entry[returned] = NULL; string block anchored to the buffer end (offsets shift by exactly the buffer-size delta: +512/+8192 measured); whole gap zeroed (verified with a 0xAA prefill); same for the W call",
    "probes": "work/tools/svcenum_probe.c (A), svcenumw_probe.c (W), svcenum_probe2.c/3.c (anchor + gap characterisation); outputs in work/tools/svcenum*_wine_before.txt, *_wine_after.txt, *_windows.txt",
    "harness": "prefix-test and the win11 guest via vmshare/ + scripts/vmcmd3.sh"
  },
  "classification": "general Wine gap (not CapCut-specific) -> patches/series/, not patches/local/",
  "fix": {
    "patch": "patches/series/0027-advapi32-sechost-EnumServicesStatusEx-string-placement.patch",
    "files": [
      "dlls/sechost/service.c (EnumServicesStatusExW: anchor WCHAR strings at size-string_bytes, zero the gap)",
      "dlls/advapi32/service.c (EnumServicesStatusExA: same for ANSI strings, plus a real ERROR_INSUFFICIENT_BUFFER instead of the old unsigned underflow of n)",
      "dlls/advapi32/tests/service.c (test_enum_svc_ex: pins the layout for A and W in an oversized buffer)"
    ],
    "commit": "c94f44e on branch merged (message approved by Main and quoted verbatim in the commit; 3 files, +133/-3)",
    "series_metadata": "patch added to patches/series/, row 0027 added to patches/SERIES.tsv, table row + prose added to patches/README.md",
    "reproducibility": "27/27 verified: git worktree of 2ca2d8f ('pristine wine-11.18') + patch -p1 for every file in series/ (27 applied) then diff -rq -x .git against git archive HEAD = IDENTICAL"
  },
  "test": {
    "suite": "wine dlls/advapi32/tests/x86_64-windows/advapi32_test.exe service",
    "before": "769 tests, 6 failures — 3 per call: 'expected a gap between the array of structures and the strings', 'expected a NULL entry right after the last returned service', 'expected the strings anchored at the end of the buffer'",
    "after": "769 tests, 0 failures (1 skipped, WoW64)"
  },
  "acceptance": {
    "clean": "logs/fix330 — solo CC_AUTOCLICK=1 cc_run.sh fix330 330, WINELOADER_BIN=$CCWS/wine-install/bin, DISPLAY=:10: launcher_alive_at_end=yes, last_time_app_proc_seen_s=328, n_app_procs_left=8, no 'ALL CAPCUT PROCESSES GONE', NO .dmp anywhere (prefix Crash/reports holds only empty dirs); recon/fix330/root_328s.png shows CapCut's full home screen at t=328s (with the pre-existing 'Project saved path not found' modal, an app-state issue)",
    "600s_attempts": "logs/fix600 died at t=292s because display :10 was closed externally mid-run (stdout ends 'XIO: fatal IO error 104 (Connection reset by peer) on X server \":10\"') — no dump; :10 was restarted (scripts/start_display.sh :10 + openbox, DRI3+Present confirmed). logs/fix600b crashed at t=40s with a dump whose ExceptionAddress is Qt6Core.dll+0x162b52 — a different module and a different defect, and the same DLLs had just run 330s clean. No metasecml.dll+0x29943 fault occurred in any post-fix run; a clean 600s run is still outstanding.",
    "post_install_sanity": "after make install: wine --version = wine-11.18; wine cmd /c echo ok = 'ok' in prefix-test (a pre-existing x86_64-only warning about syswow64\\rundll32 is unrelated)"
  },
  "caveats": [
    "The minidump's exception record says the read was from 0xffffffffffffffff while the same dump's exception context (RIP == ExceptionAddress) says the operand address is RDX=0x676f6c746e657645 ('Eventlog'); both readings name the same defect and the fix is independent of which is trusted. Recorded explicitly in CRASH100S.md §6.",
    "Wine's 'needed' over-estimate is numerically different from Windows' (968 vs a Windows figure that scales with the service list); only the layout was matched.",
    "The non-Ex EnumServicesStatusW/A wrappers lay their strings out from the start; they were not measured against Windows and were left untouched."
  ],
  "docs_updated": [
    "recon/CRASH100S.md rewritten: identified call, exact faulting chain, probe table (Wine before/after vs Windows 11), fix, test, surviving-run evidence, and the record-vs-context discrepancy",
    "STATE.md §28 end updated with the commit, 27/27 verification, test counts and acceptance results",
    "patches/README.md (table row + prose + 27/27 note), patches/SERIES.tsv row 0027"
  ],
  "ruled_out_or_not_needed": "CreateToolhelp32Snapshot/Module32*/RegGetValueA (MachineGuid, ProductId)/BCrypt MD5/etc. all appear in the same relay window and answer normally; the crashing thread's own call log ends at the EnumServicesStatusExA pair, so no other candidate needed a Windows comparison."
}