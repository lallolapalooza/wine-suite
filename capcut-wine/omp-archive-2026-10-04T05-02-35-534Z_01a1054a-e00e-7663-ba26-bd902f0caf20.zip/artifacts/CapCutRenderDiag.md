{
  "summary": "CapCut paints its real UI under Wine. The acceptance shot exists: recon/ours_d10_final/HOME_SCREEN_CLEAN.png (t=79s of a solo 620s run) and recon/ours_d10_winconf/HOME_SCREEN.png are CapCut's full home screen ('Create project', EditPilot, Projects, ...) on OUR build (wine-install/bin/wine), DXVK off, DISPLAY=:10, openbox, with the app's own env-detection config forced to the branch Windows takes.",
  "deliverables": {
    "report": "recon/RENDER.md (284 lines): verdict, the rewritten observer, 12 configurations with evidence, the app's own logs, ranked causes with for/against, exact reproduction recipe",
    "acceptance_screenshots": [
      "recon/ours_d10_final/HOME_SCREEN_CLEAN.png (home screen, no modal)",
      "recon/ours_d10_winconf/HOME_SCREEN.png (home screen + 'Project saved path' modal)",
      "recon/ours_d10_final/root_61s_b.png",
      "recon/ours_d10_winconf/root_38s_b.png"
    ],
    "observer": "scripts/cc_run.sh — polls by argv substring (Wine argv[0] is a Windows path, so pgrep -x never matches), first sample the instant an app process/CapCut window appears, samples every SAMPLE s, two root captures + per-window captures for IsViewable windows only (import on an unmapped window hangs for ever), exit code + LAUNCHER EXITED moment + stdout_at_exit.log, size-stable crash-dump rescue, prefix pre-warm with wineboot -u, prefix-scoped cleanup via /proc/*/environ, and a flock run lock that refuses a second owner. Knobs: WINELOADER_BIN, CC_DISPLAY, SAMPLE, DXVK_CONF, CC_AUTOCLICK, CC_KILL_VEDETECTOR_AT.",
    "helper_scripts": [
      "scripts/dll_overrides.sh (native|builtin)",
      "scripts/find_cyan_click.py (finds the CapCut accent button)",
      "scripts/cc_dismiss.sh (escalating input prober)",
      "scripts/dmp_summary.py (rewritten for crashpad ExceptionList/full dumps)"
    ],
    "screenshots_per_config": "every configuration run with the new observer has screenshots in recon/<tag>/ (stg_base_1 18, stg_wm_dxvk 27, stg_wm_builtin 174, ours_builtin 104, ours_d10_builtin 57, ours_d10_click3 61, ours_d10_winconf 66, ours_d10_noveD 96, ours_d10_final 69)"
  },
  "key_findings": [
    {
      "finding": "Our dcomp+dxgi port is what makes any paint possible: on staging the app never mapped a window for 130s; on our build it paints.",
      "evidence": "recon/stg_base_1 (no viewable window in 120s) vs recon/ours_d10_builtin/root_22s_b.png (ToS dialog)"
    },
    {
      "finding": "DXVK must be OFF: DXVK's DXGI has no CreateSwapChainForComposition (E_NOTIMPL), so Qt's D3D11 RHI gets no composition surface.",
      "evidence": "DXVK runs produce no dcomp output and a holed white window (recon/stg_wm_dxvk/win_0xc00008_38s.png); Main's t_d3d11dcomp control; runs use builtin overrides"
    },
    {
      "finding": "The remaining rendering defect is CapCut's hardware-render branch: same app/Wine/display, only the detection config differs -> hw branch = uniformly white main window, software branch = full home screen.",
      "evidence": "ours_d10_builtin/click2 (mean 0.865, white) vs ours_d10_winconf + ours_d10_final (mean 0.057, home screen)"
    },
    {
      "finding": "The 'black rectangle' in the white main window is a capture artefact: it is exactly the ToS dialog's occluded area (352x161+544+429 inside the main window).",
      "evidence": "win_0xc00010_30s.png measured with -trim; the root capture of the same sample shows the white window with the dialog card on top"
    },
    {
      "finding": "VEDetector's 'request settings' is a NETWORK call that SUCCEEDS (editor-api.capcutapi.com/service/settings/v3); all 12 detector items finish and report success; the later 'request settings timeout' is a deferred second callback and is not the blocker.",
      "evidence": "logs/ours_builtin/VeDetector_2026-10-04T00-46-07.log lines 634-1243"
    },
    {
      "finding": "The SIGKILL that truncated runs was mostly my own harness: with a flock run lock and one solo 620s run the app lived 130s (vs 42-56s); it is still killed at 130s with a 201MB crashpad dump at t~98s and upload_nomal_quit=0.",
      "evidence": "logs/ours_d10_final/timeline.log 'LAUNCHER EXITED at t=130s wall=01:09:41', rescue.log, crashuploadremark.ini"
    },
    {
      "finding": "ve_detector/ is load-bearing for the ANGLE load but is NOT the hardware-branch fix: hw runs that went white had it present with 0 'failed to load library' lines; removing it is the only thing that logs the failure and it stalls earlier.",
      "evidence": "grep -c 'failed to load library' per tag; ours_d10_noveD"
    },
    {
      "finding": "Mouse input does not reach the app on :10 (Xwayland): 6 xdotool click/Return attempts at the verified button centre had no effect.",
      "evidence": "ours_d10_click3 / ours_d10_noveD CLICK lines; xdotool getmouselocation round-trip is exact, so it is delivery/focus, not coordinates"
    }
  ],
  "prefix_changes": [
    "HKCU\\Software\\Wine\\DllOverrides: d3d8 d3d9 d3d10core d3d11 dxgi = builtin (no DXVK)",
    "Config/EnvDetect.json, EnvDetectSimulate.json, ve_hw_check.ini copied from recon/winlog/Config (Windows reference); globalSetting = Windows flags + Wine's own cache paths; backups in recon/config_wine_backup/",
    "no dxvk.conf in the app dir; ve_detector/ restored to its original name",
    "note: the app rewrites globalSetting back to hardwareRenderEnable=true while running, so the Windows config must be re-applied before each run"
  ],
  "final_state": "prefix and installed app intact (CapCut.exe present), wine build tree untouched, no cc_run processes left, overrides builtin, config left in the working (rendering) state; only recon/, logs/, scripts/ and prefix/ were written",
  "open_items": [
    "the 130s SIGKILL (app's own crash/safe-guard path or another agent on the shared prefix) - needs a +seh solo run against stdout_at_exit.log",
    "why the hardware branch leaves the main window white (AGFX/EffectSDK GL-ANGLE path vs D3D11 CheckFormatSupport)",
    "mouse input delivery on :10"
  ]
}