{
  "summary": "CapCut's hardware-render branch now paints its home screen under Wine. The ticket's step-1 question is settled by measurement: Qt DOES call DirectComposition, our dcomp IS reached, and it composites. The white window was caused by dcomp's commit-time blit being unable to read R8G8B8A8 (the only format the app uses). Fixed by series/0030 (commit ba18ed4); series is 30 patches, reproducibility 30/30.",
  "step1_measurement": {
    "winedebug": "+dcomp,+dxgi, hardware config, run logs/hwdcomp1",
    "quoted_lines": [
      "trace:dcomp:DCompositionCreateDevice 0000000000000000, {c37ea93a-e7aa-450d-b16f-9746cb0407f3}.",
      "trace:dcomp:dcomp_device_create rendering_device 0000000000000000, iid {c37ea93a-...}",
      "trace:dcomp:dcomp_device1_CreateTargetForHwnd iface ..., hwnd 0000000000060122, topmost 0, target ...",
      "trace:dcomp:dcomp_target_create Created target ... for hwnd 0000000000060122",
      "trace:dcomp:dcomp_device1_CreateVisual ... / trace:dcomp:dcomp_visual_create Created visual ...",
      "trace:dxgi:dxgi_factory_CreateSwapChainForComposition desc: 1440x994 format 0x1c buffers 2 effect 0x4 alpha 0x1 flags 0 (pid 348).",
      "trace:dcomp:dcomp_visual_SetContent iface ..., content 00007BBDA6988670.",
      "trace:dcomp:dcomp_target_SetRoot iface ..., visual ...",
      "trace:dcomp:dcomp_target_blit_swapchain Blit of content ... returned 0.",
      "warn:dcomp:dcomp_target_present Content 00007BBDA6988670 is not a blittable composition swapchain.",
      "trace:dxgi:__wine_dxgi_set_composition_target Swapchain ... now composites into window 0000000000060122 at 0,0.",
      "trace:dxgi:d3d11_swapchain_composite Compositing swapchain ... into window 0000000000060122."
    ],
    "called": [
      "DCompositionCreateDevice",
      "IDCompositionDevice::CreateTargetForHwnd",
      "CreateVisual",
      "IDCompositionVisual::SetContent",
      "IDCompositionTarget::SetRoot",
      "Commit (dcomp_device_commit; no trace of its own - its effects are the two lines after it)",
      "IDXGIFactory2::CreateSwapChainForComposition (1440x994, R8G8B8A8, PREMULTIPLIED, FLIP_DISCARD)"
    ],
    "never_called": [
      "DCompositionCreateSurfaceHandle (still '@ stub'; nothing measured justifies implementing it - withdrawn, as the previous agent correctly suspected)",
      "IDCompositionDevice{1,3}::CreateSurface / CreateVirtualSurface / CreateSurfaceFromHandle / CreateSurfaceFromHwnd"
    ],
    "why_previous_conclusion_was_wrong": "hwtrace3/hwrb3-family runs used WINEDEBUG=+dxgi but NOT +dcomp, and 'now composites into' is dxgi's channel. 'No DCompositionCreateDevice' was inferred from a channel that was never enabled. With +dcomp, even the *white* run hwrb3 shows CreateDevice/CreateTargetForHwnd/CreateVisual/SetContent/SetRoot."
  },
  "root_cause_and_fix": {
    "defect": "dcomp_target_blit_swapchain composited with IDXGISurface1::GetDC + StretchBlt, which cannot read R8G8B8A8 (wined3d has no DDI format), so every commit logged 'Blit of content ... returned 0' + WARN 'not a blittable composition swapchain' - for the only format the app asks for (0x1c). Ordering made it fatal: Qt does Present THEN Commit, and dxgi's per-present composite needs composition_window, which only Commit sets; a scene that presents once and goes static was never shown. Measured: hwrb3 = 1 Present / 0 composites / white; hwattr = 1079 Presents / painted.",
    "fix": "series/0030, commit ba18ed4, exactly the approved message 'dcomp: composite a composition swap chain through dxgi, including R8G8B8A8'. New private dxgi export __wine_dxgi_composite_swapchain (sets the target + calls d3d11_swapchain_composite, including series/0029's staging readback); dcomp's commit calls it. No second composition engine.",
    "extra_bug_found_and_fixed": "dcomp_target_Release never did list_remove(&target->entry), leaving a dangling entry in the device's target list; the next CreateTargetForHwnd reused the freed block, the list became self-referential, and the next Commit looped (the control probe hung 60 s on its second case until fixed). Recorded in the commit body.",
    "files": [
      "dlls/dxgi/swapchain.c",
      "dlls/dxgi/dxgi.spec",
      "dlls/dxgi/dxgi_private.h",
      "dlls/dcomp/target.c",
      "dlls/dcomp/device.c"
    ],
    "patch": "patches/series/0030-dcomp-composite-a-composition-swap-chain-through-dxgi.patch; patches/SERIES.tsv + patches/README.md updated; patches/local/ still empty (30 series patches)."
  },
  "before_after_pixels": {
    "probe": "work/tools/t_d3d11dcomp.cpp - now renders a solid colour, Commits, and READS THE WINDOW PIXEL BACK, for both B8G8R8A8 and R8G8B8A8 (PROBE_ONLY=bgra8|rgba8). Run in prefix-test with WINEDLLOVERRIDES='d3d10core,d3d11,dxgi,d3d8,d3d9=b' (prefix-test has DXVK, whose dxgi answers CreateSwapChainForComposition with E_NOTIMPL).",
    "before": {
      "B8G8R8A8": "ok - window RGB(230,51,13)",
      "R8G8B8A8": "FAIL - window RGB(255,255,255) (white)",
      "result": "RESULT: FAIL (1 failure)"
    },
    "after": {
      "B8G8R8A8": "ok - window RGB(230,51,13)",
      "R8G8B8A8": "ok - window RGB(13,51,230)",
      "result": "RESULT: ALL PATHS OK (0 failures), exit 0"
    },
    "files": [
      "work/tools/t_d3d11dcomp_rgba8_before_fix.txt",
      "work/tools/t_d3d11dcomp_wine_before_fix.txt",
      "work/tools/t_d3d11dcomp_wine_after_fix.txt",
      "work/tools/t_d3d11dcomp_wine_after_fix_d9.txt (same ALL PATHS OK on :9)"
    ],
    "why_the_old_probe_misled": "it only ever used B8G8R8A8 (where GetDC works) and never looked at a pixel - an API sequence that returns S_OK says nothing about whether pixels arrive."
  },
  "acceptance": {
    "primary_run": "logs/hwaccept11b",
    "display": ":11 = sway WLR_BACKENDS=headless -> Xwayland -> openbox. xdpyinfo 1916x1173, 96x96 DPI, DRI3 present, checked before AND after the run.",
    "command": "cc_cfg.sh hw; CC_DISPLAY=:11 SAMPLE=5 WINELOADER_BIN=$CCWS/wine-install/bin DXVK_CONF=none scripts/cc_run.sh hwaccept11b 240 'err+all,fixme-all'  (solo, DXVK off, no +dcomp/+dxgi)",
    "evidence": "exit_code=137 elapsed_at_exit=243s launcher_alive_at_end=yes; last_time_app_proc_seen_s=235; n_app_procs_left=7; capcut_windows=36; screenshots=574; 0 crash dump; root_33s_b.png..root_243s_b.png mean 0.101 (1916x1173 screen, 1440x994 window ~58% of it); screenshot recon/hwaccept11b/HOME_SCREEN.png shows the full home screen.",
    "second_run": "logs/hwaccept on :10 (Xwayland 1600x1000, 96 DPI, DRI3): exit_code=137 elapsed_at_exit=245s launcher_alive_at_end=yes, last_time_app_proc_seen_s=237, n_app_procs_left=8, 623 screenshots, 0 crash dump, mean 0.142 - recon/hwaccept/HOME_SCREEN.png.",
    "software_branch": "NOT regressed: logs/swaccept on :10 painted the full home screen post-0030 (recon/swaccept/HOME_SCREEN.png, t=31 s, mean 0.124) and logs/swaccept9b on :9 likewise (t=15-30 s). Later software re-runs (swaccept10) hit the same 'LAUNCHER EXITED at t=13s' early exit the hardware runs hit - pre-existing erratic behaviour (STATE §32), not a regression.",
    "wine_suites": {
      "dxgi_test.exe": "20448 tests executed (332 marked as todo, 0 as flaky, 0 failures), 36 skipped - logs/dxgi_test_0030.log; before 0030 (STATE §35.1) was 20460 (332 todo, 2 flaky, 0 failures), the delta being flaky-rerun accounting, 0 failures both times.",
      "dcomp/d3d11": "dlls/dcomp/tests is NOT in this tree's build ('grep -c dcomp/tests Makefile' -> 0, no generated Makefile in that directory), so the suite added with 0023 has never run here - a pre-existing gap, documented. Behavioural regression test for 0030 is the pixel-checking probe above."
    },
    "reproducibility": "30/30 - pristine 2ca2d8f worktree + patch -p1 for every file in patches/series/ (30 applied) + diff -rq -x .git against git archive HEAD = empty ('REPRODUCIBLE: no differences')."
  },
  "docs": {
    "STATE.md": "new section 48 (48.1 measurement, 48.2 defect+fix, 48.3 before/after with pixels, 48.4 acceptance) plus a display note: measured display properties, the :10 Xwayland fragility, the correction that on :9 the app DOES paint the home screen and then dies at t~35 s (not white), and that the intermittent Qt6Core.dll+0x162b52 crash is STATE §30's open item, not this change. Renumbered from §45 to §48 because Main added §45-§47.",
    "recon/RENDER.md": "new section 10: supersedes §9's 'still open' paragraph, records the measurement, the defect, the fix, the pixel-checked before/after, the acceptance and suite numbers, and the DRI3 requirement.",
    "patches/README.md + SERIES.tsv": "0030 row; counts updated 29->30; local/ note updated."
  },
  "two_separate_facts": {
    "0030": "the compositing fix - RGBA8 composition swap chains now composite on Commit, so a static scene is shown.",
    "dri3": "a property the DISPLAY must have - the app renders on DRI3 displays (:10, :11) and on :9 (Xvfb, no DRI3) it renders the home screen once and then dies at t~35 s. 0030 behaves identically on :9 and :11 in the probe (ALL PATHS OK both), so 0030 does not depend on DRI3; the app's rendering does."
  },
  "not_done_or_open": [
    "The intermittent Qt6Core.dll+0x162b52 crash (STATE §30) is still open and still intermittent: seen pre-0030 (hwdcomp1/hwdcomp2/fix600b) and post-0030 (hwaccept9/hwaccept9c/swaccept9b), never in hwattr/hwdcomp3/hwaccept/hwaccept11b. Identical signature and information [0, 0xffffffffffffffff] in every dump.",
    "DCompositionCreateSurfaceHandle and IDCompositionDevice{1,3}::CreateSurface* remain stubs - nothing measured calls them; on this measurement they should stay stubs.",
    "'Project saved path not found' modal (STATE §31/§33/§44) untouched - out of scope for this ticket."
  ],
  "operational_notes": [
    "use :11 (headless DRI3) for app runs: invisible and cannot be closed; :10 is a window in the user's desktop session and was closed mid-task once, killing three runs with 'x11drv: Can't open display: :10' / 'XIO: fatal IO error 104'.",
    "killing a cc_run script leaves orphaned wine processes holding logs/.cc_run.lock via the inherited fd 9; free it with 'fuser -k logs/.cc_run.lock' before the next run.",
    "WORKDIR unchanged: /home/asdf/projects/capcut-wine; wine tree clean at ba18ed4; disk 18 GB free."
  ]
}